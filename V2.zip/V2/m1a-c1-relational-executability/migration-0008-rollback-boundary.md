# Migration 0008 rollback boundary

`migration-0008.proposal.sql` is additive and is executed here only in one
owned loopback disposable PostgreSQL 18 cluster. It is not a production
migration.

There is intentionally no destructive `down.sql`. Application rollback keeps
the private schema and append-only authorities intact. A later separately
approved contraction may remove unused objects only after:

- M0_C1 and exact backup/PITR/rollback authority pass;
- N-1 application compatibility is no longer required;
- every operation, job, attempt, outbox, webhook, gate, authorization,
  terminal, budget and usage row is reconciled;
- provider egress is disabled and external-ledger reconciliation is complete;
- retention, export, delete and legal-hold decisions are approved;
- a restore drill proves the exact recovery point; and
- Owner and release authorities explicitly approve the irreversible change.

The private schema must never be dropped merely to roll back an application
digest. Terminal Human Gate/formal decisions, external egress commitments and
provider outcome authorities are historical truth, not cache.

