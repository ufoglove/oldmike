# Architecture decision: relationally executable production foundation

## Outcome

Adopt a strangler architecture that retains the current C19/Beta2 user and
domain semantics while replacing future production execution infrastructure:

1. A modular Next.js web/BFF owns Better Auth session resolution, exact
   tenant/project authorization, commands, projections, and the stable
   `/api/v2-beta2` compatibility surface. It performs no provider I/O.
2. PostgreSQL is the business-truth authority for project snapshots/events,
   canonical operation intent, source bundles, approved registries, jobs,
   Human Gates, formal authorizations, receipts, reconciliation, budgets, and
   append-only usage.
3. An outbox relay publishes ID/hash-only messages and never changes business
   job state.
4. A durable worker is the sole consumer allowed to request provider egress.
   It obtains a database lease, conditionally creates the immutable external
   egress-ledger entry, commits `MAY_HAVE_SUBMITTED` before network I/O, and
   never resends that attempt.
5. A provider-egress broker is the only network-capable component. It validates
   the external ledger commitment and provider policy, then performs one
   bounded request. The production conditional ledger target is DynamoDB, held
   disabled pending exact AWS account/capability evidence.
6. Reconciliation is lookup/webhook/authorized-human only. It cannot generate,
   retry, fail over, or infer a terminal outcome.
7. Raw source bytes live in versioned object storage. Queue and ordinary logs
   contain IDs, hashes, states, timings, and bounded usage only.

## Exact ownership

| Owner | Allowed authority | Forbidden authority |
|---|---|---|
| Web/BFF | auth, project commands, deterministic payloads, projections | provider credentials/I/O, raw table DML |
| PostgreSQL capabilities | canonical identity, CAS, append-only truth, exact result binding | external network I/O, caller-supplied free-form truth |
| Relay | lease/publish/ack typed outbox rows | job state decisions, project truth, provider I/O |
| Worker | lease, budget, external-ledger coordination, strict outcome commit | blind resend, cross-provider failover, direct project table DML |
| Provider broker | one bounded provider request after exact ledger proof | database mutation, tenant/project truth, retry policy |
| Reconciler | non-generating lookup, webhook and authorized-human evidence | submission, unbound terminal promotion |
| Observer | sanitized aggregate views | baseline/auth/research/provider-body rows |

## Relational authority

Every new object is schema-qualified under `old_mike_production_private` and
owned by `old_mike_prod_owner`. The migrator has only the exact PostgreSQL 18
`SET` membership needed to create owner-owned objects. Web, worker, relay and
observer roles are NOLOGIN, NOINHERIT and receive no raw table mutation.
`SECURITY DEFINER` functions have owner identity, `search_path=pg_catalog`, no
dynamic SQL, exact input types, fixed locks/CAS order, and explicit grants.

Human and formal decisions are modeled as request/decision and
authorization/terminal-event pairs. No terminal row is updated. A formal
authorization requires the exact confirmed decision and same project snapshot;
its immutable dispatch row references that authorization.

Provider attempts use a single immutable tuple:

`workspace + project + job + attemptNo + providerClass + providerRequestId + requestHash + requestAuthorityHash + externalLedgerHash`.

Receipts, reconciliation observations, usage, and terminal job state bind that
tuple. `PREPARED` or `MAY_HAVE_SUBMITTED` in either the external ledger or
PostgreSQL prevents another submission. `COMPLETION_UNKNOWN` is permanent
no-resend until exact reconciliation evidence commits a terminal state.

## Compatibility

`/api/v2-beta2/projects/[projectId]` remains the stable M1/M2 path. Future
command-layer refactoring is internal. Existing request, response, error,
HTTP-status, idempotency, tenant/project, UNKNOWN, and no-resend semantics must
remain byte-compatible for N-1 clients and rollback servers. There is no silent
path rename.

## Deployment target boundary

The recommended later target is AWS `ap-east-2`: ECS/Fargate behind ALB,
traditional RDS PostgreSQL Multi-AZ DB instance, SQS FIFO/DLQ, S3/KMS,
CloudFront for public static assets only, standard AWS Backup/Vault Lock,
multi-Region CloudTrail to a log archive, and conventional build-once OCI
promotion. No RDS Proxy or Multi-AZ DB Cluster dependency is assumed. All
account/region/service/quota/AZ/engine/class/OIDC/backup and connection-budget
facts remain `UNKNOWN` and block apply.

## Decision status

`PASS_LOCAL_RELATIONAL_DESIGN_WITH_DISPOSABLE_POSTGRESQL18_PROOF_ONLY` may be
claimed only if the package verifier and real PG18 proof both pass with P0=0,
P1=0 and predecessor bytes unchanged. This is not executable M1 approval,
production migration authority, release readiness, or Professor UAT.

