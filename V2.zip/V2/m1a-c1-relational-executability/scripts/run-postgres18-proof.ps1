[CmdletBinding()]
param()

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$scriptRoot = Split-Path -Parent $PSCommandPath
$packageRoot = [System.IO.Path]::GetFullPath((Join-Path $scriptRoot '..'))
$workspaceRoot = [System.IO.Path]::GetFullPath((Join-Path $packageRoot '..\..'))
$pgBin = 'C:\Program Files\PostgreSQL\18\bin'
$psql = Join-Path $pgBin 'psql.exe'
$createdb = Join-Path $pgBin 'createdb.exe'
$initdb = Join-Path $pgBin 'initdb.exe'
$pgCtl = Join-Path $pgBin 'pg_ctl.exe'
$node = (Get-Command node -ErrorAction Stop).Source
$tempParent = [System.IO.Path]::GetFullPath([System.IO.Path]::GetTempPath())
$ownedRoot = Join-Path $tempParent ('old-mike-m1a-c1-pg18-proof-' + [guid]::NewGuid().ToString('N'))
$dataRoot = Join-Path $ownedRoot 'data'
$postgresLog = Join-Path $ownedRoot 'postgres.log'
$serverStarted = $false
$cleanupStatus = 'UNKNOWN'
$stage = 'BOOTSTRAP'
$result = $null
$failure = $null
$port = $null

function Get-Sha256([byte[]]$Bytes) {
  return [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($Bytes)).ToLowerInvariant()
}

function Get-TextDigest([string]$Text) {
  return Get-Sha256 ([Text.Encoding]::UTF8.GetBytes($Text))
}

function Invoke-CheckedProcess {
  param(
    [Parameter(Mandatory=$true)][string]$FilePath,
    [Parameter(Mandatory=$true)][string[]]$ArgumentList,
    [hashtable]$Environment = @{}
  )
  $info = [Diagnostics.ProcessStartInfo]::new()
  $info.FileName = $FilePath
  $info.UseShellExecute = $false
  $info.CreateNoWindow = $true
  $info.RedirectStandardOutput = $true
  $info.RedirectStandardError = $true
  foreach ($argument in $ArgumentList) { [void]$info.ArgumentList.Add($argument) }
  foreach ($entry in $Environment.GetEnumerator()) { $info.Environment[$entry.Key] = [string]$entry.Value }
  $process = [Diagnostics.Process]::new()
  $process.StartInfo = $info
  if (-not $process.Start()) { throw "process_start_failed:$([IO.Path]::GetFileName($FilePath))" }
  $stdoutTask = $process.StandardOutput.ReadToEndAsync()
  $stderrTask = $process.StandardError.ReadToEndAsync()
  $process.WaitForExit()
  $stdout = $stdoutTask.GetAwaiter().GetResult()
  $stderr = $stderrTask.GetAwaiter().GetResult()
  if ($process.ExitCode -ne 0) {
    $tail = (($stderr + "`n" + $stdout) -split "`r?`n" | Select-Object -Last 14) -join ' | '
    throw "process_failed:$([IO.Path]::GetFileName($FilePath)):$($process.ExitCode):$tail"
  }
  return [pscustomobject]@{ ExitCode=$process.ExitCode; Stdout=$stdout; Stderr=$stderr }
}

function Invoke-CheckedProcessWithoutRedirect {
  param(
    [Parameter(Mandatory=$true)][string]$FilePath,
    [Parameter(Mandatory=$true)][string[]]$ArgumentList,
    [int]$TimeoutMilliseconds = 60000
  )
  $info = [Diagnostics.ProcessStartInfo]::new()
  $info.FileName = $FilePath
  $info.UseShellExecute = $false
  $info.CreateNoWindow = $true
  $info.RedirectStandardOutput = $false
  $info.RedirectStandardError = $false
  foreach ($argument in $ArgumentList) { [void]$info.ArgumentList.Add($argument) }
  $process = [Diagnostics.Process]::new()
  $process.StartInfo = $info
  if (-not $process.Start()) { throw "process_start_failed:$([IO.Path]::GetFileName($FilePath))" }
  if (-not $process.WaitForExit($TimeoutMilliseconds)) {
    try { $process.Kill($true) } catch {}
    throw "process_timeout:$([IO.Path]::GetFileName($FilePath))"
  }
  if ($process.ExitCode -ne 0) {
    throw "process_failed:$([IO.Path]::GetFileName($FilePath)):$($process.ExitCode)"
  }
  return [pscustomobject]@{ ExitCode=$process.ExitCode }
}

function Invoke-PsqlFile {
  param([string]$Database,[string]$User,[string]$Path,[string]$Role='')
  $arguments = @('-h','127.0.0.1','-p',[string]$script:port,'-U',$User,'-d',$Database,'-X','-v','ON_ERROR_STOP=1','-f',$Path)
  $environment = @{}
  if ($Role) { $environment.PGOPTIONS = "-c role=$Role" }
  return Invoke-CheckedProcess -FilePath $script:psql -ArgumentList $arguments -Environment $environment
}

function Invoke-PsqlQuery {
  param([string]$Database,[string]$User,[string]$Query,[string]$Role='')
  $arguments = @('-h','127.0.0.1','-p',[string]$script:port,'-U',$User,'-d',$Database,'-X','-A','-t','-v','ON_ERROR_STOP=1','-c',$Query)
  $environment = @{}
  if ($Role) { $environment.PGOPTIONS = "-c role=$Role" }
  return Invoke-CheckedProcess -FilePath $script:psql -ArgumentList $arguments -Environment $environment
}

function Start-PsqlFile {
  param([string]$Database,[string]$Path)
  $info = [Diagnostics.ProcessStartInfo]::new()
  $info.FileName = $script:psql
  $info.UseShellExecute = $false
  $info.CreateNoWindow = $true
  $info.RedirectStandardOutput = $true
  $info.RedirectStandardError = $true
  foreach ($argument in @('-h','127.0.0.1','-p',[string]$script:port,'-U','m1a_c1_fixture_runner','-d',$Database,'-X','-v','ON_ERROR_STOP=1','-f',$Path)) {
    [void]$info.ArgumentList.Add($argument)
  }
  $process = [Diagnostics.Process]::new()
  $process.StartInfo = $info
  if (-not $process.Start()) { throw 'concurrent_psql_start_failed' }
  return [pscustomobject]@{
    Process=$process
    StdoutTask=$process.StandardOutput.ReadToEndAsync()
    StderrTask=$process.StandardError.ReadToEndAsync()
  }
}

function Complete-StartedProcess($Started) {
  $Started.Process.WaitForExit()
  return [pscustomobject]@{
    ExitCode=$Started.Process.ExitCode
    Stdout=$Started.StdoutTask.GetAwaiter().GetResult()
    Stderr=$Started.StderrTask.GetAwaiter().GetResult()
  }
}

function Get-FreeLoopbackPort {
  $listener = [Net.Sockets.TcpListener]::new([Net.IPAddress]::Loopback,0)
  $listener.Start()
  try { return ([Net.IPEndPoint]$listener.LocalEndpoint).Port }
  finally { $listener.Stop() }
}

function Test-PortClosed([int]$Port) {
  $client = [Net.Sockets.TcpClient]::new()
  try {
    $task = $client.ConnectAsync('127.0.0.1',$Port)
    if (-not $task.Wait(350)) { return $true }
    return -not $client.Connected
  } catch { return $true }
  finally { $client.Dispose() }
}

try {
  $stage = 'STATIC_PRECHECK'
  foreach ($required in @($psql,$createdb,$initdb,$pgCtl,$node)) {
    if (-not (Test-Path -LiteralPath $required -PathType Leaf)) { throw "required_executable_missing:$required" }
  }
  $versionResult = Invoke-CheckedProcess -FilePath $psql -ArgumentList @('--version')
  if ($versionResult.Stdout -notmatch ' 18\.') { throw 'postgresql_18_client_required' }
  $staticBefore = Invoke-CheckedProcess -FilePath $node -ArgumentList @((Join-Path $scriptRoot 'verify-static-package.mjs'))
  $staticBeforeValue = $staticBefore.Stdout.Trim() | ConvertFrom-Json
  if ($staticBeforeValue.status -ne 'PASS') { throw 'static_precheck_failed' }

  $stage = 'OWNED_CLUSTER_CREATE'
  if (Test-Path -LiteralPath $ownedRoot) { throw 'owned_root_collision' }
  New-Item -ItemType Directory -Path $ownedRoot | Out-Null
  $port = Get-FreeLoopbackPort
  [void](Invoke-CheckedProcess -FilePath $initdb -ArgumentList @('-D',$dataRoot,'-A','trust','-U','postgres','--encoding=UTF8','--no-locale'))
  [void](Invoke-CheckedProcessWithoutRedirect -FilePath $pgCtl -ArgumentList @('-D',$dataRoot,'-l',$postgresLog,'-o',"-p $port -h 127.0.0.1",'-w','-s','start'))
  $serverStarted = $true
  $serverVersion = (Invoke-PsqlQuery -Database 'postgres' -User 'postgres' -Query "SELECT current_setting('server_version');").Stdout.Trim()
  if ($serverVersion -notmatch '^18\.') { throw 'postgresql_18_server_required' }

  $stage = 'ROLE_BOOTSTRAP'
  [void](Invoke-PsqlFile -Database 'postgres' -User 'postgres' -Path (Join-Path $packageRoot 'fixtures\bootstrap-roles.sql'))
  foreach ($databaseName in @('m1a_c1_empty','m1a_c1_nminus1')) {
    [void](Invoke-CheckedProcess -FilePath $createdb -ArgumentList @('-h','127.0.0.1','-p',[string]$port,'-U','postgres','-O','old_mike_prod_owner',$databaseName))
  }

  $migrationFiles = Get-ChildItem -LiteralPath (Join-Path $workspaceRoot 'research-portal\database\migrations') -Filter '*.up.sql' | Sort-Object Name
  if ($migrationFiles.Count -ne 7) { throw "baseline_migration_count_invalid:$($migrationFiles.Count)" }
  $catalogFile = Join-Path $packageRoot 'fixtures\catalog-authority.sql'
  $preCatalog = @{}
  $postCatalog = @{}
  $verifyDigests = @{}
  foreach ($databaseName in @('m1a_c1_empty','m1a_c1_nminus1')) {
    $stage = "BASELINE_$databaseName"
    foreach ($migration in $migrationFiles) {
      [void](Invoke-PsqlFile -Database $databaseName -User 'm1a_c1_fixture_runner' -Role 'old_mike_prod_owner' -Path $migration.FullName)
    }
    if ($databaseName -eq 'm1a_c1_nminus1') {
      [void](Invoke-PsqlFile -Database $databaseName -User 'm1a_c1_fixture_runner' -Role 'old_mike_prod_owner' -Path (Join-Path $packageRoot 'fixtures\nminus1-seed.sql'))
    }
    $preText = (Invoke-PsqlFile -Database $databaseName -User 'postgres' -Path $catalogFile).Stdout
    $preCatalog[$databaseName] = Get-TextDigest $preText
  }
  if ($preCatalog.m1a_c1_empty -ne $preCatalog.m1a_c1_nminus1) { throw 'nminus1_pre_catalog_drift' }

  foreach ($databaseName in @('m1a_c1_empty','m1a_c1_nminus1')) {
    $stage = "MIGRATION_0008_$databaseName"
    [void](Invoke-PsqlFile -Database $databaseName -User 'm1a_c1_fixture_runner' -Role 'old_mike_prod_migrator' -Path (Join-Path $packageRoot 'migration-0008.proposal.sql'))
    $verifyResult = Invoke-PsqlFile -Database $databaseName -User 'postgres' -Path (Join-Path $packageRoot 'migration-0008.verify.sql')
    if ($verifyResult.Stdout -notmatch '"status": "PASS"') { throw "migration_verify_failed:$databaseName" }
    $verifyDigests[$databaseName] = Get-TextDigest $verifyResult.Stdout
    $postText = (Invoke-PsqlFile -Database $databaseName -User 'postgres' -Path $catalogFile).Stdout
    $postCatalog[$databaseName] = Get-TextDigest $postText
  }
  if ($postCatalog.m1a_c1_empty -ne $postCatalog.m1a_c1_nminus1) { throw 'nminus1_post_catalog_drift' }
  if ($postCatalog.m1a_c1_empty -eq $preCatalog.m1a_c1_empty) { throw 'migration_catalog_delta_missing' }

  $stage = 'RESTORE_POINT_PRE_MARKER'
  $restorePre = (Invoke-PsqlQuery -Database 'm1a_c1_nminus1' -User 'postgres' -Query "SELECT pg_create_restore_point('m1a_c1_pre_external_marker');").Stdout.Trim()

  $stage = 'CAPABILITY_MAIN'
  $capabilityResult = Invoke-PsqlFile -Database 'm1a_c1_nminus1' -User 'm1a_c1_fixture_runner' -Path (Join-Path $packageRoot 'fixtures\capability-tests.sql')
  if ($capabilityResult.Stdout -notmatch '"status": "PASS"') { throw 'capability_main_missing_pass' }

  $stage = 'CAPABILITY_ADVANCED'
  $advancedResult = Invoke-PsqlFile -Database 'm1a_c1_nminus1' -User 'm1a_c1_fixture_runner' -Path (Join-Path $packageRoot 'fixtures\advanced-capability-tests.sql')
  if ($advancedResult.Stdout -notmatch '"status": "PASS"') { throw 'capability_advanced_missing_pass' }

  $stage = 'CONCURRENT_GATE'
  $gateA = Start-PsqlFile -Database 'm1a_c1_nminus1' -Path (Join-Path $packageRoot 'fixtures\concurrent-gate-confirm.sql')
  $gateB = Start-PsqlFile -Database 'm1a_c1_nminus1' -Path (Join-Path $packageRoot 'fixtures\concurrent-gate-reject.sql')
  $gateResults = @((Complete-StartedProcess $gateA),(Complete-StartedProcess $gateB))
  $gateSuccesses = @($gateResults | Where-Object ExitCode -eq 0)
  $gateFailures = @($gateResults | Where-Object ExitCode -ne 0)
  $gateConcurrencyInvalid = $gateSuccesses.Count -ne 1 -or $gateFailures.Count -ne 1
  if (-not $gateConcurrencyInvalid) {
    $gateConcurrencyInvalid = $gateFailures[0].Stderr -notmatch 'm1a_c1_gate_already_decided'
  }
  if ($gateConcurrencyInvalid) {
    throw 'concurrent_gate_decision_authority_invalid'
  }

  $stage = 'CONCURRENT_FORMAL_AUTHORIZATION'
  $formalA = Start-PsqlFile -Database 'm1a_c1_nminus1' -Path (Join-Path $packageRoot 'fixtures\concurrent-formal-authorize.sql')
  $formalB = Start-PsqlFile -Database 'm1a_c1_nminus1' -Path (Join-Path $packageRoot 'fixtures\concurrent-formal-authorize.sql')
  $formalResults = @((Complete-StartedProcess $formalA),(Complete-StartedProcess $formalB))
  $formalFailures = @($formalResults | Where-Object ExitCode -ne 0)
  $formalOutput = ($formalResults | ForEach-Object Stdout) -join "`n"
  if ($formalFailures.Count -ne 0 -or $formalOutput -notmatch 'AUTHORIZED' -or $formalOutput -notmatch 'REPLAYED') {
    throw 'concurrent_formal_authorization_authority_invalid'
  }
  $concurrencyResult = Invoke-PsqlFile -Database 'm1a_c1_nminus1' -User 'm1a_c1_fixture_runner' -Path (Join-Path $packageRoot 'fixtures\post-concurrency-assertions.sql')
  if ($concurrencyResult.Stdout -notmatch '"status": "PASS"') { throw 'post_concurrency_assertions_failed' }

  $stage = 'EXTERNAL_LEDGER_SIMULATION'
  $ledgerResult = Invoke-CheckedProcess -FilePath $node -ArgumentList @((Join-Path $scriptRoot 'external-egress-ledger-fixture.mjs'))
  $ledgerValue = $ledgerResult.Stdout.Trim() | ConvertFrom-Json
  if ($ledgerValue.status -ne 'PASS' -or $ledgerValue.externalEffects -ne 0 -or $ledgerValue.crashWindowCount -ne 5) {
    throw 'external_ledger_fixture_failed'
  }

  $stage = 'RESTORE_POINT_POST_RESULT'
  $restorePost = (Invoke-PsqlQuery -Database 'm1a_c1_nminus1' -User 'postgres' -Query "SELECT pg_create_restore_point('m1a_c1_post_external_result');").Stdout.Trim()
  if (-not $restorePre -or -not $restorePost -or $restorePre -eq $restorePost) { throw 'restore_point_observation_invalid' }

  $stage = 'FINAL_DATABASE_AGGREGATE'
  $aggregateQuery = @"
SELECT jsonb_build_object(
  'aiJobs',(SELECT count(*) FROM old_mike_production_private.ai_jobs),
  'dispatchOutbox',(SELECT count(*) FROM old_mike_production_private.dispatch_outbox),
  'formalAuthorizations',(SELECT count(*) FROM old_mike_production_private.formal_effect_authorizations),
  'formalTerminals',(SELECT count(*) FROM old_mike_production_private.formal_effect_terminal_events),
  'gateDecisions',(SELECT count(*) FROM old_mike_production_private.human_gate_decisions),
  'projectEvents',(SELECT count(*) FROM old_mike_production_private.project_events),
  'providerAttempts',(SELECT count(*) FROM old_mike_production_private.provider_attempts),
  'providerSubmissionCount',(SELECT coalesce(sum(provider_submission_count),0) FROM old_mike_production_private.ai_jobs),
  'reconciliationObservations',(SELECT count(*) FROM old_mike_production_private.reconciliation_observations),
  'snapshots',(SELECT count(*) FROM old_mike_production_private.project_snapshots),
  'usageRows',(SELECT count(*) FROM old_mike_production_private.usage_ledger)
)::text;
"@
  $aggregateText = (Invoke-PsqlQuery -Database 'm1a_c1_nminus1' -User 'postgres' -Query $aggregateQuery).Stdout.Trim()
  $aggregateValue = $aggregateText | ConvertFrom-Json
  $aggregateInvalid = $aggregateValue.aiJobs -ne 7 -or $aggregateValue.providerSubmissionCount -ne 7
  $aggregateInvalid = $aggregateInvalid -or $aggregateValue.formalAuthorizations -ne 2 -or $aggregateValue.formalTerminals -ne 2
  $aggregateInvalid = $aggregateInvalid -or $aggregateValue.reconciliationObservations -ne 3
  if ($aggregateInvalid) {
    throw "database_aggregate_invalid:$aggregateText"
  }

  $stage = 'STATIC_POSTCHECK'
  $staticAfter = Invoke-CheckedProcess -FilePath $node -ArgumentList @((Join-Path $scriptRoot 'verify-static-package.mjs'))
  $staticAfterValue = $staticAfter.Stdout.Trim() | ConvertFrom-Json
  $staticDrift = $staticAfterValue.status -ne 'PASS'
  $staticDrift = $staticDrift -or $staticAfterValue.packageSha256 -ne $staticBeforeValue.packageSha256
  $staticDrift = $staticDrift -or $staticAfterValue.totalBytes -ne $staticBeforeValue.totalBytes
  if ($staticDrift) {
    throw 'static_package_drift_during_proof'
  }

  $inputFiles = Get-ChildItem -LiteralPath $packageRoot -Recurse -File | Sort-Object FullName
  $inputAuthorities = @($inputFiles | ForEach-Object {
    $bytes = [IO.File]::ReadAllBytes($_.FullName)
    [ordered]@{
      path = [IO.Path]::GetRelativePath($packageRoot,$_.FullName).Replace('\','/')
      size = $bytes.Length
      sha256 = Get-Sha256 $bytes
    }
  })
  $result = [ordered]@{
    schemaId = 'old-mike-v2-production-ai/m1a-c1-postgres18-proof-observation/1'
    status = 'PASS'
    trustClass = 'LOCAL_DISPOSABLE_POSTGRESQL18_PROOF_ONLY_NOT_PRODUCTION_NOT_UAT'
    postgresql = [ordered]@{
      exactMajor = 18
      observedVersion = $serverVersion
      clusterCount = 1
      databaseCount = 2
      migrationRunnerSuperuser = $false
      loopbackOnly = $true
    }
    catalogAuthority = [ordered]@{
      preNMinus1MatchesEmpty = $true
      postNMinus1MatchesEmpty = $true
      preSha256 = $preCatalog.m1a_c1_empty
      postSha256 = $postCatalog.m1a_c1_empty
      declaredDeltaOnly = $true
      verifyEmptySha256 = $verifyDigests.m1a_c1_empty
      verifyNMinus1Sha256 = $verifyDigests.m1a_c1_nminus1
    }
    observedCases = [ordered]@{
      appRawDmlDenied = $true
      concurrentGateExactlyOne = $true
      concurrentFormalAuthorizationExactlyOne = $true
      executedAndRevokedTerminalAlternatives = $true
      externalLedgerCrashWindows = 5
      leaseFencingAndStaleCommitRejected = $true
      nMinus1Upgrade = $true
      providerOutcomeTotality = $true
      reconciliationMethods = @('AUTHORIZED_HUMAN','LOOKUP','SIGNED_WEBHOOK')
      replayNoResend = $true
      restorePointCount = 2
      wrongPayloadRejected = $true
    }
    databaseAggregate = $aggregateValue
    package = [ordered]@{
      fileCount = $staticAfterValue.fileCount
      totalBytes = $staticAfterValue.totalBytes
      streamBytes = $staticAfterValue.streamBytes
      sha256 = $staticAfterValue.packageSha256
      inputs = $inputAuthorities
    }
    effects = [ordered]@{
      nonLoopbackConnections = 0
      productionDatabaseConnections = 0
      providerNetworkCalls = 0
      publicNetworkCalls = 0
      formalResearchWrites = 0
      cloudMutations = 0
    }
    cleanup = [ordered]@{ clusterStopped=$false; listenerCount=1; processCount=1; ownedRootRemoved=$false }
  }
} catch {
  $failure = [ordered]@{ stage=$stage; reason=$_.Exception.Message }
} finally {
  $cleanupErrors = [Collections.Generic.List[string]]::new()
  if ($serverStarted) {
    try {
      [void](Invoke-CheckedProcessWithoutRedirect -FilePath $pgCtl -ArgumentList @('-D',$dataRoot,'-m','fast','-w','-s','stop'))
      $serverStarted = $false
    } catch { $cleanupErrors.Add('cluster_stop_failed') }
  }
  if ($null -ne $port) {
    try { if (-not (Test-PortClosed $port)) { $cleanupErrors.Add('listener_remains') } }
    catch { $cleanupErrors.Add('listener_check_failed') }
  }
  if (Test-Path -LiteralPath $ownedRoot) {
    try {
      $resolvedOwned = [System.IO.Path]::GetFullPath((Get-Item -LiteralPath $ownedRoot).FullName)
      $cleanupScopeInvalid = -not $resolvedOwned.StartsWith($tempParent,[StringComparison]::OrdinalIgnoreCase)
      $cleanupScopeInvalid = $cleanupScopeInvalid -or $resolvedOwned -eq $tempParent
      $cleanupScopeInvalid = $cleanupScopeInvalid -or ([IO.Path]::GetFileName($resolvedOwned) -notlike 'old-mike-m1a-c1-pg18-proof-*')
      if ($cleanupScopeInvalid) {
        throw 'owned_root_scope_invalid'
      }
      if (((Get-Item -LiteralPath $resolvedOwned -Force).Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
        throw 'owned_root_reparse_forbidden'
      }
      $reparseChildren = @(Get-ChildItem -LiteralPath $resolvedOwned -Recurse -Force | Where-Object {
        ($_.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0
      })
      if ($reparseChildren.Count -ne 0) { throw 'owned_root_child_reparse_forbidden' }
      Remove-Item -LiteralPath $resolvedOwned -Recurse -Force
    } catch { $cleanupErrors.Add('owned_root_remove_failed') }
  }
  if (Test-Path -LiteralPath $ownedRoot) { $cleanupErrors.Add('owned_root_remains') }
  $cleanupStatus = if ($cleanupErrors.Count -eq 0) { 'PASS' } else { 'BLOCKED:' + ($cleanupErrors -join ',') }
}

if ($failure) {
  $terminal = [ordered]@{
    schemaId='old-mike-v2-production-ai/m1a-c1-postgres18-proof-observation/1'
    status='BLOCKED'
    stage=$failure.stage
    sanitizedReason=$failure.reason
    cleanup=$cleanupStatus
    externalEffects=0
  }
  [Console]::Error.WriteLine(($terminal | ConvertTo-Json -Depth 8 -Compress))
  exit 2
}
if ($cleanupStatus -ne 'PASS') {
  $terminal = [ordered]@{
    schemaId='old-mike-v2-production-ai/m1a-c1-postgres18-proof-observation/1'
    status='BLOCKED'
    stage='CLEANUP'
    sanitizedReason=$cleanupStatus
    externalEffects=0
  }
  [Console]::Error.WriteLine(($terminal | ConvertTo-Json -Depth 8 -Compress))
  exit 2
}
$result.cleanup = [ordered]@{ clusterStopped=$true; listenerCount=0; processCount=0; ownedRootRemoved=$true }
[Console]::Out.WriteLine(($result | ConvertTo-Json -Depth 16 -Compress))
