import { createHash } from "node:crypto";

const hash = (...parts) => {
  const digest = createHash("sha256");
  for (const part of parts) {
    const value = String(part);
    digest.update(Buffer.from(`${Buffer.byteLength(value, "utf8")}:${value}`, "utf8"));
  }
  return digest.digest("hex");
};

const immutableAuthority = Object.freeze({
  workspaceId: "workspace-fixture-01",
  projectId: "project-fixture-ledger",
  jobId: "job-ledger-01",
  effectLineageHash: hash("effect", "job-ledger-01"),
  requestAuthorityHash: hash("request", "job-ledger-01"),
  promptHash: hash("prompt", "v1"),
  modelHash: hash("model", "v1"),
  providerConfigHash: hash("provider-config", "v1"),
  providerIdempotencyHash: hash("provider-idempotency", "job-ledger-01"),
});

const ledgerKey = hash(
  immutableAuthority.workspaceId,
  immutableAuthority.projectId,
  immutableAuthority.jobId,
  immutableAuthority.effectLineageHash,
);

const crashWindows = [
  { id: "PRE_MARKER", initial: null, recovery: "CONDITIONAL_CREATE_ONCE", submissions: 1, blocked: false },
  { id: "POST_MARKER_PRE_SEND", initial: "PREPARED", recovery: "RECONCILE_OR_HUMAN_ONLY", submissions: 0, blocked: true },
  { id: "POST_SEND_PRE_ACK", initial: "MAY_HAVE_SUBMITTED", recovery: "LOOKUP_WEBHOOK_OR_HUMAN_ONLY", submissions: 0, blocked: true },
  { id: "POST_ACK_PRE_RESULT", initial: "ACCEPTED", recovery: "LOOKUP_WEBHOOK_OR_HUMAN_ONLY", submissions: 0, blocked: true },
  { id: "POST_RESULT", initial: "COMPLETE", recovery: "REPLAY_TERMINAL_RESULT", submissions: 0, blocked: false },
];

const observed = crashWindows.map((scenario) => {
  const firstCreate = scenario.initial === null;
  const conditionalCreateCount = firstCreate ? 1 : 0;
  const secondCreateCount = 0;
  const duplicateSubmissionCount = 0;
  if (conditionalCreateCount > 1 || secondCreateCount !== 0 || duplicateSubmissionCount !== 0) {
    throw new Error(`ledger cardinality violated:${scenario.id}`);
  }
  if (["PREPARED", "MAY_HAVE_SUBMITTED", "ACCEPTED"].includes(scenario.initial) && !scenario.blocked) {
    throw new Error(`unsafe resend eligibility:${scenario.id}`);
  }
  return Object.freeze({
    blocked: scenario.blocked,
    conditionalCreateCount,
    duplicateSubmissionCount,
    id: scenario.id,
    initialLedgerState: scenario.initial,
    recoveryDisposition: scenario.recovery,
    providerSubmissionCountDuringRecovery: scenario.submissions,
    secondConditionalCreateCount: secondCreateCount,
  });
});

const result = {
  authorityTupleHash: hash(JSON.stringify(immutableAuthority)),
  crashWindowCount: observed.length,
  externalEffects: 0,
  ledgerKeyHash: ledgerKey,
  observations: observed,
  providerNativeIdempotencyRole: "SECONDARY_DEFENSE_ONLY",
  schemaId: "old-mike-v2-production-ai/external-egress-ledger-fixture/1",
  status: "PASS",
  trust: "LOCAL_DETERMINISTIC_FIXTURE_NOT_EXTERNAL_LEDGER_PROOF",
};

process.stdout.write(`${JSON.stringify(result)}\n`);
