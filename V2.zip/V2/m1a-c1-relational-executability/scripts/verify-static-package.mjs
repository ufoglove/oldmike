import { createHash } from "node:crypto";
import { readFile, readdir, stat } from "node:fs/promises";
import { dirname, join, relative, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const scriptDir = dirname(fileURLToPath(import.meta.url));
const packageRoot = resolve(scriptDir, "..");

const expectedFiles = [
  "README.md",
  "acceptance-matrix.json",
  "ai-execution-and-governance.json",
  "architecture-decision.md",
  "aws-ap-east-2-preflight.schema.json",
  "aws-iac-interfaces.json",
  "ci-cd-and-acceptance.md",
  "cutover-rollback-slo.md",
  "fixtures/advanced-capability-tests.sql",
  "fixtures/bootstrap-roles.sql",
  "fixtures/capability-tests.sql",
  "fixtures/catalog-authority.sql",
  "fixtures/concurrent-formal-authorize.sql",
  "fixtures/concurrent-gate-confirm.sql",
  "fixtures/concurrent-gate-reject.sql",
  "fixtures/nminus1-seed.sql",
  "fixtures/post-concurrency-assertions.sql",
  "migration-0008-rollback-boundary.md",
  "migration-0008.proposal.sql",
  "migration-0008.verify.sql",
  "module-map.json",
  "owner-decisions-cost-residency.json",
  "scripts/external-egress-ledger-fixture.mjs",
  "scripts/run-postgres18-proof.ps1",
  "scripts/verify-static-package.mjs",
  "security-data-flow-threat-model.md",
].sort();

const sha256 = (bytes) => createHash("sha256").update(bytes).digest("hex");

async function walk(directory) {
  const files = [];
  for (const entry of await readdir(directory, { withFileTypes: true })) {
    const fullPath = join(directory, entry.name);
    if (entry.isSymbolicLink()) throw new Error(`reparse entry forbidden:${relative(packageRoot, fullPath)}`);
    if (entry.isDirectory()) files.push(...(await walk(fullPath)));
    else if (entry.isFile()) files.push(relative(packageRoot, fullPath).replaceAll("\\", "/"));
    else throw new Error(`nonregular entry forbidden:${relative(packageRoot, fullPath)}`);
  }
  return files;
}

function parseJsonDuplicateAware(source, label) {
  let index = 0;
  const whitespace = () => {
    while (/\s/u.test(source[index] ?? "")) index += 1;
  };
  const parseString = () => {
    const start = index;
    if (source[index] !== '"') throw new Error(`${label}:string expected:${index}`);
    index += 1;
    while (index < source.length) {
      if (source[index] === "\\") {
        index += 2;
        continue;
      }
      if (source[index] === '"') {
        index += 1;
        return JSON.parse(source.slice(start, index));
      }
      index += 1;
    }
    throw new Error(`${label}:unterminated string`);
  };
  const parseValue = () => {
    whitespace();
    if (source[index] === "{") return parseObject();
    if (source[index] === "[") return parseArray();
    if (source[index] === '"') return parseString();
    const match = source.slice(index).match(/^(?:-?(?:0|[1-9]\d*)(?:\.\d+)?(?:[eE][+-]?\d+)?|true|false|null)/u);
    if (!match) throw new Error(`${label}:value expected:${index}`);
    index += match[0].length;
    return JSON.parse(match[0]);
  };
  const parseObject = () => {
    const value = {};
    const keys = new Set();
    index += 1;
    whitespace();
    if (source[index] === "}") {
      index += 1;
      return value;
    }
    while (true) {
      whitespace();
      const key = parseString();
      if (keys.has(key)) throw new Error(`${label}:duplicate key:${key}`);
      keys.add(key);
      whitespace();
      if (source[index] !== ":") throw new Error(`${label}:colon expected:${index}`);
      index += 1;
      value[key] = parseValue();
      whitespace();
      if (source[index] === "}") {
        index += 1;
        return value;
      }
      if (source[index] !== ",") throw new Error(`${label}:comma expected:${index}`);
      index += 1;
    }
  };
  const parseArray = () => {
    const value = [];
    index += 1;
    whitespace();
    if (source[index] === "]") {
      index += 1;
      return value;
    }
    while (true) {
      value.push(parseValue());
      whitespace();
      if (source[index] === "]") {
        index += 1;
        return value;
      }
      if (source[index] !== ",") throw new Error(`${label}:comma expected:${index}`);
      index += 1;
    }
  };
  const value = parseValue();
  whitespace();
  if (index !== source.length) throw new Error(`${label}:trailing bytes:${index}`);
  return value;
}

const actualFiles = (await walk(packageRoot)).sort();
if (JSON.stringify(actualFiles) !== JSON.stringify(expectedFiles)) {
  throw new Error(`package file set mismatch:${JSON.stringify(actualFiles)}`);
}

const entries = [];
let totalBytes = 0;
const allText = [];
for (const path of actualFiles) {
  const bytes = await readFile(join(packageRoot, path));
  const fileStat = await stat(join(packageRoot, path));
  if (!fileStat.isFile()) throw new Error(`non-file package member:${path}`);
  totalBytes += bytes.length;
  const digest = sha256(bytes);
  entries.push({ path, size: bytes.length, sha256: digest });
  const text = bytes.toString("utf8");
  if (Buffer.from(text, "utf8").compare(bytes) !== 0) throw new Error(`non-UTF8 package member:${path}`);
  allText.push(`${path}\n${text}`);
  if (path.endsWith(".json")) parseJsonDuplicateAware(text, path);
}

const joinedText = allText.join("\n");
for (const forbidden of [
  /-----BEGIN [A-Z ]+ PRIVATE KEY-----/u,
  /postgres(?:ql)?:\/\/[^\s"']+/iu,
  /\bsk-[A-Za-z0-9_-]{16,}\b/u,
  /\bAKIA[0-9A-Z]{16}\b/u,
]) {
  if (forbidden.test(joinedText)) throw new Error(`secret-shaped value forbidden:${forbidden}`);
}

const proposal = await readFile(join(packageRoot, "migration-0008.proposal.sql"), "utf8");
const verifier = await readFile(join(packageRoot, "migration-0008.verify.sql"), "utf8");
const tableNames = [...proposal.matchAll(/CREATE TABLE old_mike_production_private\.([a-z0-9_]+)/gu)]
  .map((match) => match[1]).sort();
if (tableNames.length !== 24 || new Set(tableNames).size !== 24) {
  throw new Error(`proposal table classification invalid:${JSON.stringify(tableNames)}`);
}
for (const tableName of tableNames) {
  if (!verifier.includes(`'${tableName}'`)) throw new Error(`verifier omits proposal table:${tableName}`);
}
if (/CREATE\s+(?:TABLE|VIEW|FUNCTION)\s+(?!old_mike_production_private\.)/iu.test(proposal)) {
  throw new Error("unqualified new object target detected");
}
if (proposal.split(/\r?\n/u).some((line) => /^\s*EXECUTE\s/iu.test(line))) {
  throw new Error("dynamic SQL detected");
}
const securityDefinerBlocks = proposal.split(/CREATE FUNCTION /u).slice(1)
  .filter((block) => /SECURITY DEFINER/u.test(block));
if (securityDefinerBlocks.length !== 21
  || securityDefinerBlocks.some((block) => !/SET search_path\s*=\s*pg_catalog/u.test(block))) {
  throw new Error(`SECURITY DEFINER posture invalid:${securityDefinerBlocks.length}`);
}
for (const required of [
  "REVOKE ALL PRIVILEGES ON ALL TABLES IN SCHEMA old_mike_production_private",
  "PROVEN_NOT_SUBMITTED",
  "COMPLETION_UNKNOWN",
  "external_ledger_commitment_hash",
  "gate_request_payload_hash",
  "provider_attempts_job_fk",
  "reconciliation_observations_attempt_fk",
  "SET LOCAL ROLE old_mike_prod_owner",
]) {
  if (!proposal.includes(required)) throw new Error(`proposal authority missing:${required}`);
}
for (const required of [
  "/api/v2-beta2",
  "M0_C1",
  "UNKNOWN",
  "NO_BLIND_RESEND",
  "LOCAL_STATIC_DESIGN_ONLY",
  "accountAuthorityHash",
  "old_mike_production_private",
]) {
  if (!joinedText.includes(required)) throw new Error(`package invariant missing:${required}`);
}

const stream = Buffer.concat(entries.map((entry) => Buffer.from(
  `${entry.path}\0${entry.size}\0${entry.sha256}\n`, "utf8",
)));
const result = {
  duplicateJsonKeys: 0,
  externalEffects: 0,
  fileCount: entries.length,
  packageSha256: sha256(stream),
  schemaId: "old-mike-v2-production-ai/m1a-c1-static-verifier-result/1",
  securityDefinerCount: securityDefinerBlocks.length,
  status: "PASS",
  streamBytes: stream.length,
  tableCount: tableNames.length,
  totalBytes,
};
process.stdout.write(`${JSON.stringify(result)}\n`);
