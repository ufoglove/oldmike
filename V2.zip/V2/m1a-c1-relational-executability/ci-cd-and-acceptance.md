# Conventional CI/CD and acceptance authority

## Release source

Git commit plus protected review is source authority. Linux CI checks out that
commit once, resolves a frozen lockfile, and builds one OCI image. Staging and
production promote the same digest; mutable tags and rebuild-on-promote are not
authority.

Required digest-bound artifacts are an SPDX or CycloneDX SBOM, SLSA-compatible
provenance, vulnerability policy result, signature, attestation, migration
manifest, configuration schema, and test receipts. Missing or mismatched
identity stops promotion.

## CI stages

1. Secret, credential, provider-identity and research-content leak scans.
2. Formatting, lint, TypeScript, unit and property tests.
3. Exact request/response/parser and N-1 `/api/v2-beta2` contracts.
4. PostgreSQL 18 empty and N-1 migration, catalog, ACL, capability,
   concurrency, crash, replay, lease, egress-ledger and restore-window tests.
5. Provider-port conformance with deterministic fake adapter and network deny.
6. Next.js 16.3.1 webpack production build, source/built scans, 404/405 and
   readiness behavior.
7. Product-owned standard Playwright journeys for C19 professional UX, Beta2
   durable save/resume, accessibility, material byte fidelity, idempotency,
   UNKNOWN no-resend, Human Gate, formal-write zero, and desktop/mobile.
8. Build OCI once, generate SBOM/provenance, sign, attest, and publish by digest.
9. Deploy exact digest to staging only after account/capability and migration
   gates; run integration/fault/restore/canary rehearsal.
10. Independent manual Professor UAT against the exact digest/environment only
    after a separate Brain decision.

## PostgreSQL gates

- PostgreSQL major 18 exact.
- Physical 0001-0007 digests match the frozen manifest.
- Migration session is non-superuser and uses exact SET membership into the
  NOLOGIN migrator/owner roles.
- Empty and real N-1 data paths pass.
- Baseline structural catalog stream is unchanged; only declared owner
  REFERENCES/SELECT ACL additions are allowed.
- New private-schema object, column, constraint, FK, trigger, function,
  `proconfig`, owner, ACL and default-ACL sets are exact with no extra/missing
  object.
- Raw app DML and PUBLIC function execute fail.
- Actual capability calls—not source regex—prove job, gate, formal,
  reconciliation, budget, lease and no-resend behavior.

## Acceptance ownership

Technical acceptance is product-owned and conventional. Historical A3
action-specific drivers and custom hash DAGs remain immutable evidence but
cannot grant M1/M2 or professional acceptance. Professor review judges visible
professional meaning and usability; it does not author hashes, selectors,
database proofs, or provider-state machinery.

## Stop rules

Stop on any P0/P1, M0_C1 gap, account/capability UNKNOWN, source/material drift,
tenant/project authorization defect, provider submission ambiguity, external
ledger mismatch, COMPLETION_UNKNOWN resend, registry/source/gate/formal
authority mismatch, migration/catalog/ACL drift, nonzero formal write, secret
leak, cleanup uncertainty, digest mismatch, missing rollback artifact, or
missing independent Professor UAT.

This M1A_C1 package runs only static validation and one owned loopback
disposable PostgreSQL 18 proof. It creates no OCI image and performs no CI,
deployment, UAT, provider, AWS, or public network action.

