# M1A_C1 relational executability package

Status: `LOCAL_STATIC_SUCCESSOR_WITH_DISPOSABLE_POSTGRESQL18_PROOF_ONLY`.

This directory is the complete versioned successor to the frozen M1A static
package. It does not modify the 老麥 product, run a live provider, connect to a
non-disposable database, or authorize migration, deployment, release, or
Professor UAT.

## Decision

Preserve the C19 professional UX and the Beta2 `/api/v2-beta2` contract while
moving future production execution behind a modular Next.js web/BFF, a durable
worker, a relay, and a provider-egress broker. PostgreSQL owns project truth,
operation identity, immutable source and registry authority, Human Gate and
formal-effect decisions, and provider outcome reconciliation. A conditional
provider-egress ledger outside PostgreSQL's PITR domain is the primary
one-submission fence; provider-native idempotency is secondary.

All new relational objects live in the owner-controlled
`old_mike_production_private` schema. Production roles are NOLOGIN,
NOINHERIT, non-superuser, non-BYPASSRLS roles. Application roles receive no raw
table DML. Exact `SECURITY DEFINER` capabilities with `search_path=pg_catalog`
are the only write path.

## Package map

- `architecture-decision.md`: target architecture and ownership boundaries.
- `module-map.json`: exact current-to-target file and module classification.
- `ai-execution-and-governance.json`: total state, evidence, queue, provider,
  reconciliation, budget, registry, Human Gate, and formal-effect authority.
- `aws-ap-east-2-preflight.schema.json` and `aws-iac-interfaces.json`: disabled,
  account-bound future infrastructure interfaces.
- `migration-0008.proposal.sql`: executable additive proposal for a disposable
  PostgreSQL 18 proof only.
- `migration-0008.verify.sql`: fail-closed catalog, ACL, owner, function,
  trigger, FK, capability, and invariant verifier.
- `migration-0008-rollback-boundary.md`: expand/backfill/reconcile/canary/soak
  and non-destructive rollback boundary.
- `fixtures/`: disposable role/bootstrap, N-1 seed, capability, concurrency,
  tamper, and outcome fixtures.
- `scripts/run-postgres18-proof.ps1`: one fresh owned loopback PostgreSQL 18
  cluster, two databases (empty and N-1), physical 0001-0007 application,
  successor application, capability execution, catalog comparison, external
  egress-ledger simulation, cleanup, and sanitized observation.
- `scripts/external-egress-ledger-fixture.mjs`: local `wx` conditional-create
  simulation outside PostgreSQL.
- `scripts/verify-static-package.mjs`: exact package/static cross-file checks.
- `acceptance-matrix.json`, `ci-cd-and-acceptance.md`,
  `security-data-flow-threat-model.md`, `cutover-rollback-slo.md`, and
  `owner-decisions-cost-residency.json`: implementation and stop authorities.

## Frozen boundaries

- Runtime product and `/api/v2-beta2` wire semantics are unchanged.
- AWS account/region capabilities are `UNKNOWN` and disabled until M0_C1 and
  exact account evidence pass.
- No provider, AWS, Zeabur, Neon, n8n, scholarly, Zotero, or public network call
  is made.
- Migration 0008 is a proposal executed only against an owned loopback
  disposable PostgreSQL 18 cluster.
- Formal research effects remain impossible without one confirmed Human Gate,
  one immutable formal authorization, and one append-only terminal event.

## Proof contract

The runner must observe PostgreSQL major version 18, apply the exact physical
0001-0007 files, run 0008 as a non-superuser role, verify empty and N-1 paths,
invoke actual capability functions, and clean the owned cluster. It emits no
DSN, credential, absolute secret path, raw research text, or provider body.

Static parsing, regex checks, and in-memory models are supporting evidence
only. Any missing capability invocation, catalog mismatch, unknown outcome,
stale fencing token, privilege leak, cleanup uncertainty, or predecessor drift
is blocking.

