\set ON_ERROR_STOP on

-- M1A_C1 additive production-AI relational foundation proposal.
-- AUTHORITY: disposable PostgreSQL 18 proof only; NOT a production migration.

BEGIN;
SET LOCAL lock_timeout = '5s';
SET LOCAL statement_timeout = '60s';
SET LOCAL idle_in_transaction_session_timeout = '60s';

DO $preflight$
DECLARE
  role_name text;
  role_row record;
BEGIN
  IF current_setting('server_version_num')::integer < 180000
     OR current_setting('server_version_num')::integer >= 190000 THEN
    RAISE EXCEPTION 'm1a_c1_postgresql_18_required';
  END IF;
  IF current_user <> 'old_mike_prod_migrator' THEN
    RAISE EXCEPTION 'm1a_c1_exact_migrator_role_required';
  END IF;

  FOREACH role_name IN ARRAY ARRAY[
    'old_mike_prod_owner',
    'old_mike_prod_migrator',
    'old_mike_prod_web',
    'old_mike_prod_worker',
    'old_mike_prod_relay',
    'old_mike_prod_observer'
  ] LOOP
    SELECT * INTO role_row FROM pg_catalog.pg_roles WHERE rolname = role_name;
    IF NOT FOUND THEN
      RAISE EXCEPTION 'm1a_c1_required_role_missing:%', role_name;
    END IF;
    IF role_row.rolsuper OR role_row.rolinherit OR role_row.rolcreaterole
       OR role_row.rolcreatedb OR role_row.rolcanlogin OR role_row.rolreplication
       OR role_row.rolbypassrls THEN
      RAISE EXCEPTION 'm1a_c1_unsafe_role_attributes:%', role_name;
    END IF;
  END LOOP;

  IF NOT EXISTS (
    SELECT 1
      FROM pg_catalog.pg_auth_members membership
      JOIN pg_catalog.pg_roles granted_role ON granted_role.oid = membership.roleid
      JOIN pg_catalog.pg_roles member_role ON member_role.oid = membership.member
     WHERE granted_role.rolname = 'old_mike_prod_owner'
       AND member_role.rolname = 'old_mike_prod_migrator'
       AND membership.admin_option = false
       AND membership.inherit_option = false
       AND membership.set_option = true
  ) THEN
    RAISE EXCEPTION 'm1a_c1_exact_migrator_owner_membership_required';
  END IF;

  IF EXISTS (
    SELECT 1
      FROM pg_catalog.pg_auth_members membership
      JOIN pg_catalog.pg_roles member_role ON member_role.oid = membership.member
     WHERE member_role.rolname IN (
       'old_mike_prod_owner', 'old_mike_prod_web', 'old_mike_prod_worker',
       'old_mike_prod_relay', 'old_mike_prod_observer'
     )
  ) THEN
    RAISE EXCEPTION 'm1a_c1_production_role_must_not_inherit_memberships';
  END IF;
END
$preflight$;

SET LOCAL ROLE old_mike_prod_owner;

GRANT USAGE ON SCHEMA public TO old_mike_prod_owner;
GRANT SELECT, REFERENCES ON TABLE public.projects, public.workspace_members, public."user"
  TO old_mike_prod_owner;

CREATE SCHEMA old_mike_production_private AUTHORIZATION old_mike_prod_owner;
REVOKE ALL ON SCHEMA old_mike_production_private FROM PUBLIC;

CREATE DOMAIN old_mike_production_private.sha256_hex AS text
  CHECK (VALUE ~ '^[0-9a-f]{64}$');

CREATE DOMAIN old_mike_production_private.authority_id AS text
  CHECK (char_length(VALUE) BETWEEN 3 AND 200 AND VALUE ~ '^[A-Za-z0-9][A-Za-z0-9._:-]+$');

CREATE FUNCTION old_mike_production_private.hash_parts(VARIADIC p_parts text[])
RETURNS text
LANGUAGE sql
IMMUTABLE
PARALLEL SAFE
SET search_path = pg_catalog
AS $function$
  SELECT pg_catalog.encode(
    pg_catalog.sha256(
      pg_catalog.convert_to(
        COALESCE(
          pg_catalog.string_agg(
            CASE
              WHEN value IS NULL THEN '-1:'
              ELSE pg_catalog.octet_length(pg_catalog.convert_to(value, 'UTF8'))::text || ':' || value
            END,
            '' ORDER BY ordinal
          ),
          ''
        ),
        'UTF8'
      )
    ),
    'hex'
  )
  FROM pg_catalog.unnest(p_parts) WITH ORDINALITY AS item(value, ordinal)
$function$;

CREATE FUNCTION old_mike_production_private.canonical_json_hash(p_payload jsonb)
RETURNS text
LANGUAGE sql
IMMUTABLE
STRICT
PARALLEL SAFE
SET search_path = pg_catalog
AS $function$
  SELECT pg_catalog.encode(
    pg_catalog.sha256(pg_catalog.convert_to(p_payload::text, 'UTF8')),
    'hex'
  )
$function$;

CREATE FUNCTION old_mike_production_private.assert_exact_payload(
  p_supplied jsonb,
  p_expected jsonb,
  p_supplied_hash text
)
RETURNS void
LANGUAGE plpgsql
IMMUTABLE
STRICT
SET search_path = pg_catalog
AS $function$
DECLARE
  expected_hash text;
BEGIN
  expected_hash := old_mike_production_private.canonical_json_hash(p_expected);
  IF p_supplied <> p_expected OR p_supplied_hash <> expected_hash THEN
    RAISE EXCEPTION 'm1a_c1_payload_authority_invalid';
  END IF;
END
$function$;

CREATE FUNCTION old_mike_production_private.assert_active_member(
  p_workspace_id text,
  p_project_id text,
  p_actor_user_id text
)
RETURNS void
LANGUAGE plpgsql
STABLE
STRICT
SET search_path = pg_catalog
AS $function$
BEGIN
  IF NOT EXISTS (
    SELECT 1
      FROM public.projects project_row
      JOIN public.workspace_members member_row
        ON member_row.workspace_id = project_row.workspace_id
       AND member_row.user_id = p_actor_user_id
     WHERE project_row.workspace_id = p_workspace_id
       AND project_row.project_id = p_project_id
       AND project_row.status = 'ACTIVE'
       AND project_row.legacy = false
  ) THEN
    RAISE EXCEPTION 'm1a_c1_active_tenant_project_member_required';
  END IF;
END
$function$;

CREATE TABLE old_mike_production_private.migration_authority (
  migration_id text PRIMARY KEY,
  schema_version text NOT NULL UNIQUE,
  baseline_files jsonb NOT NULL,
  baseline_manifest_hash old_mike_production_private.sha256_hex NOT NULL,
  proposal_hash_authority text NOT NULL DEFAULT 'PHYSICAL_FILE_HASH_BOUND_BY_PACKAGE_MANIFEST',
  applied_by_role text NOT NULL,
  applied_at timestamptz NOT NULL DEFAULT pg_catalog.statement_timestamp(),
  CHECK (migration_id = '0008_production_ai_foundation'),
  CHECK (schema_version = 'old-mike-v2-production-ai/migration-0008/1'),
  CHECK (applied_by_role = 'old_mike_prod_owner'),
  CHECK (pg_catalog.jsonb_typeof(baseline_files) = 'array'),
  CHECK (pg_catalog.jsonb_array_length(baseline_files) = 14)
);

INSERT INTO old_mike_production_private.migration_authority (
  migration_id, schema_version, baseline_files, baseline_manifest_hash, applied_by_role
) VALUES (
  '0008_production_ai_foundation',
  'old-mike-v2-production-ai/migration-0008/1',
  '[
    {"path":"0001_better_auth_core.down.sql","size":175,"sha256":"371c85d5adbe3a2abea9e5f9a493974cbae47b1005b9d35e64949a89aeffeef6"},
    {"path":"0001_better_auth_core.up.sql","size":1781,"sha256":"87a62b7b42094e8a41ecd1ddb050ffb3582cb87550a0bf374c314e50334ac768"},
    {"path":"0002_old_mike_tenant.down.sql","size":394,"sha256":"82fea4bdbfa5eff3bc6537cb9c310d0ba42a6c4d30f6d4a0e1ad089a68365a13"},
    {"path":"0002_old_mike_tenant.up.sql","size":3388,"sha256":"781be7081ea1be0a319496d0fd4f82fbe57fdaa42a9f663504f810eb31f01597"},
    {"path":"0003_registration_invites.down.sql","size":58,"sha256":"40ada3f89bbf1dd98034e08abd3b81b02f1356314d7aaadc79ec62ee4ed7d6a4"},
    {"path":"0003_registration_invites.up.sql","size":1136,"sha256":"dbf7a7af07c1d071cd325cc410600dfc6ef20f682aa2cc384df4072ef7e3cbb0"},
    {"path":"0004_registration_invite_revocation.down.sql","size":1169,"sha256":"163b0b220cd5ae6a1ece943c92e392fd9643209c34a3fe0474111083dce33f9a"},
    {"path":"0004_registration_invite_revocation.up.sql","size":1286,"sha256":"db6d91c3c04b27c6131feaea7c144780d87e7c9e1123323a08062bcfd108ae64"},
    {"path":"0005_research_workflow_phase2.down.sql","size":1099,"sha256":"bbb6a06dde8128ad2dde4d1127597a9942dcff76963f79c84a889210cfbea8ba"},
    {"path":"0005_research_workflow_phase2.up.sql","size":14056,"sha256":"34d1c22c0965cbe4d8f3241b80a935a6981d7fe51ee1a275bab171889fa3e1d7"},
    {"path":"0006_admin_provisioned_accounts.down.sql","size":632,"sha256":"6b5b60f04e72ff8604f4ab5469410af7bfa9a730441f46d72281f14d94e41d48"},
    {"path":"0006_admin_provisioned_accounts.up.sql","size":3051,"sha256":"8ba2a874c5b3df87227303f36799fbb1429d51fe112d1013b1824fee5f7826aa"},
    {"path":"0007_topic_lab_frontier_radar.down.sql","size":974,"sha256":"0cbb2231c3fe294da4234d56094d881bcea1706866003a3bfb3a881b15baa03d"},
    {"path":"0007_topic_lab_frontier_radar.up.sql","size":3774,"sha256":"8dce3d2ef516be42e676c4643a14c253de167469e80f7e86cdf8d20f7f80d815"}
  ]'::jsonb,
  old_mike_production_private.canonical_json_hash('[
    {"path":"0001_better_auth_core.down.sql","size":175,"sha256":"371c85d5adbe3a2abea9e5f9a493974cbae47b1005b9d35e64949a89aeffeef6"},
    {"path":"0001_better_auth_core.up.sql","size":1781,"sha256":"87a62b7b42094e8a41ecd1ddb050ffb3582cb87550a0bf374c314e50334ac768"},
    {"path":"0002_old_mike_tenant.down.sql","size":394,"sha256":"82fea4bdbfa5eff3bc6537cb9c310d0ba42a6c4d30f6d4a0e1ad089a68365a13"},
    {"path":"0002_old_mike_tenant.up.sql","size":3388,"sha256":"781be7081ea1be0a319496d0fd4f82fbe57fdaa42a9f663504f810eb31f01597"},
    {"path":"0003_registration_invites.down.sql","size":58,"sha256":"40ada3f89bbf1dd98034e08abd3b81b02f1356314d7aaadc79ec62ee4ed7d6a4"},
    {"path":"0003_registration_invites.up.sql","size":1136,"sha256":"dbf7a7af07c1d071cd325cc410600dfc6ef20f682aa2cc384df4072ef7e3cbb0"},
    {"path":"0004_registration_invite_revocation.down.sql","size":1169,"sha256":"163b0b220cd5ae6a1ece943c92e392fd9643209c34a3fe0474111083dce33f9a"},
    {"path":"0004_registration_invite_revocation.up.sql","size":1286,"sha256":"db6d91c3c04b27c6131feaea7c144780d87e7c9e1123323a08062bcfd108ae64"},
    {"path":"0005_research_workflow_phase2.down.sql","size":1099,"sha256":"bbb6a06dde8128ad2dde4d1127597a9942dcff76963f79c84a889210cfbea8ba"},
    {"path":"0005_research_workflow_phase2.up.sql","size":14056,"sha256":"34d1c22c0965cbe4d8f3241b80a935a6981d7fe51ee1a275bab171889fa3e1d7"},
    {"path":"0006_admin_provisioned_accounts.down.sql","size":632,"sha256":"6b5b60f04e72ff8604f4ab5469410af7bfa9a730441f46d72281f14d94e41d48"},
    {"path":"0006_admin_provisioned_accounts.up.sql","size":3051,"sha256":"8ba2a874c5b3df87227303f36799fbb1429d51fe112d1013b1824fee5f7826aa"},
    {"path":"0007_topic_lab_frontier_radar.down.sql","size":974,"sha256":"0cbb2231c3fe294da4234d56094d881bcea1706866003a3bfb3a881b15baa03d"},
    {"path":"0007_topic_lab_frontier_radar.up.sql","size":3774,"sha256":"8dce3d2ef516be42e676c4643a14c253de167469e80f7e86cdf8d20f7f80d815"}
  ]'::jsonb),
  current_user
);

CREATE TABLE old_mike_production_private.project_snapshots (
  workspace_id text NOT NULL,
  project_id text NOT NULL,
  revision bigint NOT NULL CHECK (revision >= 0),
  content_hash old_mike_production_private.sha256_hex NOT NULL,
  predecessor_content_hash old_mike_production_private.sha256_hex,
  operation text NOT NULL,
  operation_identity_hash old_mike_production_private.sha256_hex NOT NULL,
  request_id old_mike_production_private.authority_id NOT NULL,
  idempotency_key old_mike_production_private.authority_id NOT NULL,
  request_hash old_mike_production_private.sha256_hex NOT NULL,
  actor_user_id text NOT NULL,
  schema_version text NOT NULL,
  authority_payload_hash old_mike_production_private.sha256_hex NOT NULL,
  source_job_id old_mike_production_private.authority_id,
  created_at timestamptz NOT NULL DEFAULT pg_catalog.statement_timestamp(),
  PRIMARY KEY (workspace_id, project_id, revision),
  UNIQUE (workspace_id, project_id, content_hash),
  UNIQUE (workspace_id, project_id, revision, content_hash),
  CONSTRAINT project_snapshots_project_fk FOREIGN KEY (workspace_id, project_id)
    REFERENCES public.projects(workspace_id, project_id) ON DELETE RESTRICT,
  CONSTRAINT project_snapshots_actor_fk FOREIGN KEY (actor_user_id)
    REFERENCES public."user"(id) ON DELETE RESTRICT,
  CHECK ((revision = 0 AND predecessor_content_hash IS NULL)
      OR (revision > 0 AND predecessor_content_hash IS NOT NULL))
);

CREATE TABLE old_mike_production_private.operation_intents (
  workspace_id text NOT NULL,
  project_id text NOT NULL,
  operation text NOT NULL,
  request_id old_mike_production_private.authority_id NOT NULL,
  idempotency_key old_mike_production_private.authority_id NOT NULL,
  request_hash old_mike_production_private.sha256_hex NOT NULL,
  base_revision bigint NOT NULL CHECK (base_revision >= 0),
  base_content_hash old_mike_production_private.sha256_hex NOT NULL,
  operation_identity_hash old_mike_production_private.sha256_hex NOT NULL,
  job_id old_mike_production_private.authority_id NOT NULL,
  actor_user_id text NOT NULL,
  status text NOT NULL DEFAULT 'PENDING' CHECK (status IN ('PENDING', 'COMMITTED', 'CONFLICTED')),
  committed_revision bigint,
  committed_content_hash old_mike_production_private.sha256_hex,
  committed_event_id old_mike_production_private.authority_id,
  committed_response_hash old_mike_production_private.sha256_hex,
  created_at timestamptz NOT NULL DEFAULT pg_catalog.statement_timestamp(),
  terminal_at timestamptz,
  PRIMARY KEY (workspace_id, project_id, operation_identity_hash),
  UNIQUE (workspace_id, project_id, idempotency_key),
  UNIQUE (workspace_id, project_id, request_id),
  UNIQUE (
    workspace_id, project_id, operation, request_id, idempotency_key,
    request_hash, base_revision, base_content_hash, operation_identity_hash
  ),
  CONSTRAINT operation_intents_project_fk FOREIGN KEY (workspace_id, project_id)
    REFERENCES public.projects(workspace_id, project_id) ON DELETE RESTRICT,
  CONSTRAINT operation_intents_actor_fk FOREIGN KEY (actor_user_id)
    REFERENCES public."user"(id) ON DELETE RESTRICT,
  CHECK (
    (status = 'PENDING' AND committed_revision IS NULL AND committed_content_hash IS NULL
      AND committed_event_id IS NULL AND committed_response_hash IS NULL AND terminal_at IS NULL)
    OR
    (status IN ('COMMITTED', 'CONFLICTED') AND committed_revision IS NOT NULL
      AND committed_content_hash IS NOT NULL AND committed_event_id IS NOT NULL
      AND committed_response_hash IS NOT NULL AND terminal_at IS NOT NULL)
  )
);

CREATE TABLE old_mike_production_private.source_objects (
  workspace_id text NOT NULL,
  project_id text NOT NULL,
  source_object_id old_mike_production_private.authority_id NOT NULL,
  object_kind text NOT NULL CHECK (object_kind IN ('ORIGINAL', 'DERIVATIVE')),
  object_store_version_id old_mike_production_private.authority_id NOT NULL,
  byte_length bigint NOT NULL CHECK (byte_length >= 0),
  content_sha256 old_mike_production_private.sha256_hex NOT NULL,
  original_source_object_id old_mike_production_private.authority_id,
  transformation_authority_hash old_mike_production_private.sha256_hex,
  created_at timestamptz NOT NULL DEFAULT pg_catalog.statement_timestamp(),
  PRIMARY KEY (workspace_id, project_id, source_object_id),
  UNIQUE (workspace_id, project_id, source_object_id, object_store_version_id, byte_length, content_sha256),
  CONSTRAINT source_objects_project_fk FOREIGN KEY (workspace_id, project_id)
    REFERENCES public.projects(workspace_id, project_id) ON DELETE RESTRICT,
  CONSTRAINT source_objects_original_fk FOREIGN KEY (workspace_id, project_id, original_source_object_id)
    REFERENCES old_mike_production_private.source_objects(workspace_id, project_id, source_object_id) ON DELETE RESTRICT,
  CHECK (
    (object_kind = 'ORIGINAL' AND original_source_object_id IS NULL AND transformation_authority_hash IS NULL)
    OR
    (object_kind = 'DERIVATIVE' AND original_source_object_id IS NOT NULL AND transformation_authority_hash IS NOT NULL)
  )
);

CREATE TABLE old_mike_production_private.source_bundles (
  workspace_id text NOT NULL,
  project_id text NOT NULL,
  source_bundle_id old_mike_production_private.authority_id NOT NULL,
  version integer NOT NULL CHECK (version > 0),
  member_count integer NOT NULL CHECK (member_count > 0),
  bundle_hash old_mike_production_private.sha256_hex NOT NULL,
  created_at timestamptz NOT NULL DEFAULT pg_catalog.statement_timestamp(),
  PRIMARY KEY (workspace_id, project_id, source_bundle_id, version),
  UNIQUE (workspace_id, project_id, source_bundle_id, version, bundle_hash),
  CONSTRAINT source_bundles_project_fk FOREIGN KEY (workspace_id, project_id)
    REFERENCES public.projects(workspace_id, project_id) ON DELETE RESTRICT
);

CREATE TABLE old_mike_production_private.source_bundle_members (
  workspace_id text NOT NULL,
  project_id text NOT NULL,
  source_bundle_id old_mike_production_private.authority_id NOT NULL,
  bundle_version integer NOT NULL,
  ordinal integer NOT NULL CHECK (ordinal > 0),
  source_object_id old_mike_production_private.authority_id NOT NULL,
  object_store_version_id old_mike_production_private.authority_id NOT NULL,
  byte_length bigint NOT NULL CHECK (byte_length >= 0),
  content_sha256 old_mike_production_private.sha256_hex NOT NULL,
  PRIMARY KEY (workspace_id, project_id, source_bundle_id, bundle_version, ordinal),
  UNIQUE (workspace_id, project_id, source_bundle_id, bundle_version, source_object_id),
  CONSTRAINT source_bundle_members_bundle_fk FOREIGN KEY (workspace_id, project_id, source_bundle_id, bundle_version)
    REFERENCES old_mike_production_private.source_bundles(workspace_id, project_id, source_bundle_id, version) ON DELETE RESTRICT,
  CONSTRAINT source_bundle_members_object_fk FOREIGN KEY (
    workspace_id, project_id, source_object_id, object_store_version_id, byte_length, content_sha256
  ) REFERENCES old_mike_production_private.source_objects(
    workspace_id, project_id, source_object_id, object_store_version_id, byte_length, content_sha256
  ) ON DELETE RESTRICT
);

CREATE TABLE old_mike_production_private.authority_registry (
  registry_kind text NOT NULL CHECK (registry_kind IN ('PROMPT','SCHEMA','MODEL','EVAL','PROVIDER_CONFIG','PRIVACY','RETENTION')),
  authority_id old_mike_production_private.authority_id NOT NULL,
  version integer NOT NULL CHECK (version > 0),
  authority_hash old_mike_production_private.sha256_hex NOT NULL,
  approval_event_hash old_mike_production_private.sha256_hex NOT NULL,
  review_class text,
  created_at timestamptz NOT NULL DEFAULT pg_catalog.statement_timestamp(),
  PRIMARY KEY (registry_kind, authority_id, version),
  UNIQUE (registry_kind, authority_id, version, authority_hash, approval_event_hash),
  CHECK ((registry_kind = 'EVAL' AND review_class IS NOT NULL AND char_length(review_class) BETWEEN 1 AND 80)
      OR (registry_kind <> 'EVAL' AND review_class IS NULL))
);

CREATE TABLE old_mike_production_private.registry_status_events (
  registry_kind text NOT NULL,
  authority_id old_mike_production_private.authority_id NOT NULL,
  version integer NOT NULL,
  authority_hash old_mike_production_private.sha256_hex NOT NULL,
  approval_event_hash old_mike_production_private.sha256_hex NOT NULL,
  sequence integer NOT NULL CHECK (sequence IN (1, 2)),
  status text NOT NULL CHECK (status IN ('APPROVED', 'RETIRED')),
  predecessor_event_hash old_mike_production_private.sha256_hex,
  event_hash old_mike_production_private.sha256_hex NOT NULL,
  actor_user_id text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT pg_catalog.statement_timestamp(),
  PRIMARY KEY (registry_kind, authority_id, version, sequence),
  UNIQUE (event_hash),
  UNIQUE (registry_kind, authority_id, version, authority_hash, approval_event_hash, status),
  CONSTRAINT registry_status_events_registry_fk FOREIGN KEY (
    registry_kind, authority_id, version, authority_hash, approval_event_hash
  ) REFERENCES old_mike_production_private.authority_registry(
    registry_kind, authority_id, version, authority_hash, approval_event_hash
  ) ON DELETE RESTRICT,
  CONSTRAINT registry_status_events_actor_fk FOREIGN KEY (actor_user_id)
    REFERENCES public."user"(id) ON DELETE RESTRICT,
  CHECK ((sequence = 1 AND status = 'APPROVED' AND predecessor_event_hash IS NULL AND event_hash = approval_event_hash)
      OR (sequence = 2 AND status = 'RETIRED' AND predecessor_event_hash = approval_event_hash))
);

CREATE TABLE old_mike_production_private.ai_jobs (
  workspace_id text NOT NULL,
  project_id text NOT NULL,
  job_id old_mike_production_private.authority_id NOT NULL,
  stage_id old_mike_production_private.authority_id NOT NULL,
  effect_lineage_hash old_mike_production_private.sha256_hex NOT NULL,
  operation text NOT NULL CHECK (operation IN ('GENERATE_DURABLE_CORE', 'REGENERATE_EXPLICIT_NEW_EFFECT')),
  request_id old_mike_production_private.authority_id NOT NULL,
  idempotency_key old_mike_production_private.authority_id NOT NULL,
  request_hash old_mike_production_private.sha256_hex NOT NULL,
  base_revision bigint NOT NULL CHECK (base_revision >= 0),
  base_content_hash old_mike_production_private.sha256_hex NOT NULL,
  operation_identity_hash old_mike_production_private.sha256_hex NOT NULL,
  actor_user_id text NOT NULL,
  source_bundle_id old_mike_production_private.authority_id NOT NULL,
  source_bundle_version integer NOT NULL CHECK (source_bundle_version > 0),
  source_bundle_hash old_mike_production_private.sha256_hex NOT NULL,
  prompt_kind text NOT NULL DEFAULT 'PROMPT' CHECK (prompt_kind = 'PROMPT'),
  prompt_id old_mike_production_private.authority_id NOT NULL,
  prompt_version integer NOT NULL CHECK (prompt_version > 0),
  prompt_hash old_mike_production_private.sha256_hex NOT NULL,
  prompt_approval_event_hash old_mike_production_private.sha256_hex NOT NULL,
  schema_kind text NOT NULL DEFAULT 'SCHEMA' CHECK (schema_kind = 'SCHEMA'),
  output_schema_id old_mike_production_private.authority_id NOT NULL,
  output_schema_version integer NOT NULL CHECK (output_schema_version > 0),
  output_schema_hash old_mike_production_private.sha256_hex NOT NULL,
  output_schema_approval_event_hash old_mike_production_private.sha256_hex NOT NULL,
  model_kind text NOT NULL DEFAULT 'MODEL' CHECK (model_kind = 'MODEL'),
  model_id old_mike_production_private.authority_id NOT NULL,
  model_version integer NOT NULL CHECK (model_version > 0),
  model_hash old_mike_production_private.sha256_hex NOT NULL,
  model_approval_event_hash old_mike_production_private.sha256_hex NOT NULL,
  eval_kind text NOT NULL DEFAULT 'EVAL' CHECK (eval_kind = 'EVAL'),
  eval_id old_mike_production_private.authority_id NOT NULL,
  eval_version integer NOT NULL CHECK (eval_version > 0),
  eval_hash old_mike_production_private.sha256_hex NOT NULL,
  eval_approval_event_hash old_mike_production_private.sha256_hex NOT NULL,
  eval_review_class text NOT NULL,
  provider_config_kind text NOT NULL DEFAULT 'PROVIDER_CONFIG' CHECK (provider_config_kind = 'PROVIDER_CONFIG'),
  provider_config_id old_mike_production_private.authority_id NOT NULL,
  provider_config_version integer NOT NULL CHECK (provider_config_version > 0),
  provider_config_hash old_mike_production_private.sha256_hex NOT NULL,
  provider_config_approval_event_hash old_mike_production_private.sha256_hex NOT NULL,
  privacy_kind text NOT NULL DEFAULT 'PRIVACY' CHECK (privacy_kind = 'PRIVACY'),
  privacy_id old_mike_production_private.authority_id NOT NULL,
  privacy_version integer NOT NULL CHECK (privacy_version > 0),
  privacy_hash old_mike_production_private.sha256_hex NOT NULL,
  privacy_approval_event_hash old_mike_production_private.sha256_hex NOT NULL,
  retention_kind text NOT NULL DEFAULT 'RETENTION' CHECK (retention_kind = 'RETENTION'),
  retention_id old_mike_production_private.authority_id NOT NULL,
  retention_version integer NOT NULL CHECK (retention_version > 0),
  retention_hash old_mike_production_private.sha256_hex NOT NULL,
  retention_approval_event_hash old_mike_production_private.sha256_hex NOT NULL,
  state text NOT NULL DEFAULT 'QUEUED' CHECK (state IN (
    'QUEUED','LEASED','SUBMITTING','ACCEPTED','COMPLETION_UNKNOWN','SUCCEEDED',
    'TERMINAL_REJECTED','FAILED_PRE_SUBMISSION','PROVEN_NOT_SUBMITTED','CANCELLED_PRE_SUBMISSION'
  )),
  provider_submission_count integer NOT NULL DEFAULT 0 CHECK (provider_submission_count BETWEEN 0 AND 1),
  lease_generation bigint NOT NULL DEFAULT 0 CHECK (lease_generation >= 0),
  lease_owner_hash old_mike_production_private.sha256_hex,
  lease_expires_at timestamptz,
  submitted_at timestamptz,
  accepted_at timestamptz,
  terminal_at timestamptz,
  terminal_outcome_hash old_mike_production_private.sha256_hex,
  created_at timestamptz NOT NULL DEFAULT pg_catalog.statement_timestamp(),
  updated_at timestamptz NOT NULL DEFAULT pg_catalog.statement_timestamp(),
  PRIMARY KEY (workspace_id, project_id, job_id),
  UNIQUE (workspace_id, project_id, effect_lineage_hash),
  UNIQUE (workspace_id, project_id, job_id, effect_lineage_hash),
  UNIQUE (workspace_id, project_id, idempotency_key),
  UNIQUE (workspace_id, project_id, request_id),
  UNIQUE (
    workspace_id, project_id, job_id, request_hash, operation_identity_hash,
    source_bundle_hash, provider_config_hash
  ),
  CONSTRAINT ai_jobs_project_fk FOREIGN KEY (workspace_id, project_id)
    REFERENCES public.projects(workspace_id, project_id) ON DELETE RESTRICT,
  CONSTRAINT ai_jobs_actor_fk FOREIGN KEY (actor_user_id)
    REFERENCES public."user"(id) ON DELETE RESTRICT,
  CONSTRAINT ai_jobs_snapshot_fk FOREIGN KEY (workspace_id, project_id, base_revision, base_content_hash)
    REFERENCES old_mike_production_private.project_snapshots(workspace_id, project_id, revision, content_hash) ON DELETE RESTRICT,
  CONSTRAINT ai_jobs_operation_intent_fk FOREIGN KEY (
    workspace_id, project_id, operation, request_id, idempotency_key,
    request_hash, base_revision, base_content_hash, operation_identity_hash
  ) REFERENCES old_mike_production_private.operation_intents(
    workspace_id, project_id, operation, request_id, idempotency_key,
    request_hash, base_revision, base_content_hash, operation_identity_hash
  ) DEFERRABLE INITIALLY DEFERRED,
  CONSTRAINT ai_jobs_source_bundle_fk FOREIGN KEY (
    workspace_id, project_id, source_bundle_id, source_bundle_version, source_bundle_hash
  ) REFERENCES old_mike_production_private.source_bundles(
    workspace_id, project_id, source_bundle_id, version, bundle_hash
  ) ON DELETE RESTRICT,
  CONSTRAINT ai_jobs_prompt_fk FOREIGN KEY (prompt_kind, prompt_id, prompt_version, prompt_hash, prompt_approval_event_hash)
    REFERENCES old_mike_production_private.authority_registry(registry_kind, authority_id, version, authority_hash, approval_event_hash),
  CONSTRAINT ai_jobs_schema_fk FOREIGN KEY (schema_kind, output_schema_id, output_schema_version, output_schema_hash, output_schema_approval_event_hash)
    REFERENCES old_mike_production_private.authority_registry(registry_kind, authority_id, version, authority_hash, approval_event_hash),
  CONSTRAINT ai_jobs_model_fk FOREIGN KEY (model_kind, model_id, model_version, model_hash, model_approval_event_hash)
    REFERENCES old_mike_production_private.authority_registry(registry_kind, authority_id, version, authority_hash, approval_event_hash),
  CONSTRAINT ai_jobs_eval_fk FOREIGN KEY (eval_kind, eval_id, eval_version, eval_hash, eval_approval_event_hash)
    REFERENCES old_mike_production_private.authority_registry(registry_kind, authority_id, version, authority_hash, approval_event_hash),
  CONSTRAINT ai_jobs_provider_config_fk FOREIGN KEY (provider_config_kind, provider_config_id, provider_config_version, provider_config_hash, provider_config_approval_event_hash)
    REFERENCES old_mike_production_private.authority_registry(registry_kind, authority_id, version, authority_hash, approval_event_hash),
  CONSTRAINT ai_jobs_privacy_fk FOREIGN KEY (privacy_kind, privacy_id, privacy_version, privacy_hash, privacy_approval_event_hash)
    REFERENCES old_mike_production_private.authority_registry(registry_kind, authority_id, version, authority_hash, approval_event_hash),
  CONSTRAINT ai_jobs_retention_fk FOREIGN KEY (retention_kind, retention_id, retention_version, retention_hash, retention_approval_event_hash)
    REFERENCES old_mike_production_private.authority_registry(registry_kind, authority_id, version, authority_hash, approval_event_hash),
  CHECK ((lease_owner_hash IS NULL) = (lease_expires_at IS NULL)),
  CHECK (
    (state IN ('QUEUED','LEASED','FAILED_PRE_SUBMISSION','CANCELLED_PRE_SUBMISSION')
      AND provider_submission_count = 0 AND submitted_at IS NULL AND accepted_at IS NULL)
    OR
    (state IN ('SUBMITTING','COMPLETION_UNKNOWN','PROVEN_NOT_SUBMITTED','TERMINAL_REJECTED','SUCCEEDED')
      AND provider_submission_count = 1 AND submitted_at IS NOT NULL)
    OR
    (state = 'ACCEPTED' AND provider_submission_count = 1 AND submitted_at IS NOT NULL AND accepted_at IS NOT NULL)
  ),
  CHECK ((state IN ('SUCCEEDED','TERMINAL_REJECTED','FAILED_PRE_SUBMISSION','PROVEN_NOT_SUBMITTED','CANCELLED_PRE_SUBMISSION'))
      = (terminal_at IS NOT NULL AND terminal_outcome_hash IS NOT NULL))
);

ALTER TABLE old_mike_production_private.operation_intents
  ADD CONSTRAINT operation_intents_job_fk
  FOREIGN KEY (workspace_id, project_id, job_id)
  REFERENCES old_mike_production_private.ai_jobs(workspace_id, project_id, job_id)
  DEFERRABLE INITIALLY DEFERRED;

CREATE TABLE old_mike_production_private.project_events (
  workspace_id text NOT NULL,
  project_id text NOT NULL,
  event_id old_mike_production_private.authority_id NOT NULL,
  sequence bigint NOT NULL CHECK (sequence > 0),
  predecessor_event_hash old_mike_production_private.sha256_hex,
  event_hash old_mike_production_private.sha256_hex NOT NULL,
  operation text NOT NULL,
  request_id old_mike_production_private.authority_id NOT NULL,
  idempotency_key old_mike_production_private.authority_id NOT NULL,
  request_hash old_mike_production_private.sha256_hex NOT NULL,
  base_revision bigint NOT NULL CHECK (base_revision >= 0),
  base_content_hash old_mike_production_private.sha256_hex NOT NULL,
  operation_identity_hash old_mike_production_private.sha256_hex NOT NULL,
  snapshot_revision bigint NOT NULL CHECK (snapshot_revision >= 0),
  snapshot_content_hash old_mike_production_private.sha256_hex NOT NULL,
  job_id old_mike_production_private.authority_id NOT NULL,
  event_kind text NOT NULL CHECK (event_kind IN (
    'GENERATION_COMPLETE','GENERATION_UNKNOWN','GENERATION_REJECTED',
    'GENERATION_PROVEN_NOT_SUBMITTED','RECONCILIATION_COMPLETE','RECONCILIATION_REJECTED'
  )),
  response_authority_hash old_mike_production_private.sha256_hex NOT NULL,
  created_at timestamptz NOT NULL DEFAULT pg_catalog.statement_timestamp(),
  PRIMARY KEY (workspace_id, project_id, event_id),
  UNIQUE (workspace_id, project_id, sequence),
  UNIQUE (workspace_id, project_id, event_hash),
  UNIQUE (workspace_id, project_id, operation_identity_hash, event_kind),
  CONSTRAINT project_events_project_fk FOREIGN KEY (workspace_id, project_id)
    REFERENCES public.projects(workspace_id, project_id) ON DELETE RESTRICT,
  CONSTRAINT project_events_snapshot_fk FOREIGN KEY (workspace_id, project_id, snapshot_revision, snapshot_content_hash)
    REFERENCES old_mike_production_private.project_snapshots(workspace_id, project_id, revision, content_hash) ON DELETE RESTRICT,
  CONSTRAINT project_events_intent_fk FOREIGN KEY (
    workspace_id, project_id, operation, request_id, idempotency_key,
    request_hash, base_revision, base_content_hash, operation_identity_hash
  ) REFERENCES old_mike_production_private.operation_intents(
    workspace_id, project_id, operation, request_id, idempotency_key,
    request_hash, base_revision, base_content_hash, operation_identity_hash
  ) ON DELETE RESTRICT,
  CONSTRAINT project_events_job_fk FOREIGN KEY (workspace_id, project_id, job_id)
    REFERENCES old_mike_production_private.ai_jobs(workspace_id, project_id, job_id) ON DELETE RESTRICT,
  CHECK ((sequence = 1 AND predecessor_event_hash IS NULL) OR sequence > 1)
);

ALTER TABLE old_mike_production_private.project_snapshots
  ADD CONSTRAINT project_snapshots_source_job_fk
  FOREIGN KEY (workspace_id, project_id, source_job_id)
  REFERENCES old_mike_production_private.ai_jobs(workspace_id, project_id, job_id)
  DEFERRABLE INITIALLY DEFERRED;

ALTER TABLE old_mike_production_private.operation_intents
  ADD CONSTRAINT operation_intents_committed_snapshot_fk
  FOREIGN KEY (workspace_id, project_id, committed_revision, committed_content_hash)
  REFERENCES old_mike_production_private.project_snapshots(workspace_id, project_id, revision, content_hash)
  DEFERRABLE INITIALLY DEFERRED;

ALTER TABLE old_mike_production_private.operation_intents
  ADD CONSTRAINT operation_intents_committed_event_fk
  FOREIGN KEY (workspace_id, project_id, committed_event_id)
  REFERENCES old_mike_production_private.project_events(workspace_id, project_id, event_id)
  DEFERRABLE INITIALLY DEFERRED;

CREATE TABLE old_mike_production_private.ai_outbox (
  workspace_id text NOT NULL,
  project_id text NOT NULL,
  outbox_id old_mike_production_private.authority_id NOT NULL,
  kind text NOT NULL CHECK (kind IN ('AI_JOB_READY','RECONCILIATION_DUE')),
  job_id old_mike_production_private.authority_id NOT NULL,
  effect_lineage_hash old_mike_production_private.sha256_hex NOT NULL,
  schema_version text NOT NULL,
  payload jsonb NOT NULL,
  payload_hash old_mike_production_private.sha256_hex NOT NULL,
  state text NOT NULL DEFAULT 'PENDING' CHECK (state IN ('PENDING','LEASED','PUBLISHED')),
  lease_generation bigint NOT NULL DEFAULT 0 CHECK (lease_generation >= 0),
  lease_owner_hash old_mike_production_private.sha256_hex,
  lease_expires_at timestamptz,
  published_message_id_hash old_mike_production_private.sha256_hex,
  published_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT pg_catalog.statement_timestamp(),
  PRIMARY KEY (workspace_id, project_id, outbox_id),
  UNIQUE (workspace_id, project_id, kind, job_id),
  CONSTRAINT ai_outbox_job_fk FOREIGN KEY (workspace_id, project_id, job_id, effect_lineage_hash)
    REFERENCES old_mike_production_private.ai_jobs(workspace_id, project_id, job_id, effect_lineage_hash) ON DELETE RESTRICT,
  CHECK (payload_hash = old_mike_production_private.canonical_json_hash(payload)),
  CHECK ((lease_owner_hash IS NULL) = (lease_expires_at IS NULL)),
  CHECK ((state = 'PUBLISHED') = (published_message_id_hash IS NOT NULL AND published_at IS NOT NULL))
);

CREATE TABLE old_mike_production_private.provider_attempts (
  workspace_id text NOT NULL,
  project_id text NOT NULL,
  job_id old_mike_production_private.authority_id NOT NULL,
  attempt_no integer NOT NULL CHECK (attempt_no = 1),
  provider_class text NOT NULL CHECK (provider_class IN ('DETERMINISTIC_FAKE','OPENAI_RESPONSES','OPENCLAW')),
  provider_request_id old_mike_production_private.authority_id NOT NULL,
  request_hash old_mike_production_private.sha256_hex NOT NULL,
  request_authority_hash old_mike_production_private.sha256_hex NOT NULL,
  external_ledger_key_hash old_mike_production_private.sha256_hex NOT NULL,
  external_ledger_commitment_hash old_mike_production_private.sha256_hex NOT NULL,
  operation_identity_hash old_mike_production_private.sha256_hex NOT NULL,
  source_bundle_hash old_mike_production_private.sha256_hex NOT NULL,
  provider_config_hash old_mike_production_private.sha256_hex NOT NULL,
  state text NOT NULL DEFAULT 'PREPARED' CHECK (state IN (
    'PREPARED','MAY_HAVE_SUBMITTED','ACCEPTED','COMPLETION_UNKNOWN','SUCCEEDED','TERMINAL_REJECTED','PROVEN_NOT_SUBMITTED'
  )),
  prepared_at timestamptz NOT NULL DEFAULT pg_catalog.statement_timestamp(),
  io_started_at timestamptz,
  accepted_at timestamptz,
  terminal_at timestamptz,
  terminal_result_hash old_mike_production_private.sha256_hex,
  terminal_rejection_hash old_mike_production_private.sha256_hex,
  terminal_non_submission_proof_hash old_mike_production_private.sha256_hex,
  PRIMARY KEY (workspace_id, project_id, job_id, attempt_no),
  UNIQUE (
    workspace_id, project_id, job_id, attempt_no, provider_class,
    provider_request_id, request_hash, request_authority_hash,
    external_ledger_key_hash, external_ledger_commitment_hash
  ),
  CONSTRAINT provider_attempts_job_fk FOREIGN KEY (
    workspace_id, project_id, job_id, request_hash, operation_identity_hash,
    source_bundle_hash, provider_config_hash
  ) REFERENCES old_mike_production_private.ai_jobs(
    workspace_id, project_id, job_id, request_hash, operation_identity_hash,
    source_bundle_hash, provider_config_hash
  ) ON DELETE RESTRICT,
  CHECK ((state = 'PREPARED' AND io_started_at IS NULL)
      OR (state <> 'PREPARED' AND io_started_at IS NOT NULL)),
  CHECK ((state IN ('SUCCEEDED','TERMINAL_REJECTED','PROVEN_NOT_SUBMITTED'))
      = (terminal_at IS NOT NULL)),
  CHECK ((state = 'SUCCEEDED') = (terminal_result_hash IS NOT NULL)),
  CHECK ((state = 'TERMINAL_REJECTED') = (terminal_rejection_hash IS NOT NULL)),
  CHECK ((state = 'PROVEN_NOT_SUBMITTED') = (terminal_non_submission_proof_hash IS NOT NULL))
);

CREATE TABLE old_mike_production_private.provider_receipts (
  workspace_id text NOT NULL,
  project_id text NOT NULL,
  job_id old_mike_production_private.authority_id NOT NULL,
  attempt_no integer NOT NULL,
  provider_class text NOT NULL,
  provider_request_id old_mike_production_private.authority_id NOT NULL,
  request_hash old_mike_production_private.sha256_hex NOT NULL,
  request_authority_hash old_mike_production_private.sha256_hex NOT NULL,
  external_ledger_key_hash old_mike_production_private.sha256_hex NOT NULL,
  external_ledger_commitment_hash old_mike_production_private.sha256_hex NOT NULL,
  sequence integer NOT NULL CHECK (sequence > 0),
  receipt_kind text NOT NULL CHECK (receipt_kind IN (
    'SUBMISSION_STARTED','SUBMISSION_ACCEPTED','COMPLETION_OBSERVED',
    'TERMINAL_REJECTED','COMPLETION_UNKNOWN','PROVEN_NOT_SUBMITTED'
  )),
  predecessor_receipt_hash old_mike_production_private.sha256_hex,
  evidence_hash old_mike_production_private.sha256_hex NOT NULL,
  result_hash old_mike_production_private.sha256_hex,
  rejection_authority_hash old_mike_production_private.sha256_hex,
  non_submission_proof_hash old_mike_production_private.sha256_hex,
  sanitized_code text,
  receipt_hash old_mike_production_private.sha256_hex NOT NULL,
  observed_at timestamptz NOT NULL DEFAULT pg_catalog.statement_timestamp(),
  PRIMARY KEY (workspace_id, project_id, job_id, attempt_no, sequence),
  UNIQUE (workspace_id, project_id, receipt_hash),
  CONSTRAINT provider_receipts_attempt_fk FOREIGN KEY (
    workspace_id, project_id, job_id, attempt_no, provider_class,
    provider_request_id, request_hash, request_authority_hash,
    external_ledger_key_hash, external_ledger_commitment_hash
  ) REFERENCES old_mike_production_private.provider_attempts(
    workspace_id, project_id, job_id, attempt_no, provider_class,
    provider_request_id, request_hash, request_authority_hash,
    external_ledger_key_hash, external_ledger_commitment_hash
  ) ON DELETE RESTRICT,
  CHECK ((sequence = 1 AND predecessor_receipt_hash IS NULL) OR sequence > 1),
  CHECK (
    (receipt_kind = 'SUBMISSION_STARTED' AND result_hash IS NULL AND rejection_authority_hash IS NULL
      AND non_submission_proof_hash IS NULL AND sanitized_code IS NULL)
    OR
    (receipt_kind = 'SUBMISSION_ACCEPTED' AND result_hash IS NULL AND rejection_authority_hash IS NULL
      AND non_submission_proof_hash IS NULL AND sanitized_code IS NULL)
    OR
    (receipt_kind = 'COMPLETION_OBSERVED' AND result_hash IS NOT NULL AND rejection_authority_hash IS NULL
      AND non_submission_proof_hash IS NULL AND sanitized_code IS NULL)
    OR
    (receipt_kind = 'TERMINAL_REJECTED' AND result_hash IS NULL AND rejection_authority_hash IS NOT NULL
      AND non_submission_proof_hash IS NULL AND sanitized_code ~ '^[A-Z0-9_]{3,80}$')
    OR
    (receipt_kind = 'COMPLETION_UNKNOWN' AND result_hash IS NULL AND rejection_authority_hash IS NULL
      AND non_submission_proof_hash IS NULL AND sanitized_code ~ '^[A-Z0-9_]{3,80}$')
    OR
    (receipt_kind = 'PROVEN_NOT_SUBMITTED' AND result_hash IS NULL AND rejection_authority_hash IS NULL
      AND non_submission_proof_hash IS NOT NULL AND sanitized_code ~ '^[A-Z0-9_]{3,80}$')
  )
);

CREATE TABLE old_mike_production_private.provider_lookup_receipts (
  workspace_id text NOT NULL,
  project_id text NOT NULL,
  job_id old_mike_production_private.authority_id NOT NULL,
  attempt_no integer NOT NULL,
  provider_class text NOT NULL,
  provider_request_id old_mike_production_private.authority_id NOT NULL,
  request_hash old_mike_production_private.sha256_hex NOT NULL,
  request_authority_hash old_mike_production_private.sha256_hex NOT NULL,
  external_ledger_key_hash old_mike_production_private.sha256_hex NOT NULL,
  external_ledger_commitment_hash old_mike_production_private.sha256_hex NOT NULL,
  lookup_receipt_id old_mike_production_private.authority_id NOT NULL,
  lookup_outcome text NOT NULL CHECK (lookup_outcome IN ('NOT_FOUND','PENDING','COMPLETE','TERMINAL_REJECTED','UNKNOWN')),
  result_hash old_mike_production_private.sha256_hex,
  rejection_authority_hash old_mike_production_private.sha256_hex,
  lookup_authority_hash old_mike_production_private.sha256_hex NOT NULL,
  observed_at timestamptz NOT NULL DEFAULT pg_catalog.statement_timestamp(),
  PRIMARY KEY (workspace_id, project_id, lookup_receipt_id),
  UNIQUE (
    workspace_id, project_id, job_id, attempt_no, provider_class, provider_request_id,
    request_hash, request_authority_hash, external_ledger_key_hash,
    external_ledger_commitment_hash, lookup_receipt_id, lookup_outcome,
    result_hash, rejection_authority_hash, lookup_authority_hash
  ),
  CONSTRAINT provider_lookup_receipts_attempt_fk FOREIGN KEY (
    workspace_id, project_id, job_id, attempt_no, provider_class,
    provider_request_id, request_hash, request_authority_hash,
    external_ledger_key_hash, external_ledger_commitment_hash
  ) REFERENCES old_mike_production_private.provider_attempts(
    workspace_id, project_id, job_id, attempt_no, provider_class,
    provider_request_id, request_hash, request_authority_hash,
    external_ledger_key_hash, external_ledger_commitment_hash
  ) ON DELETE RESTRICT,
  CHECK ((lookup_outcome = 'COMPLETE' AND result_hash IS NOT NULL AND rejection_authority_hash IS NULL)
      OR (lookup_outcome = 'TERMINAL_REJECTED' AND result_hash IS NULL AND rejection_authority_hash IS NOT NULL)
      OR (lookup_outcome IN ('NOT_FOUND','PENDING','UNKNOWN') AND result_hash IS NULL AND rejection_authority_hash IS NULL))
);

CREATE TABLE old_mike_production_private.webhook_inbox (
  workspace_id text NOT NULL,
  project_id text NOT NULL,
  webhook_id old_mike_production_private.authority_id NOT NULL,
  job_id old_mike_production_private.authority_id NOT NULL,
  attempt_no integer NOT NULL,
  provider_class text NOT NULL,
  provider_request_id old_mike_production_private.authority_id NOT NULL,
  request_hash old_mike_production_private.sha256_hex NOT NULL,
  request_authority_hash old_mike_production_private.sha256_hex NOT NULL,
  external_ledger_key_hash old_mike_production_private.sha256_hex NOT NULL,
  external_ledger_commitment_hash old_mike_production_private.sha256_hex NOT NULL,
  provider_event_id old_mike_production_private.authority_id NOT NULL,
  key_version old_mike_production_private.authority_id NOT NULL,
  raw_body_byte_length bigint NOT NULL CHECK (raw_body_byte_length > 0),
  raw_body_hash old_mike_production_private.sha256_hex NOT NULL,
  body_object_id old_mike_production_private.authority_id NOT NULL,
  body_object_version_id old_mike_production_private.authority_id NOT NULL,
  body_object_key_hash old_mike_production_private.sha256_hex NOT NULL,
  storage_receipt_hash old_mike_production_private.sha256_hex NOT NULL,
  signature_authority_hash old_mike_production_private.sha256_hex NOT NULL,
  validation_state text NOT NULL CHECK (validation_state IN ('VALID','INVALID')),
  outcome text NOT NULL CHECK (outcome IN ('PENDING','UNKNOWN','COMPLETE','TERMINAL_REJECTED')),
  result_hash old_mike_production_private.sha256_hex,
  rejection_authority_hash old_mike_production_private.sha256_hex,
  state text NOT NULL DEFAULT 'RECEIVED' CHECK (state IN ('RECEIVED','LEASED','APPLIED','BLOCKED')),
  lease_generation bigint NOT NULL DEFAULT 0 CHECK (lease_generation >= 0),
  lease_owner_hash old_mike_production_private.sha256_hex,
  lease_expires_at timestamptz,
  applied_observation_id old_mike_production_private.authority_id,
  received_at timestamptz NOT NULL DEFAULT pg_catalog.statement_timestamp(),
  terminal_at timestamptz,
  PRIMARY KEY (workspace_id, project_id, webhook_id),
  UNIQUE (provider_class, provider_event_id, key_version, raw_body_hash),
  UNIQUE (
    workspace_id, project_id, webhook_id, job_id, attempt_no, provider_class,
    provider_request_id, request_hash, request_authority_hash,
    external_ledger_key_hash, external_ledger_commitment_hash, provider_event_id,
    key_version, raw_body_hash, body_object_id, body_object_version_id,
    body_object_key_hash, storage_receipt_hash, signature_authority_hash, validation_state,
    outcome, result_hash, rejection_authority_hash
  ),
  CONSTRAINT webhook_inbox_project_fk FOREIGN KEY (workspace_id, project_id)
    REFERENCES public.projects(workspace_id, project_id) ON DELETE RESTRICT,
  CONSTRAINT webhook_inbox_attempt_fk FOREIGN KEY (
    workspace_id, project_id, job_id, attempt_no, provider_class,
    provider_request_id, request_hash, request_authority_hash,
    external_ledger_key_hash, external_ledger_commitment_hash
  ) REFERENCES old_mike_production_private.provider_attempts(
    workspace_id, project_id, job_id, attempt_no, provider_class,
    provider_request_id, request_hash, request_authority_hash,
    external_ledger_key_hash, external_ledger_commitment_hash
  ) ON DELETE RESTRICT,
  CHECK ((lease_owner_hash IS NULL) = (lease_expires_at IS NULL)),
  CHECK ((state IN ('APPLIED','BLOCKED')) = (terminal_at IS NOT NULL)),
  CHECK ((outcome = 'COMPLETE' AND result_hash IS NOT NULL AND rejection_authority_hash IS NULL)
      OR (outcome = 'TERMINAL_REJECTED' AND result_hash IS NULL AND rejection_authority_hash IS NOT NULL)
      OR (outcome IN ('PENDING','UNKNOWN') AND result_hash IS NULL AND rejection_authority_hash IS NULL))
);

CREATE TABLE old_mike_production_private.human_reconciliation_authorities (
  workspace_id text NOT NULL,
  project_id text NOT NULL,
  human_authority_id old_mike_production_private.authority_id NOT NULL,
  job_id old_mike_production_private.authority_id NOT NULL,
  attempt_no integer NOT NULL,
  provider_class text NOT NULL,
  provider_request_id old_mike_production_private.authority_id NOT NULL,
  request_hash old_mike_production_private.sha256_hex NOT NULL,
  request_authority_hash old_mike_production_private.sha256_hex NOT NULL,
  external_ledger_key_hash old_mike_production_private.sha256_hex NOT NULL,
  external_ledger_commitment_hash old_mike_production_private.sha256_hex NOT NULL,
  actor_user_id text NOT NULL,
  membership_authority_hash old_mike_production_private.sha256_hex NOT NULL,
  authorization_scope_hash old_mike_production_private.sha256_hex NOT NULL,
  authorization_policy_hash old_mike_production_private.sha256_hex NOT NULL,
  outcome text NOT NULL CHECK (outcome IN ('COMPLETE','TERMINAL_REJECTED')),
  result_hash old_mike_production_private.sha256_hex,
  rejection_authority_hash old_mike_production_private.sha256_hex,
  decision_hash old_mike_production_private.sha256_hex NOT NULL,
  decided_at timestamptz NOT NULL DEFAULT pg_catalog.statement_timestamp(),
  PRIMARY KEY (workspace_id, project_id, human_authority_id),
  UNIQUE (
    workspace_id, project_id, job_id, attempt_no, provider_class, provider_request_id,
    request_hash, request_authority_hash, external_ledger_key_hash,
    external_ledger_commitment_hash, human_authority_id, outcome,
    result_hash, rejection_authority_hash, decision_hash
  ),
  CONSTRAINT human_reconciliation_attempt_fk FOREIGN KEY (
    workspace_id, project_id, job_id, attempt_no, provider_class,
    provider_request_id, request_hash, request_authority_hash,
    external_ledger_key_hash, external_ledger_commitment_hash
  ) REFERENCES old_mike_production_private.provider_attempts(
    workspace_id, project_id, job_id, attempt_no, provider_class,
    provider_request_id, request_hash, request_authority_hash,
    external_ledger_key_hash, external_ledger_commitment_hash
  ) ON DELETE RESTRICT,
  CONSTRAINT human_reconciliation_actor_fk FOREIGN KEY (actor_user_id)
    REFERENCES public."user"(id) ON DELETE RESTRICT,
  CHECK ((outcome = 'COMPLETE' AND result_hash IS NOT NULL AND rejection_authority_hash IS NULL)
      OR (outcome = 'TERMINAL_REJECTED' AND result_hash IS NULL AND rejection_authority_hash IS NOT NULL))
);

CREATE TABLE old_mike_production_private.reconciliation_observations (
  workspace_id text NOT NULL,
  project_id text NOT NULL,
  observation_id old_mike_production_private.authority_id NOT NULL,
  job_id old_mike_production_private.authority_id NOT NULL,
  attempt_no integer NOT NULL,
  provider_class text NOT NULL,
  provider_request_id old_mike_production_private.authority_id NOT NULL,
  request_hash old_mike_production_private.sha256_hex NOT NULL,
  request_authority_hash old_mike_production_private.sha256_hex NOT NULL,
  external_ledger_key_hash old_mike_production_private.sha256_hex NOT NULL,
  external_ledger_commitment_hash old_mike_production_private.sha256_hex NOT NULL,
  method text NOT NULL CHECK (method IN ('LOOKUP','SIGNED_WEBHOOK','AUTHORIZED_HUMAN')),
  lookup_receipt_id old_mike_production_private.authority_id,
  webhook_id old_mike_production_private.authority_id,
  human_authority_id old_mike_production_private.authority_id,
  outcome text NOT NULL CHECK (outcome IN ('PENDING','UNKNOWN','COMPLETE','TERMINAL_REJECTED')),
  result_hash old_mike_production_private.sha256_hex,
  rejection_authority_hash old_mike_production_private.sha256_hex,
  observation_hash old_mike_production_private.sha256_hex NOT NULL,
  observed_at timestamptz NOT NULL DEFAULT pg_catalog.statement_timestamp(),
  PRIMARY KEY (workspace_id, project_id, observation_id),
  UNIQUE (workspace_id, project_id, job_id, attempt_no, observation_hash),
  CONSTRAINT reconciliation_observations_attempt_fk FOREIGN KEY (
    workspace_id, project_id, job_id, attempt_no, provider_class,
    provider_request_id, request_hash, request_authority_hash,
    external_ledger_key_hash, external_ledger_commitment_hash
  ) REFERENCES old_mike_production_private.provider_attempts(
    workspace_id, project_id, job_id, attempt_no, provider_class,
    provider_request_id, request_hash, request_authority_hash,
    external_ledger_key_hash, external_ledger_commitment_hash
  ) ON DELETE RESTRICT,
  CONSTRAINT reconciliation_observations_lookup_fk FOREIGN KEY (workspace_id, project_id, lookup_receipt_id)
    REFERENCES old_mike_production_private.provider_lookup_receipts(workspace_id, project_id, lookup_receipt_id) ON DELETE RESTRICT,
  CONSTRAINT reconciliation_observations_webhook_fk FOREIGN KEY (workspace_id, project_id, webhook_id)
    REFERENCES old_mike_production_private.webhook_inbox(workspace_id, project_id, webhook_id) ON DELETE RESTRICT,
  CONSTRAINT reconciliation_observations_human_fk FOREIGN KEY (workspace_id, project_id, human_authority_id)
    REFERENCES old_mike_production_private.human_reconciliation_authorities(workspace_id, project_id, human_authority_id) ON DELETE RESTRICT,
  CHECK ((method = 'LOOKUP' AND lookup_receipt_id IS NOT NULL AND webhook_id IS NULL AND human_authority_id IS NULL)
      OR (method = 'SIGNED_WEBHOOK' AND lookup_receipt_id IS NULL AND webhook_id IS NOT NULL AND human_authority_id IS NULL)
      OR (method = 'AUTHORIZED_HUMAN' AND lookup_receipt_id IS NULL AND webhook_id IS NULL AND human_authority_id IS NOT NULL)),
  CHECK ((outcome = 'COMPLETE' AND result_hash IS NOT NULL AND rejection_authority_hash IS NULL)
      OR (outcome = 'TERMINAL_REJECTED' AND result_hash IS NULL AND rejection_authority_hash IS NOT NULL)
      OR (outcome IN ('PENDING','UNKNOWN') AND result_hash IS NULL AND rejection_authority_hash IS NULL))
);

CREATE TABLE old_mike_production_private.budget_reservations (
  workspace_id text NOT NULL,
  project_id text NOT NULL,
  reservation_id old_mike_production_private.authority_id NOT NULL,
  job_id old_mike_production_private.authority_id NOT NULL,
  currency text NOT NULL CHECK (currency ~ '^[A-Z]{3}$'),
  unit text NOT NULL CHECK (unit IN ('TOKEN','MILLIUNIT','REQUEST')),
  policy_id old_mike_production_private.authority_id NOT NULL,
  policy_version integer NOT NULL CHECK (policy_version > 0),
  policy_hash old_mike_production_private.sha256_hex NOT NULL,
  reserved_units bigint NOT NULL CHECK (reserved_units > 0),
  reserved_cost_minor bigint NOT NULL CHECK (reserved_cost_minor >= 0),
  expires_at timestamptz NOT NULL,
  created_at timestamptz NOT NULL DEFAULT pg_catalog.statement_timestamp(),
  PRIMARY KEY (workspace_id, project_id, reservation_id),
  UNIQUE (workspace_id, project_id, job_id, currency, unit, policy_id, policy_version, policy_hash),
  CONSTRAINT budget_reservations_job_fk FOREIGN KEY (workspace_id, project_id, job_id)
    REFERENCES old_mike_production_private.ai_jobs(workspace_id, project_id, job_id) ON DELETE RESTRICT
);

CREATE TABLE old_mike_production_private.usage_ledger (
  workspace_id text NOT NULL,
  project_id text NOT NULL,
  usage_id old_mike_production_private.authority_id NOT NULL,
  reservation_id old_mike_production_private.authority_id NOT NULL,
  job_id old_mike_production_private.authority_id NOT NULL,
  attempt_no integer NOT NULL,
  provider_class text NOT NULL,
  provider_request_id old_mike_production_private.authority_id NOT NULL,
  request_hash old_mike_production_private.sha256_hex NOT NULL,
  request_authority_hash old_mike_production_private.sha256_hex NOT NULL,
  external_ledger_key_hash old_mike_production_private.sha256_hex NOT NULL,
  external_ledger_commitment_hash old_mike_production_private.sha256_hex NOT NULL,
  currency text NOT NULL,
  unit text NOT NULL,
  policy_id old_mike_production_private.authority_id NOT NULL,
  policy_version integer NOT NULL,
  policy_hash old_mike_production_private.sha256_hex NOT NULL,
  consumed_units bigint NOT NULL CHECK (consumed_units >= 0),
  cost_minor bigint NOT NULL CHECK (cost_minor >= 0),
  provider_usage_receipt_hash old_mike_production_private.sha256_hex NOT NULL,
  created_at timestamptz NOT NULL DEFAULT pg_catalog.statement_timestamp(),
  PRIMARY KEY (workspace_id, project_id, usage_id),
  UNIQUE (workspace_id, project_id, provider_usage_receipt_hash),
  CONSTRAINT usage_ledger_reservation_fk FOREIGN KEY (
    workspace_id, project_id, reservation_id
  ) REFERENCES old_mike_production_private.budget_reservations(
    workspace_id, project_id, reservation_id
  ) ON DELETE RESTRICT,
  CONSTRAINT usage_ledger_attempt_fk FOREIGN KEY (
    workspace_id, project_id, job_id, attempt_no, provider_class,
    provider_request_id, request_hash, request_authority_hash,
    external_ledger_key_hash, external_ledger_commitment_hash
  ) REFERENCES old_mike_production_private.provider_attempts(
    workspace_id, project_id, job_id, attempt_no, provider_class,
    provider_request_id, request_hash, request_authority_hash,
    external_ledger_key_hash, external_ledger_commitment_hash
  ) ON DELETE RESTRICT,
  CONSTRAINT usage_ledger_reservation_tuple_fk FOREIGN KEY (
    workspace_id, project_id, job_id, currency, unit, policy_id, policy_version, policy_hash
  ) REFERENCES old_mike_production_private.budget_reservations(
    workspace_id, project_id, job_id, currency, unit, policy_id, policy_version, policy_hash
  ) ON DELETE RESTRICT
);

CREATE TABLE old_mike_production_private.human_gate_requests (
  workspace_id text NOT NULL,
  tenant_id text NOT NULL,
  project_id text NOT NULL,
  gate_request_id old_mike_production_private.authority_id NOT NULL,
  snapshot_revision bigint NOT NULL CHECK (snapshot_revision >= 0),
  snapshot_content_hash old_mike_production_private.sha256_hex NOT NULL,
  actor_user_id text NOT NULL,
  operation text NOT NULL,
  schema_version text NOT NULL,
  authority_payload jsonb NOT NULL,
  authority_payload_hash old_mike_production_private.sha256_hex NOT NULL,
  created_at timestamptz NOT NULL DEFAULT pg_catalog.statement_timestamp(),
  PRIMARY KEY (workspace_id, project_id, gate_request_id),
  UNIQUE (workspace_id, tenant_id, project_id, gate_request_id),
  UNIQUE (
    workspace_id, tenant_id, project_id, gate_request_id, snapshot_revision,
    snapshot_content_hash, actor_user_id, operation, schema_version,
    authority_payload_hash
  ),
  CONSTRAINT human_gate_requests_project_fk FOREIGN KEY (workspace_id, project_id)
    REFERENCES public.projects(workspace_id, project_id) ON DELETE RESTRICT,
  CONSTRAINT human_gate_requests_snapshot_fk FOREIGN KEY (workspace_id, project_id, snapshot_revision, snapshot_content_hash)
    REFERENCES old_mike_production_private.project_snapshots(workspace_id, project_id, revision, content_hash) ON DELETE RESTRICT,
  CONSTRAINT human_gate_requests_actor_fk FOREIGN KEY (actor_user_id)
    REFERENCES public."user"(id) ON DELETE RESTRICT,
  CHECK (tenant_id = workspace_id),
  CHECK (authority_payload_hash = old_mike_production_private.canonical_json_hash(authority_payload))
);

CREATE TABLE old_mike_production_private.human_gate_decisions (
  workspace_id text NOT NULL,
  tenant_id text NOT NULL,
  project_id text NOT NULL,
  gate_request_id old_mike_production_private.authority_id NOT NULL,
  decision text NOT NULL CHECK (decision IN ('CONFIRMED','REJECTED')),
  decision_actor_user_id text NOT NULL,
  decision_hash old_mike_production_private.sha256_hex NOT NULL,
  decided_at timestamptz NOT NULL DEFAULT pg_catalog.statement_timestamp(),
  PRIMARY KEY (workspace_id, project_id, gate_request_id),
  UNIQUE (workspace_id, project_id, gate_request_id, decision_hash),
  UNIQUE (workspace_id, project_id, decision_hash),
  CONSTRAINT human_gate_decisions_request_fk FOREIGN KEY (
    workspace_id, tenant_id, project_id, gate_request_id
  ) REFERENCES old_mike_production_private.human_gate_requests(
    workspace_id, tenant_id, project_id, gate_request_id
  ) ON DELETE RESTRICT,
  CONSTRAINT human_gate_decisions_actor_fk FOREIGN KEY (decision_actor_user_id)
    REFERENCES public."user"(id) ON DELETE RESTRICT,
  CHECK (tenant_id = workspace_id)
);

CREATE TABLE old_mike_production_private.formal_effect_authorizations (
  workspace_id text NOT NULL,
  tenant_id text NOT NULL,
  project_id text NOT NULL,
  formal_effect_id old_mike_production_private.authority_id NOT NULL,
  gate_request_id old_mike_production_private.authority_id NOT NULL,
  gate_decision_hash old_mike_production_private.sha256_hex NOT NULL,
  snapshot_revision bigint NOT NULL,
  snapshot_content_hash old_mike_production_private.sha256_hex NOT NULL,
  gate_request_actor_user_id text NOT NULL,
  gate_request_schema_version text NOT NULL,
  gate_request_payload_hash old_mike_production_private.sha256_hex NOT NULL,
  actor_user_id text NOT NULL,
  operation text NOT NULL,
  schema_version text NOT NULL,
  authority_payload jsonb NOT NULL,
  authority_payload_hash old_mike_production_private.sha256_hex NOT NULL,
  authorization_hash old_mike_production_private.sha256_hex NOT NULL,
  authorized_at timestamptz NOT NULL DEFAULT pg_catalog.statement_timestamp(),
  PRIMARY KEY (workspace_id, project_id, formal_effect_id),
  UNIQUE (workspace_id, project_id, gate_request_id),
  UNIQUE (workspace_id, project_id, formal_effect_id, authorization_hash),
  CONSTRAINT formal_effect_authorizations_gate_fk FOREIGN KEY (
    workspace_id, project_id, gate_request_id, gate_decision_hash
  ) REFERENCES old_mike_production_private.human_gate_decisions(
    workspace_id, project_id, gate_request_id, decision_hash
  ) ON DELETE RESTRICT,
  CONSTRAINT formal_effect_authorizations_request_fk FOREIGN KEY (
    workspace_id, tenant_id, project_id, gate_request_id,
    snapshot_revision, snapshot_content_hash, gate_request_actor_user_id, operation,
    gate_request_schema_version, gate_request_payload_hash
  ) REFERENCES old_mike_production_private.human_gate_requests(
    workspace_id, tenant_id, project_id, gate_request_id,
    snapshot_revision, snapshot_content_hash, actor_user_id, operation,
    schema_version, authority_payload_hash
  ) ON DELETE RESTRICT,
  CONSTRAINT formal_effect_authorizations_actor_fk FOREIGN KEY (actor_user_id)
    REFERENCES public."user"(id) ON DELETE RESTRICT,
  CHECK (tenant_id = workspace_id),
  CHECK (authority_payload_hash = old_mike_production_private.canonical_json_hash(authority_payload))
);

CREATE TABLE old_mike_production_private.formal_effect_terminal_events (
  workspace_id text NOT NULL,
  project_id text NOT NULL,
  formal_effect_id old_mike_production_private.authority_id NOT NULL,
  authorization_hash old_mike_production_private.sha256_hex NOT NULL,
  outcome text NOT NULL CHECK (outcome IN ('EXECUTED','REVOKED_BEFORE_EXECUTION')),
  actor_user_id text NOT NULL,
  terminal_authority_hash old_mike_production_private.sha256_hex NOT NULL,
  occurred_at timestamptz NOT NULL DEFAULT pg_catalog.statement_timestamp(),
  PRIMARY KEY (workspace_id, project_id, formal_effect_id),
  UNIQUE (workspace_id, project_id, terminal_authority_hash),
  CONSTRAINT formal_effect_terminal_authorization_fk FOREIGN KEY (
    workspace_id, project_id, formal_effect_id, authorization_hash
  ) REFERENCES old_mike_production_private.formal_effect_authorizations(
    workspace_id, project_id, formal_effect_id, authorization_hash
  ) ON DELETE RESTRICT,
  CONSTRAINT formal_effect_terminal_actor_fk FOREIGN KEY (actor_user_id)
    REFERENCES public."user"(id) ON DELETE RESTRICT
);

CREATE TABLE old_mike_production_private.dispatch_outbox (
  workspace_id text NOT NULL,
  project_id text NOT NULL,
  dispatch_id old_mike_production_private.authority_id NOT NULL,
  formal_effect_id old_mike_production_private.authority_id NOT NULL,
  authorization_hash old_mike_production_private.sha256_hex NOT NULL,
  kind text NOT NULL CHECK (kind = 'FORMAL_EFFECT_READY'),
  schema_version text NOT NULL,
  payload jsonb NOT NULL,
  payload_hash old_mike_production_private.sha256_hex NOT NULL,
  state text NOT NULL DEFAULT 'PENDING' CHECK (state IN ('PENDING','LEASED','PUBLISHED')),
  lease_generation bigint NOT NULL DEFAULT 0 CHECK (lease_generation >= 0),
  lease_owner_hash old_mike_production_private.sha256_hex,
  lease_expires_at timestamptz,
  published_message_id_hash old_mike_production_private.sha256_hex,
  published_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT pg_catalog.statement_timestamp(),
  PRIMARY KEY (workspace_id, project_id, dispatch_id),
  UNIQUE (workspace_id, project_id, formal_effect_id),
  CONSTRAINT dispatch_outbox_authorization_fk FOREIGN KEY (
    workspace_id, project_id, formal_effect_id, authorization_hash
  ) REFERENCES old_mike_production_private.formal_effect_authorizations(
    workspace_id, project_id, formal_effect_id, authorization_hash
  ) ON DELETE RESTRICT,
  CHECK (payload_hash = old_mike_production_private.canonical_json_hash(payload)),
  CHECK ((lease_owner_hash IS NULL) = (lease_expires_at IS NULL)),
  CHECK ((state = 'PUBLISHED') = (published_message_id_hash IS NOT NULL AND published_at IS NOT NULL))
);

CREATE VIEW old_mike_production_private.observer_job_metrics
WITH (security_barrier = true)
AS
SELECT state, pg_catalog.count(*)::bigint AS job_count,
       pg_catalog.max(updated_at) AS latest_state_at
  FROM old_mike_production_private.ai_jobs
 GROUP BY state;

CREATE VIEW old_mike_production_private.observer_queue_metrics
WITH (security_barrier = true)
AS
SELECT kind, state, pg_catalog.count(*)::bigint AS message_count,
       pg_catalog.max(created_at) AS latest_created_at
  FROM old_mike_production_private.ai_outbox
 GROUP BY kind, state;

CREATE VIEW old_mike_production_private.observer_usage_metrics
WITH (security_barrier = true)
AS
SELECT currency, unit, pg_catalog.count(*)::bigint AS receipt_count,
       pg_catalog.sum(consumed_units)::numeric AS consumed_units,
       pg_catalog.sum(cost_minor)::numeric AS cost_minor
  FROM old_mike_production_private.usage_ledger
 GROUP BY currency, unit;

CREATE FUNCTION old_mike_production_private.reject_append_only_mutation()
RETURNS trigger
LANGUAGE plpgsql
SET search_path = pg_catalog
AS $function$
BEGIN
  RAISE EXCEPTION 'm1a_c1_append_only_record';
END
$function$;

CREATE FUNCTION old_mike_production_private.guard_registry_status_insert()
RETURNS trigger
LANGUAGE plpgsql
SET search_path = pg_catalog
AS $function$
DECLARE
  previous old_mike_production_private.registry_status_events%ROWTYPE;
BEGIN
  IF NEW.sequence = 1 THEN
    IF EXISTS (
      SELECT 1 FROM old_mike_production_private.registry_status_events event_row
       WHERE event_row.registry_kind = NEW.registry_kind
         AND event_row.authority_id = NEW.authority_id
         AND event_row.version = NEW.version
    ) THEN
      RAISE EXCEPTION 'm1a_c1_registry_second_approval_forbidden';
    END IF;
  ELSE
    SELECT * INTO previous
      FROM old_mike_production_private.registry_status_events event_row
     WHERE event_row.registry_kind = NEW.registry_kind
       AND event_row.authority_id = NEW.authority_id
       AND event_row.version = NEW.version
       AND event_row.sequence = 1
     FOR SHARE;
    IF NOT FOUND OR previous.status <> 'APPROVED'
       OR previous.event_hash <> NEW.predecessor_event_hash THEN
      RAISE EXCEPTION 'm1a_c1_registry_retirement_predecessor_invalid';
    END IF;
    IF EXISTS (
      SELECT 1 FROM old_mike_production_private.registry_status_events event_row
       WHERE event_row.registry_kind = NEW.registry_kind
         AND event_row.authority_id = NEW.authority_id
         AND event_row.version = NEW.version
         AND event_row.sequence = 2
    ) THEN
      RAISE EXCEPTION 'm1a_c1_registry_post_retirement_event_forbidden';
    END IF;
  END IF;
  RETURN NEW;
END
$function$;

CREATE FUNCTION old_mike_production_private.guard_operation_intent_mutation()
RETURNS trigger
LANGUAGE plpgsql
SET search_path = pg_catalog
AS $function$
BEGIN
  IF (pg_catalog.to_jsonb(OLD) - ARRAY[
        'status','committed_revision','committed_content_hash','committed_event_id',
        'committed_response_hash','terminal_at'
      ]) IS DISTINCT FROM
     (pg_catalog.to_jsonb(NEW) - ARRAY[
        'status','committed_revision','committed_content_hash','committed_event_id',
        'committed_response_hash','terminal_at'
      ]) THEN
    RAISE EXCEPTION 'm1a_c1_operation_identity_immutable';
  END IF;
  IF OLD.status <> 'PENDING' OR NEW.status NOT IN ('COMMITTED','CONFLICTED') THEN
    RAISE EXCEPTION 'm1a_c1_operation_transition_invalid';
  END IF;
  RETURN NEW;
END
$function$;

CREATE FUNCTION old_mike_production_private.guard_job_mutation()
RETURNS trigger
LANGUAGE plpgsql
SET search_path = pg_catalog
AS $function$
DECLARE
  transition text := OLD.state || '->' || NEW.state;
BEGIN
  IF (pg_catalog.to_jsonb(OLD) - ARRAY[
        'state','provider_submission_count','lease_generation','lease_owner_hash',
        'lease_expires_at','submitted_at','accepted_at','terminal_at',
        'terminal_outcome_hash','updated_at'
      ]) IS DISTINCT FROM
     (pg_catalog.to_jsonb(NEW) - ARRAY[
        'state','provider_submission_count','lease_generation','lease_owner_hash',
        'lease_expires_at','submitted_at','accepted_at','terminal_at',
        'terminal_outcome_hash','updated_at'
      ]) THEN
    RAISE EXCEPTION 'm1a_c1_job_identity_immutable';
  END IF;
  IF transition NOT IN (
    'QUEUED->LEASED', 'QUEUED->FAILED_PRE_SUBMISSION', 'QUEUED->CANCELLED_PRE_SUBMISSION',
    'LEASED->LEASED', 'LEASED->SUBMITTING', 'LEASED->FAILED_PRE_SUBMISSION',
    'SUBMITTING->ACCEPTED', 'SUBMITTING->COMPLETION_UNKNOWN',
    'SUBMITTING->SUCCEEDED', 'SUBMITTING->TERMINAL_REJECTED',
    'SUBMITTING->PROVEN_NOT_SUBMITTED',
    'ACCEPTED->COMPLETION_UNKNOWN', 'ACCEPTED->SUCCEEDED', 'ACCEPTED->TERMINAL_REJECTED',
    'COMPLETION_UNKNOWN->COMPLETION_UNKNOWN', 'COMPLETION_UNKNOWN->SUCCEEDED',
    'COMPLETION_UNKNOWN->TERMINAL_REJECTED'
  ) THEN
    RAISE EXCEPTION 'm1a_c1_job_transition_invalid:%', transition;
  END IF;
  IF NEW.provider_submission_count < OLD.provider_submission_count
     OR NEW.provider_submission_count > 1 THEN
    RAISE EXCEPTION 'm1a_c1_provider_submission_count_invalid';
  END IF;
  IF transition = 'QUEUED->LEASED' AND NEW.lease_generation <> OLD.lease_generation + 1 THEN
    RAISE EXCEPTION 'm1a_c1_job_lease_generation_invalid';
  END IF;
  IF transition = 'LEASED->LEASED' AND (
    OLD.lease_expires_at IS NULL OR OLD.lease_expires_at > pg_catalog.statement_timestamp()
    OR NEW.lease_generation <> OLD.lease_generation + 1
  ) THEN
    RAISE EXCEPTION 'm1a_c1_live_job_lease_theft';
  END IF;
  RETURN NEW;
END
$function$;

CREATE FUNCTION old_mike_production_private.guard_attempt_mutation()
RETURNS trigger
LANGUAGE plpgsql
SET search_path = pg_catalog
AS $function$
DECLARE
  transition text := OLD.state || '->' || NEW.state;
BEGIN
  IF (pg_catalog.to_jsonb(OLD) - ARRAY[
        'state','io_started_at','accepted_at','terminal_at','terminal_result_hash',
        'terminal_rejection_hash','terminal_non_submission_proof_hash'
      ]) IS DISTINCT FROM
     (pg_catalog.to_jsonb(NEW) - ARRAY[
        'state','io_started_at','accepted_at','terminal_at','terminal_result_hash',
        'terminal_rejection_hash','terminal_non_submission_proof_hash'
      ]) THEN
    RAISE EXCEPTION 'm1a_c1_attempt_identity_immutable';
  END IF;
  IF transition NOT IN (
    'PREPARED->MAY_HAVE_SUBMITTED',
    'MAY_HAVE_SUBMITTED->ACCEPTED','MAY_HAVE_SUBMITTED->COMPLETION_UNKNOWN',
    'MAY_HAVE_SUBMITTED->SUCCEEDED','MAY_HAVE_SUBMITTED->TERMINAL_REJECTED',
    'MAY_HAVE_SUBMITTED->PROVEN_NOT_SUBMITTED',
    'ACCEPTED->COMPLETION_UNKNOWN','ACCEPTED->SUCCEEDED','ACCEPTED->TERMINAL_REJECTED',
    'COMPLETION_UNKNOWN->COMPLETION_UNKNOWN','COMPLETION_UNKNOWN->SUCCEEDED',
    'COMPLETION_UNKNOWN->TERMINAL_REJECTED'
  ) THEN
    RAISE EXCEPTION 'm1a_c1_attempt_transition_invalid:%', transition;
  END IF;
  RETURN NEW;
END
$function$;

CREATE FUNCTION old_mike_production_private.guard_leased_message_mutation()
RETURNS trigger
LANGUAGE plpgsql
SET search_path = pg_catalog
AS $function$
DECLARE
  transition text := OLD.state || '->' || NEW.state;
BEGIN
  IF (pg_catalog.to_jsonb(OLD) - ARRAY[
        'state','lease_generation','lease_owner_hash','lease_expires_at',
        'published_message_id_hash','published_at'
      ]) IS DISTINCT FROM
     (pg_catalog.to_jsonb(NEW) - ARRAY[
        'state','lease_generation','lease_owner_hash','lease_expires_at',
        'published_message_id_hash','published_at'
      ]) THEN
    RAISE EXCEPTION 'm1a_c1_outbox_identity_immutable';
  END IF;
  IF transition NOT IN ('PENDING->LEASED','LEASED->LEASED','LEASED->PUBLISHED') THEN
    RAISE EXCEPTION 'm1a_c1_outbox_transition_invalid:%', transition;
  END IF;
  IF transition IN ('PENDING->LEASED','LEASED->LEASED')
     AND NEW.lease_generation <> OLD.lease_generation + 1 THEN
    RAISE EXCEPTION 'm1a_c1_outbox_generation_invalid';
  END IF;
  IF transition = 'LEASED->LEASED'
     AND (OLD.lease_expires_at IS NULL OR OLD.lease_expires_at > pg_catalog.statement_timestamp()) THEN
    RAISE EXCEPTION 'm1a_c1_live_outbox_lease_theft';
  END IF;
  RETURN NEW;
END
$function$;

CREATE FUNCTION old_mike_production_private.guard_webhook_mutation()
RETURNS trigger
LANGUAGE plpgsql
SET search_path = pg_catalog
AS $function$
DECLARE
  transition text := OLD.state || '->' || NEW.state;
BEGIN
  IF (pg_catalog.to_jsonb(OLD) - ARRAY[
        'state','lease_generation','lease_owner_hash','lease_expires_at',
        'applied_observation_id','terminal_at'
      ]) IS DISTINCT FROM
     (pg_catalog.to_jsonb(NEW) - ARRAY[
        'state','lease_generation','lease_owner_hash','lease_expires_at',
        'applied_observation_id','terminal_at'
      ]) THEN
    RAISE EXCEPTION 'm1a_c1_webhook_identity_immutable';
  END IF;
  IF transition NOT IN ('RECEIVED->LEASED','LEASED->LEASED','LEASED->APPLIED','LEASED->BLOCKED') THEN
    RAISE EXCEPTION 'm1a_c1_webhook_transition_invalid:%', transition;
  END IF;
  IF transition IN ('RECEIVED->LEASED','LEASED->LEASED')
     AND NEW.lease_generation <> OLD.lease_generation + 1 THEN
    RAISE EXCEPTION 'm1a_c1_webhook_generation_invalid';
  END IF;
  IF transition = 'LEASED->LEASED'
     AND (OLD.lease_expires_at IS NULL OR OLD.lease_expires_at > pg_catalog.statement_timestamp()) THEN
    RAISE EXCEPTION 'm1a_c1_live_webhook_lease_theft';
  END IF;
  RETURN NEW;
END
$function$;

CREATE TRIGGER migration_authority_append_only
  BEFORE UPDATE OR DELETE ON old_mike_production_private.migration_authority
  FOR EACH ROW EXECUTE FUNCTION old_mike_production_private.reject_append_only_mutation();
CREATE TRIGGER project_snapshots_append_only
  BEFORE UPDATE OR DELETE ON old_mike_production_private.project_snapshots
  FOR EACH ROW EXECUTE FUNCTION old_mike_production_private.reject_append_only_mutation();
CREATE TRIGGER project_events_append_only
  BEFORE UPDATE OR DELETE ON old_mike_production_private.project_events
  FOR EACH ROW EXECUTE FUNCTION old_mike_production_private.reject_append_only_mutation();
CREATE TRIGGER source_objects_append_only
  BEFORE UPDATE OR DELETE ON old_mike_production_private.source_objects
  FOR EACH ROW EXECUTE FUNCTION old_mike_production_private.reject_append_only_mutation();
CREATE TRIGGER source_bundles_append_only
  BEFORE UPDATE OR DELETE ON old_mike_production_private.source_bundles
  FOR EACH ROW EXECUTE FUNCTION old_mike_production_private.reject_append_only_mutation();
CREATE TRIGGER source_bundle_members_append_only
  BEFORE UPDATE OR DELETE ON old_mike_production_private.source_bundle_members
  FOR EACH ROW EXECUTE FUNCTION old_mike_production_private.reject_append_only_mutation();
CREATE TRIGGER authority_registry_append_only
  BEFORE UPDATE OR DELETE ON old_mike_production_private.authority_registry
  FOR EACH ROW EXECUTE FUNCTION old_mike_production_private.reject_append_only_mutation();
CREATE TRIGGER registry_status_events_append_only
  BEFORE UPDATE OR DELETE ON old_mike_production_private.registry_status_events
  FOR EACH ROW EXECUTE FUNCTION old_mike_production_private.reject_append_only_mutation();
CREATE TRIGGER registry_status_events_insert_guard
  BEFORE INSERT ON old_mike_production_private.registry_status_events
  FOR EACH ROW EXECUTE FUNCTION old_mike_production_private.guard_registry_status_insert();
CREATE TRIGGER operation_intents_guard
  BEFORE UPDATE ON old_mike_production_private.operation_intents
  FOR EACH ROW EXECUTE FUNCTION old_mike_production_private.guard_operation_intent_mutation();
CREATE TRIGGER operation_intents_delete_guard
  BEFORE DELETE ON old_mike_production_private.operation_intents
  FOR EACH ROW EXECUTE FUNCTION old_mike_production_private.reject_append_only_mutation();
CREATE TRIGGER ai_jobs_guard
  BEFORE UPDATE ON old_mike_production_private.ai_jobs
  FOR EACH ROW EXECUTE FUNCTION old_mike_production_private.guard_job_mutation();
CREATE TRIGGER ai_jobs_delete_guard
  BEFORE DELETE ON old_mike_production_private.ai_jobs
  FOR EACH ROW EXECUTE FUNCTION old_mike_production_private.reject_append_only_mutation();
CREATE TRIGGER ai_outbox_guard
  BEFORE UPDATE ON old_mike_production_private.ai_outbox
  FOR EACH ROW EXECUTE FUNCTION old_mike_production_private.guard_leased_message_mutation();
CREATE TRIGGER ai_outbox_delete_guard
  BEFORE DELETE ON old_mike_production_private.ai_outbox
  FOR EACH ROW EXECUTE FUNCTION old_mike_production_private.reject_append_only_mutation();
CREATE TRIGGER provider_attempts_guard
  BEFORE UPDATE ON old_mike_production_private.provider_attempts
  FOR EACH ROW EXECUTE FUNCTION old_mike_production_private.guard_attempt_mutation();
CREATE TRIGGER provider_attempts_delete_guard
  BEFORE DELETE ON old_mike_production_private.provider_attempts
  FOR EACH ROW EXECUTE FUNCTION old_mike_production_private.reject_append_only_mutation();
CREATE TRIGGER provider_receipts_append_only
  BEFORE UPDATE OR DELETE ON old_mike_production_private.provider_receipts
  FOR EACH ROW EXECUTE FUNCTION old_mike_production_private.reject_append_only_mutation();
CREATE TRIGGER provider_lookup_receipts_append_only
  BEFORE UPDATE OR DELETE ON old_mike_production_private.provider_lookup_receipts
  FOR EACH ROW EXECUTE FUNCTION old_mike_production_private.reject_append_only_mutation();
CREATE TRIGGER webhook_inbox_guard
  BEFORE UPDATE ON old_mike_production_private.webhook_inbox
  FOR EACH ROW EXECUTE FUNCTION old_mike_production_private.guard_webhook_mutation();
CREATE TRIGGER webhook_inbox_delete_guard
  BEFORE DELETE ON old_mike_production_private.webhook_inbox
  FOR EACH ROW EXECUTE FUNCTION old_mike_production_private.reject_append_only_mutation();
CREATE TRIGGER human_reconciliation_authorities_append_only
  BEFORE UPDATE OR DELETE ON old_mike_production_private.human_reconciliation_authorities
  FOR EACH ROW EXECUTE FUNCTION old_mike_production_private.reject_append_only_mutation();
CREATE TRIGGER reconciliation_observations_append_only
  BEFORE UPDATE OR DELETE ON old_mike_production_private.reconciliation_observations
  FOR EACH ROW EXECUTE FUNCTION old_mike_production_private.reject_append_only_mutation();
CREATE TRIGGER budget_reservations_append_only
  BEFORE UPDATE OR DELETE ON old_mike_production_private.budget_reservations
  FOR EACH ROW EXECUTE FUNCTION old_mike_production_private.reject_append_only_mutation();
CREATE TRIGGER usage_ledger_append_only
  BEFORE UPDATE OR DELETE ON old_mike_production_private.usage_ledger
  FOR EACH ROW EXECUTE FUNCTION old_mike_production_private.reject_append_only_mutation();
CREATE TRIGGER human_gate_requests_append_only
  BEFORE UPDATE OR DELETE ON old_mike_production_private.human_gate_requests
  FOR EACH ROW EXECUTE FUNCTION old_mike_production_private.reject_append_only_mutation();
CREATE TRIGGER human_gate_decisions_append_only
  BEFORE UPDATE OR DELETE ON old_mike_production_private.human_gate_decisions
  FOR EACH ROW EXECUTE FUNCTION old_mike_production_private.reject_append_only_mutation();
CREATE TRIGGER formal_effect_authorizations_append_only
  BEFORE UPDATE OR DELETE ON old_mike_production_private.formal_effect_authorizations
  FOR EACH ROW EXECUTE FUNCTION old_mike_production_private.reject_append_only_mutation();
CREATE TRIGGER formal_effect_terminal_events_append_only
  BEFORE UPDATE OR DELETE ON old_mike_production_private.formal_effect_terminal_events
  FOR EACH ROW EXECUTE FUNCTION old_mike_production_private.reject_append_only_mutation();
CREATE TRIGGER dispatch_outbox_guard
  BEFORE UPDATE ON old_mike_production_private.dispatch_outbox
  FOR EACH ROW EXECUTE FUNCTION old_mike_production_private.guard_leased_message_mutation();
CREATE TRIGGER dispatch_outbox_delete_guard
  BEFORE DELETE ON old_mike_production_private.dispatch_outbox
  FOR EACH ROW EXECUTE FUNCTION old_mike_production_private.reject_append_only_mutation();

CREATE FUNCTION old_mike_production_private.compute_source_bundle_hash(
  p_workspace_id text,
  p_project_id text,
  p_source_bundle_id text,
  p_bundle_version integer
)
RETURNS TABLE(member_count bigint, minimum_ordinal integer, maximum_ordinal integer, bundle_hash text)
LANGUAGE sql
STABLE
STRICT
SET search_path = pg_catalog
AS $function$
  SELECT
    pg_catalog.count(*)::bigint,
    pg_catalog.min(member_row.ordinal),
    pg_catalog.max(member_row.ordinal),
    pg_catalog.encode(
      pg_catalog.sha256(
        COALESCE(
          pg_catalog.string_agg(
            pg_catalog.convert_to(member_row.ordinal::text, 'UTF8')
            || pg_catalog.decode('00','hex')
            || pg_catalog.convert_to(member_row.source_object_id, 'UTF8')
            || pg_catalog.decode('00','hex')
            || pg_catalog.convert_to(member_row.object_store_version_id, 'UTF8')
            || pg_catalog.decode('00','hex')
            || pg_catalog.convert_to(member_row.byte_length::text, 'UTF8')
            || pg_catalog.decode('00','hex')
            || pg_catalog.convert_to(member_row.content_sha256::text, 'UTF8')
            || pg_catalog.decode('0a','hex'),
            ''::bytea ORDER BY member_row.ordinal
          ),
          ''::bytea
        )
      ),
      'hex'
    )
  FROM old_mike_production_private.source_bundle_members member_row
  WHERE member_row.workspace_id = p_workspace_id
    AND member_row.project_id = p_project_id
    AND member_row.source_bundle_id = p_source_bundle_id
    AND member_row.bundle_version = p_bundle_version
$function$;

CREATE FUNCTION old_mike_production_private.assert_registry_approved(
  p_kind text,
  p_authority_id text,
  p_version integer,
  p_authority_hash text,
  p_approval_event_hash text,
  p_review_class text DEFAULT NULL
)
RETURNS void
LANGUAGE plpgsql
STABLE
SET search_path = pg_catalog
AS $function$
DECLARE
  latest_status text;
  registry_review_class text;
BEGIN
  SELECT registry_row.review_class
    INTO registry_review_class
    FROM old_mike_production_private.authority_registry registry_row
   WHERE registry_row.registry_kind = p_kind
     AND registry_row.authority_id = p_authority_id
     AND registry_row.version = p_version
     AND registry_row.authority_hash = p_authority_hash
     AND registry_row.approval_event_hash = p_approval_event_hash;
  IF NOT FOUND OR registry_review_class IS DISTINCT FROM p_review_class THEN
    RAISE EXCEPTION 'm1a_c1_registry_tuple_invalid:%', p_kind;
  END IF;
  SELECT event_row.status INTO latest_status
    FROM old_mike_production_private.registry_status_events event_row
   WHERE event_row.registry_kind = p_kind
     AND event_row.authority_id = p_authority_id
     AND event_row.version = p_version
   ORDER BY event_row.sequence DESC
   LIMIT 1;
  IF latest_status IS DISTINCT FROM 'APPROVED' THEN
    RAISE EXCEPTION 'm1a_c1_registry_not_approved:%', p_kind;
  END IF;
END
$function$;

CREATE FUNCTION old_mike_production_private.bootstrap_project_snapshot(
  p_workspace_id text,
  p_project_id text,
  p_actor_user_id text,
  p_request_id text,
  p_idempotency_key text,
  p_request_hash text,
  p_schema_version text,
  p_content_hash text,
  p_payload jsonb,
  p_payload_hash text
)
RETURNS TABLE(revision bigint, content_hash text)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog
AS $function$
DECLARE
  expected_payload jsonb;
  expected_content_hash text;
BEGIN
  PERFORM old_mike_production_private.assert_active_member(p_workspace_id, p_project_id, p_actor_user_id);
  PERFORM 1 FROM public.projects project_row
   WHERE project_row.workspace_id = p_workspace_id AND project_row.project_id = p_project_id
   FOR UPDATE;
  expected_payload := pg_catalog.jsonb_build_object(
    'actorUserId', p_actor_user_id,
    'idempotencyKey', p_idempotency_key,
    'operation', 'BOOTSTRAP_PROJECT_SNAPSHOT',
    'projectId', p_project_id,
    'requestHash', p_request_hash,
    'requestId', p_request_id,
    'schemaVersion', p_schema_version,
    'workspaceId', p_workspace_id
  );
  PERFORM old_mike_production_private.assert_exact_payload(p_payload, expected_payload, p_payload_hash);
  expected_content_hash := old_mike_production_private.hash_parts(
    p_workspace_id, p_project_id, '0', p_schema_version, p_payload_hash
  );
  IF p_content_hash <> expected_content_hash THEN
    RAISE EXCEPTION 'm1a_c1_bootstrap_content_hash_invalid';
  END IF;
  IF EXISTS (
    SELECT 1 FROM old_mike_production_private.project_snapshots snapshot_row
     WHERE snapshot_row.workspace_id = p_workspace_id AND snapshot_row.project_id = p_project_id
  ) THEN
    RETURN QUERY
      SELECT snapshot_row.revision, snapshot_row.content_hash::text
        FROM old_mike_production_private.project_snapshots snapshot_row
       WHERE snapshot_row.workspace_id = p_workspace_id AND snapshot_row.project_id = p_project_id
       ORDER BY snapshot_row.revision DESC LIMIT 1;
    RETURN;
  END IF;
  INSERT INTO old_mike_production_private.project_snapshots (
    workspace_id, project_id, revision, content_hash, predecessor_content_hash,
    operation, operation_identity_hash, request_id, idempotency_key, request_hash,
    actor_user_id, schema_version, authority_payload_hash, source_job_id
  ) VALUES (
    p_workspace_id, p_project_id, 0, p_content_hash, NULL,
    'BOOTSTRAP_PROJECT_SNAPSHOT',
    old_mike_production_private.hash_parts(
      p_workspace_id, p_project_id, 'BOOTSTRAP_PROJECT_SNAPSHOT', p_request_id,
      p_idempotency_key, p_request_hash, '0', p_content_hash
    ),
    p_request_id, p_idempotency_key, p_request_hash, p_actor_user_id,
    p_schema_version, p_payload_hash, NULL
  );
  RETURN QUERY SELECT 0::bigint, p_content_hash;
END
$function$;

CREATE FUNCTION old_mike_production_private.create_ai_job(
  p_workspace_id text,
  p_project_id text,
  p_actor_user_id text,
  p_job_id text,
  p_outbox_id text,
  p_stage_id text,
  p_operation text,
  p_request_id text,
  p_idempotency_key text,
  p_base_revision bigint,
  p_base_content_hash text,
  p_source_bundle_id text,
  p_source_bundle_version integer,
  p_source_bundle_hash text,
  p_prompt_id text,
  p_prompt_version integer,
  p_prompt_hash text,
  p_prompt_approval_event_hash text,
  p_output_schema_id text,
  p_output_schema_version integer,
  p_output_schema_hash text,
  p_output_schema_approval_event_hash text,
  p_model_id text,
  p_model_version integer,
  p_model_hash text,
  p_model_approval_event_hash text,
  p_eval_id text,
  p_eval_version integer,
  p_eval_hash text,
  p_eval_approval_event_hash text,
  p_eval_review_class text,
  p_provider_config_id text,
  p_provider_config_version integer,
  p_provider_config_hash text,
  p_provider_config_approval_event_hash text,
  p_privacy_id text,
  p_privacy_version integer,
  p_privacy_hash text,
  p_privacy_approval_event_hash text,
  p_retention_id text,
  p_retention_version integer,
  p_retention_hash text,
  p_retention_approval_event_hash text,
  p_effect_lineage_hash text,
  p_operation_identity_hash text,
  p_request_hash text,
  p_schema_version text,
  p_payload jsonb,
  p_payload_hash text
)
RETURNS TABLE(disposition text, job_id text, job_state text, outbox_id text)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog
AS $function$
DECLARE
  expected_payload jsonb;
  expected_operation_hash text;
  expected_effect_hash text;
  expected_request_hash text;
  bundle_row record;
  declared_bundle old_mike_production_private.source_bundles%ROWTYPE;
  existing old_mike_production_private.ai_jobs%ROWTYPE;
  outbox_payload jsonb;
BEGIN
  IF p_operation NOT IN ('GENERATE_DURABLE_CORE','REGENERATE_EXPLICIT_NEW_EFFECT') THEN
    RAISE EXCEPTION 'm1a_c1_operation_invalid';
  END IF;
  PERFORM old_mike_production_private.assert_active_member(p_workspace_id, p_project_id, p_actor_user_id);
  PERFORM 1 FROM public.projects project_row
   WHERE project_row.workspace_id = p_workspace_id AND project_row.project_id = p_project_id
   FOR UPDATE;

  expected_operation_hash := old_mike_production_private.hash_parts(
    p_workspace_id, p_project_id, p_operation, p_request_id, p_idempotency_key,
    p_request_hash, p_base_revision::text, p_base_content_hash
  );
  expected_effect_hash := old_mike_production_private.hash_parts(
    p_workspace_id, p_project_id, p_stage_id, p_base_revision::text, p_base_content_hash
  );
  IF p_operation_identity_hash <> expected_operation_hash
     OR p_effect_lineage_hash <> expected_effect_hash THEN
    RAISE EXCEPTION 'm1a_c1_operation_or_effect_identity_invalid';
  END IF;

  expected_payload := pg_catalog.jsonb_build_object(
    'actorUserId', p_actor_user_id,
    'baseContentHash', p_base_content_hash,
    'baseRevision', p_base_revision,
    'effectLineageHash', p_effect_lineage_hash,
    'evalAuthority', pg_catalog.jsonb_build_object('hash',p_eval_hash,'id',p_eval_id,'reviewClass',p_eval_review_class,'version',p_eval_version),
    'idempotencyKey', p_idempotency_key,
    'jobId', p_job_id,
    'modelAuthority', pg_catalog.jsonb_build_object('hash',p_model_hash,'id',p_model_id,'version',p_model_version),
    'operation', p_operation,
    'outputSchemaAuthority', pg_catalog.jsonb_build_object('hash',p_output_schema_hash,'id',p_output_schema_id,'version',p_output_schema_version),
    'privacyAuthority', pg_catalog.jsonb_build_object('hash',p_privacy_hash,'id',p_privacy_id,'version',p_privacy_version),
    'projectId', p_project_id,
    'promptAuthority', pg_catalog.jsonb_build_object('hash',p_prompt_hash,'id',p_prompt_id,'version',p_prompt_version),
    'providerConfigAuthority', pg_catalog.jsonb_build_object('hash',p_provider_config_hash,'id',p_provider_config_id,'version',p_provider_config_version),
    'requestId', p_request_id,
    'retentionAuthority', pg_catalog.jsonb_build_object('hash',p_retention_hash,'id',p_retention_id,'version',p_retention_version),
    'schemaVersion', p_schema_version,
    'sourceBundleHash', p_source_bundle_hash,
    'sourceBundleId', p_source_bundle_id,
    'sourceBundleVersion', p_source_bundle_version,
    'stageId', p_stage_id,
    'workspaceId', p_workspace_id
  );
  PERFORM old_mike_production_private.assert_exact_payload(p_payload, expected_payload, p_payload_hash);
  expected_request_hash := old_mike_production_private.hash_parts(p_operation, p_payload_hash);
  IF p_request_hash <> expected_request_hash THEN
    RAISE EXCEPTION 'm1a_c1_request_hash_invalid';
  END IF;

  SELECT snapshot_row.revision, snapshot_row.content_hash::text
    INTO STRICT bundle_row
    FROM old_mike_production_private.project_snapshots snapshot_row
   WHERE snapshot_row.workspace_id = p_workspace_id
     AND snapshot_row.project_id = p_project_id
   ORDER BY snapshot_row.revision DESC
   LIMIT 1;
  IF bundle_row.revision <> p_base_revision OR bundle_row.content_hash <> p_base_content_hash THEN
    RAISE EXCEPTION 'm1a_c1_stale_project_head';
  END IF;

  SELECT * INTO STRICT declared_bundle
    FROM old_mike_production_private.source_bundles source_bundle
   WHERE source_bundle.workspace_id = p_workspace_id
     AND source_bundle.project_id = p_project_id
     AND source_bundle.source_bundle_id = p_source_bundle_id
     AND source_bundle.version = p_source_bundle_version
   FOR SHARE;
  SELECT * INTO STRICT bundle_row
    FROM old_mike_production_private.compute_source_bundle_hash(
      p_workspace_id, p_project_id, p_source_bundle_id, p_source_bundle_version
    );
  IF bundle_row.member_count <> declared_bundle.member_count
     OR bundle_row.minimum_ordinal <> 1
     OR bundle_row.maximum_ordinal <> declared_bundle.member_count
     OR bundle_row.bundle_hash <> declared_bundle.bundle_hash
     OR bundle_row.bundle_hash <> p_source_bundle_hash THEN
    RAISE EXCEPTION 'm1a_c1_source_bundle_authority_invalid';
  END IF;

  PERFORM old_mike_production_private.assert_registry_approved('PROMPT',p_prompt_id,p_prompt_version,p_prompt_hash,p_prompt_approval_event_hash,NULL);
  PERFORM old_mike_production_private.assert_registry_approved('SCHEMA',p_output_schema_id,p_output_schema_version,p_output_schema_hash,p_output_schema_approval_event_hash,NULL);
  PERFORM old_mike_production_private.assert_registry_approved('MODEL',p_model_id,p_model_version,p_model_hash,p_model_approval_event_hash,NULL);
  PERFORM old_mike_production_private.assert_registry_approved('EVAL',p_eval_id,p_eval_version,p_eval_hash,p_eval_approval_event_hash,p_eval_review_class);
  PERFORM old_mike_production_private.assert_registry_approved('PROVIDER_CONFIG',p_provider_config_id,p_provider_config_version,p_provider_config_hash,p_provider_config_approval_event_hash,NULL);
  PERFORM old_mike_production_private.assert_registry_approved('PRIVACY',p_privacy_id,p_privacy_version,p_privacy_hash,p_privacy_approval_event_hash,NULL);
  PERFORM old_mike_production_private.assert_registry_approved('RETENTION',p_retention_id,p_retention_version,p_retention_hash,p_retention_approval_event_hash,NULL);

  SELECT * INTO existing
    FROM old_mike_production_private.ai_jobs job_row
   WHERE job_row.workspace_id = p_workspace_id
     AND job_row.project_id = p_project_id
     AND (job_row.idempotency_key = p_idempotency_key
       OR job_row.request_id = p_request_id
       OR job_row.effect_lineage_hash = p_effect_lineage_hash)
   LIMIT 1;
  IF FOUND THEN
    IF existing.job_id = p_job_id
       AND existing.operation = p_operation
       AND existing.request_id = p_request_id
       AND existing.idempotency_key = p_idempotency_key
       AND existing.request_hash = p_request_hash
       AND existing.operation_identity_hash = p_operation_identity_hash
       AND existing.effect_lineage_hash = p_effect_lineage_hash
       AND existing.base_revision = p_base_revision
       AND existing.base_content_hash = p_base_content_hash THEN
      RETURN QUERY
        SELECT 'REPLAYED'::text, existing.job_id::text, existing.state,
               outbox_row.outbox_id::text
          FROM old_mike_production_private.ai_outbox outbox_row
         WHERE outbox_row.workspace_id = p_workspace_id
           AND outbox_row.project_id = p_project_id
           AND outbox_row.kind = 'AI_JOB_READY'
           AND outbox_row.job_id = existing.job_id;
      RETURN;
    END IF;
    RAISE EXCEPTION 'm1a_c1_idempotency_conflict';
  END IF;

  INSERT INTO old_mike_production_private.operation_intents (
    workspace_id, project_id, operation, request_id, idempotency_key, request_hash,
    base_revision, base_content_hash, operation_identity_hash, job_id, actor_user_id
  ) VALUES (
    p_workspace_id, p_project_id, p_operation, p_request_id, p_idempotency_key,
    p_request_hash, p_base_revision, p_base_content_hash, p_operation_identity_hash,
    p_job_id, p_actor_user_id
  );

  INSERT INTO old_mike_production_private.ai_jobs (
    workspace_id, project_id, job_id, stage_id, effect_lineage_hash, operation,
    request_id, idempotency_key, request_hash, base_revision, base_content_hash,
    operation_identity_hash, actor_user_id,
    source_bundle_id, source_bundle_version, source_bundle_hash,
    prompt_id, prompt_version, prompt_hash, prompt_approval_event_hash,
    output_schema_id, output_schema_version, output_schema_hash, output_schema_approval_event_hash,
    model_id, model_version, model_hash, model_approval_event_hash,
    eval_id, eval_version, eval_hash, eval_approval_event_hash, eval_review_class,
    provider_config_id, provider_config_version, provider_config_hash, provider_config_approval_event_hash,
    privacy_id, privacy_version, privacy_hash, privacy_approval_event_hash,
    retention_id, retention_version, retention_hash, retention_approval_event_hash
  ) VALUES (
    p_workspace_id, p_project_id, p_job_id, p_stage_id, p_effect_lineage_hash, p_operation,
    p_request_id, p_idempotency_key, p_request_hash, p_base_revision, p_base_content_hash,
    p_operation_identity_hash, p_actor_user_id,
    p_source_bundle_id, p_source_bundle_version, p_source_bundle_hash,
    p_prompt_id, p_prompt_version, p_prompt_hash, p_prompt_approval_event_hash,
    p_output_schema_id, p_output_schema_version, p_output_schema_hash, p_output_schema_approval_event_hash,
    p_model_id, p_model_version, p_model_hash, p_model_approval_event_hash,
    p_eval_id, p_eval_version, p_eval_hash, p_eval_approval_event_hash, p_eval_review_class,
    p_provider_config_id, p_provider_config_version, p_provider_config_hash, p_provider_config_approval_event_hash,
    p_privacy_id, p_privacy_version, p_privacy_hash, p_privacy_approval_event_hash,
    p_retention_id, p_retention_version, p_retention_hash, p_retention_approval_event_hash
  );

  outbox_payload := pg_catalog.jsonb_build_object(
    'effectLineageHash', p_effect_lineage_hash,
    'jobId', p_job_id,
    'kind', 'AI_JOB_READY',
    'projectId', p_project_id,
    'requestHash', p_request_hash,
    'schemaVersion', p_schema_version,
    'workspaceId', p_workspace_id
  );
  INSERT INTO old_mike_production_private.ai_outbox (
    workspace_id, project_id, outbox_id, kind, job_id, effect_lineage_hash,
    schema_version, payload, payload_hash
  ) VALUES (
    p_workspace_id, p_project_id, p_outbox_id, 'AI_JOB_READY', p_job_id,
    p_effect_lineage_hash, p_schema_version, outbox_payload,
    old_mike_production_private.canonical_json_hash(outbox_payload)
  );

  RETURN QUERY SELECT 'CREATED'::text, p_job_id, 'QUEUED'::text, p_outbox_id;
END
$function$;

CREATE FUNCTION old_mike_production_private.claim_ai_outbox(
  p_workspace_id text,
  p_project_id text,
  p_outbox_id text,
  p_lease_owner_hash text,
  p_lease_seconds integer
)
RETURNS TABLE(disposition text, lease_generation bigint, payload_hash text)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog
AS $function$
DECLARE
  outbox_row old_mike_production_private.ai_outbox%ROWTYPE;
BEGIN
  IF p_lease_seconds < 1 OR p_lease_seconds > 300 THEN
    RAISE EXCEPTION 'm1a_c1_outbox_lease_duration_invalid';
  END IF;
  SELECT * INTO STRICT outbox_row
    FROM old_mike_production_private.ai_outbox row_value
   WHERE row_value.workspace_id = p_workspace_id
     AND row_value.project_id = p_project_id
     AND row_value.outbox_id = p_outbox_id
   FOR UPDATE;
  IF outbox_row.state = 'PUBLISHED' THEN
    RETURN QUERY SELECT 'REPLAYED_PUBLISHED'::text, outbox_row.lease_generation, outbox_row.payload_hash::text;
    RETURN;
  END IF;
  IF outbox_row.state = 'LEASED' AND outbox_row.lease_expires_at > pg_catalog.statement_timestamp() THEN
    RAISE EXCEPTION 'm1a_c1_outbox_live_lease';
  END IF;
  UPDATE old_mike_production_private.ai_outbox
     SET state = 'LEASED',
         lease_generation = outbox_row.lease_generation + 1,
         lease_owner_hash = p_lease_owner_hash,
         lease_expires_at = pg_catalog.statement_timestamp() + pg_catalog.make_interval(secs => p_lease_seconds)
   WHERE workspace_id = p_workspace_id AND project_id = p_project_id AND outbox_id = p_outbox_id;
  RETURN QUERY SELECT 'LEASED'::text, outbox_row.lease_generation + 1, outbox_row.payload_hash::text;
END
$function$;

CREATE FUNCTION old_mike_production_private.publish_ai_outbox(
  p_workspace_id text,
  p_project_id text,
  p_outbox_id text,
  p_lease_owner_hash text,
  p_lease_generation bigint,
  p_message_id_hash text
)
RETURNS TABLE(disposition text, message_id_hash text)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog
AS $function$
DECLARE
  outbox_row old_mike_production_private.ai_outbox%ROWTYPE;
BEGIN
  SELECT * INTO STRICT outbox_row
    FROM old_mike_production_private.ai_outbox row_value
   WHERE row_value.workspace_id = p_workspace_id
     AND row_value.project_id = p_project_id
     AND row_value.outbox_id = p_outbox_id
   FOR UPDATE;
  IF outbox_row.state = 'PUBLISHED' THEN
    IF outbox_row.published_message_id_hash <> p_message_id_hash THEN
      RAISE EXCEPTION 'm1a_c1_outbox_publish_identity_conflict';
    END IF;
    RETURN QUERY SELECT 'REPLAYED'::text, outbox_row.published_message_id_hash::text;
    RETURN;
  END IF;
  IF outbox_row.state <> 'LEASED'
     OR outbox_row.lease_generation <> p_lease_generation
     OR outbox_row.lease_owner_hash <> p_lease_owner_hash
     OR outbox_row.lease_expires_at <= pg_catalog.statement_timestamp() THEN
    RAISE EXCEPTION 'm1a_c1_outbox_stale_lease_commit';
  END IF;
  UPDATE old_mike_production_private.ai_outbox
     SET state = 'PUBLISHED', lease_owner_hash = NULL, lease_expires_at = NULL,
         published_message_id_hash = p_message_id_hash,
         published_at = pg_catalog.statement_timestamp()
   WHERE workspace_id = p_workspace_id AND project_id = p_project_id AND outbox_id = p_outbox_id;
  RETURN QUERY SELECT 'PUBLISHED'::text, p_message_id_hash;
END
$function$;

CREATE FUNCTION old_mike_production_private.reserve_budget(
  p_workspace_id text,
  p_project_id text,
  p_job_id text,
  p_reservation_id text,
  p_currency text,
  p_unit text,
  p_policy_id text,
  p_policy_version integer,
  p_policy_hash text,
  p_reserved_units bigint,
  p_reserved_cost_minor bigint,
  p_expires_at timestamptz
)
RETURNS TABLE(disposition text, reservation_id text)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog
AS $function$
DECLARE
  existing old_mike_production_private.budget_reservations%ROWTYPE;
BEGIN
  PERFORM 1 FROM old_mike_production_private.ai_jobs job_row
   WHERE job_row.workspace_id = p_workspace_id AND job_row.project_id = p_project_id
     AND job_row.job_id = p_job_id AND job_row.state IN ('QUEUED','LEASED')
   FOR UPDATE;
  IF NOT FOUND OR p_expires_at <= pg_catalog.statement_timestamp() THEN
    RAISE EXCEPTION 'm1a_c1_budget_job_or_expiry_invalid';
  END IF;
  SELECT * INTO existing
    FROM old_mike_production_private.budget_reservations row_value
   WHERE row_value.workspace_id = p_workspace_id AND row_value.project_id = p_project_id
     AND (row_value.reservation_id = p_reservation_id OR row_value.job_id = p_job_id)
   LIMIT 1;
  IF FOUND THEN
    IF existing.reservation_id = p_reservation_id AND existing.job_id = p_job_id
       AND existing.currency = p_currency AND existing.unit = p_unit
       AND existing.policy_id = p_policy_id AND existing.policy_version = p_policy_version
       AND existing.policy_hash = p_policy_hash
       AND existing.reserved_units = p_reserved_units
       AND existing.reserved_cost_minor = p_reserved_cost_minor
       AND existing.expires_at = p_expires_at THEN
      RETURN QUERY SELECT 'REPLAYED'::text, existing.reservation_id::text;
      RETURN;
    END IF;
    RAISE EXCEPTION 'm1a_c1_budget_reservation_conflict';
  END IF;
  INSERT INTO old_mike_production_private.budget_reservations (
    workspace_id, project_id, reservation_id, job_id, currency, unit,
    policy_id, policy_version, policy_hash, reserved_units, reserved_cost_minor, expires_at
  ) VALUES (
    p_workspace_id, p_project_id, p_reservation_id, p_job_id, p_currency, p_unit,
    p_policy_id, p_policy_version, p_policy_hash, p_reserved_units, p_reserved_cost_minor, p_expires_at
  );
  RETURN QUERY SELECT 'CREATED'::text, p_reservation_id;
END
$function$;

CREATE FUNCTION old_mike_production_private.claim_ai_job(
  p_workspace_id text,
  p_project_id text,
  p_job_id text,
  p_lease_owner_hash text,
  p_lease_seconds integer
)
RETURNS TABLE(disposition text, lease_generation bigint, job_state text)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog
AS $function$
DECLARE
  job_row old_mike_production_private.ai_jobs%ROWTYPE;
BEGIN
  IF p_lease_seconds < 1 OR p_lease_seconds > 300 THEN
    RAISE EXCEPTION 'm1a_c1_job_lease_duration_invalid';
  END IF;
  SELECT * INTO STRICT job_row
    FROM old_mike_production_private.ai_jobs row_value
   WHERE row_value.workspace_id = p_workspace_id AND row_value.project_id = p_project_id
     AND row_value.job_id = p_job_id
   FOR UPDATE;
  IF NOT EXISTS (
    SELECT 1 FROM old_mike_production_private.ai_outbox outbox_row
     WHERE outbox_row.workspace_id = p_workspace_id AND outbox_row.project_id = p_project_id
       AND outbox_row.job_id = p_job_id AND outbox_row.kind = 'AI_JOB_READY'
       AND outbox_row.state = 'PUBLISHED'
  ) THEN
    RAISE EXCEPTION 'm1a_c1_unpublished_job_not_claimable';
  END IF;
  IF job_row.state NOT IN ('QUEUED','LEASED') THEN
    RETURN QUERY SELECT 'NOT_CLAIMABLE'::text, job_row.lease_generation, job_row.state;
    RETURN;
  END IF;
  IF job_row.state = 'LEASED' AND job_row.lease_expires_at > pg_catalog.statement_timestamp() THEN
    RAISE EXCEPTION 'm1a_c1_job_live_lease';
  END IF;
  UPDATE old_mike_production_private.ai_jobs
     SET state = 'LEASED', lease_generation = job_row.lease_generation + 1,
         lease_owner_hash = p_lease_owner_hash,
         lease_expires_at = pg_catalog.statement_timestamp() + pg_catalog.make_interval(secs => p_lease_seconds),
         updated_at = pg_catalog.statement_timestamp()
   WHERE workspace_id = p_workspace_id AND project_id = p_project_id AND job_id = p_job_id;
  RETURN QUERY SELECT 'LEASED'::text, job_row.lease_generation + 1, 'LEASED'::text;
END
$function$;

CREATE FUNCTION old_mike_production_private.prepare_provider_attempt(
  p_workspace_id text,
  p_project_id text,
  p_job_id text,
  p_lease_owner_hash text,
  p_lease_generation bigint,
  p_provider_class text,
  p_provider_request_id text,
  p_request_authority_hash text,
  p_external_ledger_key_hash text,
  p_external_ledger_commitment_hash text
)
RETURNS TABLE(disposition text, attempt_state text)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog
AS $function$
DECLARE
  job_row old_mike_production_private.ai_jobs%ROWTYPE;
  existing old_mike_production_private.provider_attempts%ROWTYPE;
BEGIN
  SELECT * INTO STRICT job_row
    FROM old_mike_production_private.ai_jobs row_value
   WHERE row_value.workspace_id = p_workspace_id AND row_value.project_id = p_project_id
     AND row_value.job_id = p_job_id
   FOR UPDATE;
  IF job_row.state <> 'LEASED' OR job_row.lease_generation <> p_lease_generation
     OR job_row.lease_owner_hash <> p_lease_owner_hash
     OR job_row.lease_expires_at <= pg_catalog.statement_timestamp() THEN
    RAISE EXCEPTION 'm1a_c1_prepare_attempt_stale_job_lease';
  END IF;
  IF NOT EXISTS (
    SELECT 1 FROM old_mike_production_private.budget_reservations budget_row
     WHERE budget_row.workspace_id = p_workspace_id AND budget_row.project_id = p_project_id
       AND budget_row.job_id = p_job_id
       AND budget_row.expires_at > pg_catalog.statement_timestamp()
  ) THEN
    RAISE EXCEPTION 'm1a_c1_active_budget_reservation_required';
  END IF;
  PERFORM old_mike_production_private.assert_registry_approved('PROMPT',job_row.prompt_id,job_row.prompt_version,job_row.prompt_hash,job_row.prompt_approval_event_hash,NULL);
  PERFORM old_mike_production_private.assert_registry_approved('SCHEMA',job_row.output_schema_id,job_row.output_schema_version,job_row.output_schema_hash,job_row.output_schema_approval_event_hash,NULL);
  PERFORM old_mike_production_private.assert_registry_approved('MODEL',job_row.model_id,job_row.model_version,job_row.model_hash,job_row.model_approval_event_hash,NULL);
  PERFORM old_mike_production_private.assert_registry_approved('EVAL',job_row.eval_id,job_row.eval_version,job_row.eval_hash,job_row.eval_approval_event_hash,job_row.eval_review_class);
  PERFORM old_mike_production_private.assert_registry_approved('PROVIDER_CONFIG',job_row.provider_config_id,job_row.provider_config_version,job_row.provider_config_hash,job_row.provider_config_approval_event_hash,NULL);
  PERFORM old_mike_production_private.assert_registry_approved('PRIVACY',job_row.privacy_id,job_row.privacy_version,job_row.privacy_hash,job_row.privacy_approval_event_hash,NULL);
  PERFORM old_mike_production_private.assert_registry_approved('RETENTION',job_row.retention_id,job_row.retention_version,job_row.retention_hash,job_row.retention_approval_event_hash,NULL);
  SELECT * INTO existing
    FROM old_mike_production_private.provider_attempts attempt_row
   WHERE attempt_row.workspace_id = p_workspace_id AND attempt_row.project_id = p_project_id
     AND attempt_row.job_id = p_job_id AND attempt_row.attempt_no = 1;
  IF FOUND THEN
    IF existing.provider_class = p_provider_class
       AND existing.provider_request_id = p_provider_request_id
       AND existing.request_hash = job_row.request_hash
       AND existing.request_authority_hash = p_request_authority_hash
       AND existing.external_ledger_key_hash = p_external_ledger_key_hash
       AND existing.external_ledger_commitment_hash = p_external_ledger_commitment_hash THEN
      RETURN QUERY SELECT 'REPLAYED'::text, existing.state;
      RETURN;
    END IF;
    RAISE EXCEPTION 'm1a_c1_provider_attempt_conflict';
  END IF;
  INSERT INTO old_mike_production_private.provider_attempts (
    workspace_id, project_id, job_id, attempt_no, provider_class,
    provider_request_id, request_hash, request_authority_hash,
    external_ledger_key_hash, external_ledger_commitment_hash,
    operation_identity_hash, source_bundle_hash, provider_config_hash
  ) VALUES (
    p_workspace_id, p_project_id, p_job_id, 1, p_provider_class,
    p_provider_request_id, job_row.request_hash, p_request_authority_hash,
    p_external_ledger_key_hash, p_external_ledger_commitment_hash,
    job_row.operation_identity_hash, job_row.source_bundle_hash, job_row.provider_config_hash
  );
  RETURN QUERY SELECT 'PREPARED'::text, 'PREPARED'::text;
END
$function$;

CREATE FUNCTION old_mike_production_private.append_provider_receipt(
  p_workspace_id text,
  p_project_id text,
  p_job_id text,
  p_receipt_kind text,
  p_evidence_hash text,
  p_result_hash text,
  p_rejection_authority_hash text,
  p_non_submission_proof_hash text,
  p_sanitized_code text
)
RETURNS text
LANGUAGE plpgsql
SET search_path = pg_catalog
AS $function$
DECLARE
  attempt_row old_mike_production_private.provider_attempts%ROWTYPE;
  next_sequence integer;
  predecessor_hash text;
  current_hash text;
BEGIN
  SELECT * INTO STRICT attempt_row
    FROM old_mike_production_private.provider_attempts row_value
   WHERE row_value.workspace_id = p_workspace_id AND row_value.project_id = p_project_id
     AND row_value.job_id = p_job_id AND row_value.attempt_no = 1
   FOR UPDATE;
  SELECT COALESCE(pg_catalog.max(receipt_row.sequence),0) + 1,
         (pg_catalog.array_agg(receipt_row.receipt_hash ORDER BY receipt_row.sequence DESC))[1]::text
    INTO next_sequence, predecessor_hash
    FROM old_mike_production_private.provider_receipts receipt_row
   WHERE receipt_row.workspace_id = p_workspace_id AND receipt_row.project_id = p_project_id
     AND receipt_row.job_id = p_job_id AND receipt_row.attempt_no = 1;
  current_hash := old_mike_production_private.hash_parts(
    p_workspace_id, p_project_id, p_job_id, '1', next_sequence::text,
    p_receipt_kind, predecessor_hash, p_evidence_hash, p_result_hash,
    p_rejection_authority_hash, p_non_submission_proof_hash, p_sanitized_code
  );
  INSERT INTO old_mike_production_private.provider_receipts (
    workspace_id, project_id, job_id, attempt_no, provider_class,
    provider_request_id, request_hash, request_authority_hash,
    external_ledger_key_hash, external_ledger_commitment_hash,
    sequence, receipt_kind, predecessor_receipt_hash, evidence_hash,
    result_hash, rejection_authority_hash, non_submission_proof_hash,
    sanitized_code, receipt_hash
  ) VALUES (
    p_workspace_id, p_project_id, p_job_id, 1, attempt_row.provider_class,
    attempt_row.provider_request_id, attempt_row.request_hash, attempt_row.request_authority_hash,
    attempt_row.external_ledger_key_hash, attempt_row.external_ledger_commitment_hash,
    next_sequence, p_receipt_kind, predecessor_hash, p_evidence_hash,
    p_result_hash, p_rejection_authority_hash, p_non_submission_proof_hash,
    p_sanitized_code, current_hash
  );
  RETURN current_hash;
END
$function$;

CREATE FUNCTION old_mike_production_private.begin_provider_io(
  p_workspace_id text,
  p_project_id text,
  p_job_id text,
  p_lease_owner_hash text,
  p_lease_generation bigint,
  p_external_ledger_commitment_hash text
)
RETURNS TABLE(disposition text, job_state text, provider_submission_count integer, receipt_hash text)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog
AS $function$
DECLARE
  job_row old_mike_production_private.ai_jobs%ROWTYPE;
  attempt_row old_mike_production_private.provider_attempts%ROWTYPE;
  new_receipt_hash text;
BEGIN
  SELECT * INTO STRICT job_row
    FROM old_mike_production_private.ai_jobs row_value
   WHERE row_value.workspace_id = p_workspace_id AND row_value.project_id = p_project_id
     AND row_value.job_id = p_job_id
   FOR UPDATE;
  SELECT * INTO STRICT attempt_row
    FROM old_mike_production_private.provider_attempts row_value
   WHERE row_value.workspace_id = p_workspace_id AND row_value.project_id = p_project_id
     AND row_value.job_id = p_job_id AND row_value.attempt_no = 1
   FOR UPDATE;
  IF attempt_row.external_ledger_commitment_hash <> p_external_ledger_commitment_hash THEN
    RAISE EXCEPTION 'm1a_c1_external_ledger_commitment_mismatch';
  END IF;
  IF attempt_row.state <> 'PREPARED' THEN
    IF attempt_row.state IN ('MAY_HAVE_SUBMITTED','ACCEPTED','COMPLETION_UNKNOWN','SUCCEEDED','TERMINAL_REJECTED','PROVEN_NOT_SUBMITTED') THEN
      RETURN QUERY
        SELECT 'REPLAYED_NO_RESEND'::text, job_row.state, job_row.provider_submission_count,
               receipt_row.receipt_hash::text
          FROM old_mike_production_private.provider_receipts receipt_row
         WHERE receipt_row.workspace_id = p_workspace_id AND receipt_row.project_id = p_project_id
           AND receipt_row.job_id = p_job_id AND receipt_row.sequence = 1;
      RETURN;
    END IF;
    RAISE EXCEPTION 'm1a_c1_attempt_not_prepared';
  END IF;
  IF job_row.state <> 'LEASED' OR job_row.lease_generation <> p_lease_generation
     OR job_row.lease_owner_hash <> p_lease_owner_hash
     OR job_row.lease_expires_at <= pg_catalog.statement_timestamp() THEN
    RAISE EXCEPTION 'm1a_c1_begin_io_stale_job_lease';
  END IF;
  UPDATE old_mike_production_private.provider_attempts
     SET state = 'MAY_HAVE_SUBMITTED', io_started_at = pg_catalog.statement_timestamp()
   WHERE workspace_id = p_workspace_id AND project_id = p_project_id AND job_id = p_job_id AND attempt_no = 1;
  UPDATE old_mike_production_private.ai_jobs
     SET state = 'SUBMITTING', provider_submission_count = 1,
         submitted_at = pg_catalog.statement_timestamp(), lease_owner_hash = NULL,
         lease_expires_at = NULL, updated_at = pg_catalog.statement_timestamp()
   WHERE workspace_id = p_workspace_id AND project_id = p_project_id AND job_id = p_job_id;
  new_receipt_hash := old_mike_production_private.append_provider_receipt(
    p_workspace_id,p_project_id,p_job_id,'SUBMISSION_STARTED',
    p_external_ledger_commitment_hash,NULL,NULL,NULL,NULL
  );
  RETURN QUERY SELECT 'MAY_HAVE_SUBMITTED'::text, 'SUBMITTING'::text, 1, new_receipt_hash;
END
$function$;

CREATE FUNCTION old_mike_production_private.commit_job_event(
  p_workspace_id text,
  p_project_id text,
  p_job_id text,
  p_event_id text,
  p_event_kind text,
  p_result_hash text,
  p_rejection_authority_hash text,
  p_non_submission_proof_hash text,
  p_snapshot_schema_version text,
  p_snapshot_payload jsonb,
  p_snapshot_payload_hash text,
  p_snapshot_content_hash text,
  p_advance_snapshot boolean,
  p_commit_intent boolean
)
RETURNS TABLE(event_hash text, snapshot_revision bigint, snapshot_content_hash text, response_authority_hash text)
LANGUAGE plpgsql
SET search_path = pg_catalog
AS $function$
DECLARE
  job_row old_mike_production_private.ai_jobs%ROWTYPE;
  head_row old_mike_production_private.project_snapshots%ROWTYPE;
  intent_row old_mike_production_private.operation_intents%ROWTYPE;
  expected_snapshot_payload jsonb;
  next_sequence bigint;
  predecessor_hash text;
  computed_event_hash text;
  computed_response_hash text;
  v_committed_revision bigint;
  v_committed_hash text;
BEGIN
  SELECT * INTO STRICT job_row
    FROM old_mike_production_private.ai_jobs row_value
   WHERE row_value.workspace_id = p_workspace_id AND row_value.project_id = p_project_id
     AND row_value.job_id = p_job_id
   FOR UPDATE;
  SELECT * INTO STRICT head_row
    FROM old_mike_production_private.project_snapshots row_value
   WHERE row_value.workspace_id = p_workspace_id AND row_value.project_id = p_project_id
   ORDER BY row_value.revision DESC LIMIT 1 FOR UPDATE;
  IF head_row.revision <> job_row.base_revision OR head_row.content_hash <> job_row.base_content_hash THEN
    RAISE EXCEPTION 'm1a_c1_terminal_commit_stale_project_head';
  END IF;

  IF p_advance_snapshot THEN
    IF p_result_hash IS NULL OR p_snapshot_schema_version IS NULL
       OR p_snapshot_payload IS NULL OR p_snapshot_payload_hash IS NULL
       OR p_snapshot_content_hash IS NULL THEN
      RAISE EXCEPTION 'm1a_c1_success_snapshot_authority_required';
    END IF;
    expected_snapshot_payload := pg_catalog.jsonb_build_object(
      'jobId', p_job_id,
      'operation', job_row.operation,
      'projectId', p_project_id,
      'resultHash', p_result_hash,
      'schemaVersion', p_snapshot_schema_version,
      'sourceBundleHash', job_row.source_bundle_hash,
      'workspaceId', p_workspace_id
    );
    PERFORM old_mike_production_private.assert_exact_payload(
      p_snapshot_payload, expected_snapshot_payload, p_snapshot_payload_hash
    );
    v_committed_revision := head_row.revision + 1;
    v_committed_hash := old_mike_production_private.hash_parts(
      p_workspace_id, p_project_id, v_committed_revision::text, head_row.content_hash,
      p_job_id, p_result_hash, p_snapshot_payload_hash
    );
    IF p_snapshot_content_hash <> v_committed_hash THEN
      RAISE EXCEPTION 'm1a_c1_success_snapshot_content_hash_invalid';
    END IF;
    INSERT INTO old_mike_production_private.project_snapshots (
      workspace_id, project_id, revision, content_hash, predecessor_content_hash,
      operation, operation_identity_hash, request_id, idempotency_key, request_hash,
      actor_user_id, schema_version, authority_payload_hash, source_job_id
    ) VALUES (
      p_workspace_id, p_project_id, v_committed_revision, v_committed_hash, head_row.content_hash,
      job_row.operation, job_row.operation_identity_hash, job_row.request_id,
      job_row.idempotency_key, job_row.request_hash, job_row.actor_user_id,
      p_snapshot_schema_version, p_snapshot_payload_hash, p_job_id
    );
  ELSE
    IF p_snapshot_schema_version IS NOT NULL OR p_snapshot_payload IS NOT NULL
       OR p_snapshot_payload_hash IS NOT NULL OR p_snapshot_content_hash IS NOT NULL THEN
      RAISE EXCEPTION 'm1a_c1_nonadvancing_event_forbids_snapshot_payload';
    END IF;
    v_committed_revision := head_row.revision;
    v_committed_hash := head_row.content_hash;
  END IF;

  SELECT COALESCE(pg_catalog.max(event_row.sequence),0) + 1,
         (pg_catalog.array_agg(event_row.event_hash ORDER BY event_row.sequence DESC))[1]::text
    INTO next_sequence, predecessor_hash
    FROM old_mike_production_private.project_events event_row
   WHERE event_row.workspace_id = p_workspace_id AND event_row.project_id = p_project_id;
  computed_response_hash := old_mike_production_private.hash_parts(
    p_workspace_id, p_project_id, p_job_id, p_event_kind,
    p_result_hash, p_rejection_authority_hash, p_non_submission_proof_hash,
    v_committed_revision::text, v_committed_hash
  );
  computed_event_hash := old_mike_production_private.hash_parts(
    p_workspace_id, p_project_id, p_event_id, next_sequence::text,
    predecessor_hash, p_event_kind, job_row.operation_identity_hash,
    v_committed_revision::text, v_committed_hash, computed_response_hash
  );
  INSERT INTO old_mike_production_private.project_events (
    workspace_id, project_id, event_id, sequence, predecessor_event_hash, event_hash,
    operation, request_id, idempotency_key, request_hash, base_revision,
    base_content_hash, operation_identity_hash, snapshot_revision,
    snapshot_content_hash, job_id, event_kind, response_authority_hash
  ) VALUES (
    p_workspace_id, p_project_id, p_event_id, next_sequence, predecessor_hash,
    computed_event_hash, job_row.operation, job_row.request_id, job_row.idempotency_key,
    job_row.request_hash, job_row.base_revision, job_row.base_content_hash,
    job_row.operation_identity_hash, v_committed_revision, v_committed_hash,
    p_job_id, p_event_kind, computed_response_hash
  );
  IF p_commit_intent THEN
    SELECT * INTO STRICT intent_row
      FROM old_mike_production_private.operation_intents row_value
     WHERE row_value.workspace_id = p_workspace_id AND row_value.project_id = p_project_id
       AND row_value.operation_identity_hash = job_row.operation_identity_hash
     FOR UPDATE;
    IF intent_row.status <> 'PENDING' THEN
      RAISE EXCEPTION 'm1a_c1_operation_intent_already_terminal';
    END IF;
    UPDATE old_mike_production_private.operation_intents
       SET status = 'COMMITTED', committed_revision = v_committed_revision,
           committed_content_hash = v_committed_hash, committed_event_id = p_event_id,
           committed_response_hash = computed_response_hash,
           terminal_at = pg_catalog.statement_timestamp()
     WHERE workspace_id = p_workspace_id AND project_id = p_project_id
       AND operation_identity_hash = job_row.operation_identity_hash;
  END IF;
  RETURN QUERY SELECT computed_event_hash, v_committed_revision, v_committed_hash, computed_response_hash;
END
$function$;

CREATE FUNCTION old_mike_production_private.commit_provider_outcome(
  p_workspace_id text,
  p_project_id text,
  p_job_id text,
  p_outcome text,
  p_evidence_hash text,
  p_acceptance_evidence_hash text,
  p_result_hash text,
  p_rejection_authority_hash text,
  p_non_submission_proof_hash text,
  p_sanitized_code text,
  p_event_id text,
  p_snapshot_schema_version text,
  p_snapshot_payload jsonb,
  p_snapshot_payload_hash text,
  p_snapshot_content_hash text
)
RETURNS TABLE(disposition text, job_state text, event_hash text, snapshot_revision bigint, snapshot_content_hash text)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog
AS $function$
DECLARE
  job_row old_mike_production_private.ai_jobs%ROWTYPE;
  attempt_row old_mike_production_private.provider_attempts%ROWTYPE;
  event_row record;
  target_job_state text;
  target_attempt_state text;
  event_kind text;
  receipt_kind text;
  terminal_hash text;
BEGIN
  IF p_outcome NOT IN ('ACCEPTED','COMPLETE','TERMINAL_REJECTED','COMPLETION_UNKNOWN','PROVEN_NOT_SUBMITTED') THEN
    RAISE EXCEPTION 'm1a_c1_provider_outcome_invalid';
  END IF;
  PERFORM 1 FROM public.projects project_row
   WHERE project_row.workspace_id = p_workspace_id AND project_row.project_id = p_project_id
   FOR UPDATE;
  SELECT * INTO STRICT job_row
    FROM old_mike_production_private.ai_jobs row_value
   WHERE row_value.workspace_id = p_workspace_id AND row_value.project_id = p_project_id
     AND row_value.job_id = p_job_id FOR UPDATE;
  SELECT * INTO STRICT attempt_row
    FROM old_mike_production_private.provider_attempts row_value
   WHERE row_value.workspace_id = p_workspace_id AND row_value.project_id = p_project_id
     AND row_value.job_id = p_job_id AND row_value.attempt_no = 1 FOR UPDATE;
  target_job_state := CASE p_outcome
    WHEN 'ACCEPTED' THEN 'ACCEPTED'
    WHEN 'COMPLETE' THEN 'SUCCEEDED'
    WHEN 'TERMINAL_REJECTED' THEN 'TERMINAL_REJECTED'
    WHEN 'COMPLETION_UNKNOWN' THEN 'COMPLETION_UNKNOWN'
    WHEN 'PROVEN_NOT_SUBMITTED' THEN 'PROVEN_NOT_SUBMITTED' END;
  target_attempt_state := target_job_state;
  IF job_row.state = target_job_state AND attempt_row.state = target_attempt_state THEN
    RETURN QUERY
      SELECT 'REPLAYED'::text, job_row.state, event_value.event_hash::text,
             snapshot_value.revision, snapshot_value.content_hash::text
        FROM old_mike_production_private.project_snapshots snapshot_value
        LEFT JOIN old_mike_production_private.project_events event_value
          ON event_value.workspace_id = p_workspace_id AND event_value.project_id = p_project_id
         AND event_value.job_id = p_job_id
         AND event_value.event_kind = CASE p_outcome
           WHEN 'COMPLETE' THEN 'GENERATION_COMPLETE'
           WHEN 'TERMINAL_REJECTED' THEN 'GENERATION_REJECTED'
           WHEN 'COMPLETION_UNKNOWN' THEN 'GENERATION_UNKNOWN'
           WHEN 'PROVEN_NOT_SUBMITTED' THEN 'GENERATION_PROVEN_NOT_SUBMITTED'
           ELSE NULL END
       WHERE snapshot_value.workspace_id = p_workspace_id AND snapshot_value.project_id = p_project_id
       ORDER BY snapshot_value.revision DESC LIMIT 1;
    RETURN;
  END IF;
  IF attempt_row.state NOT IN ('MAY_HAVE_SUBMITTED','ACCEPTED')
     OR job_row.state NOT IN ('SUBMITTING','ACCEPTED') THEN
    RAISE EXCEPTION 'm1a_c1_provider_outcome_state_invalid';
  END IF;
  IF p_outcome = 'ACCEPTED' THEN
    IF attempt_row.state <> 'MAY_HAVE_SUBMITTED' OR p_acceptance_evidence_hash IS NULL
       OR p_result_hash IS NOT NULL OR p_rejection_authority_hash IS NOT NULL
       OR p_non_submission_proof_hash IS NOT NULL OR p_sanitized_code IS NOT NULL
       OR p_event_id IS NOT NULL OR p_snapshot_payload IS NOT NULL THEN
      RAISE EXCEPTION 'm1a_c1_accepted_shape_invalid';
    END IF;
    PERFORM old_mike_production_private.append_provider_receipt(
      p_workspace_id,p_project_id,p_job_id,'SUBMISSION_ACCEPTED',
      p_acceptance_evidence_hash,NULL,NULL,NULL,NULL
    );
    UPDATE old_mike_production_private.provider_attempts
       SET state = 'ACCEPTED', accepted_at = pg_catalog.statement_timestamp()
     WHERE workspace_id = p_workspace_id AND project_id = p_project_id AND job_id = p_job_id AND attempt_no = 1;
    UPDATE old_mike_production_private.ai_jobs
       SET state = 'ACCEPTED', accepted_at = pg_catalog.statement_timestamp(), updated_at = pg_catalog.statement_timestamp()
     WHERE workspace_id = p_workspace_id AND project_id = p_project_id AND job_id = p_job_id;
    RETURN QUERY
      SELECT 'COMMITTED'::text, 'ACCEPTED'::text, NULL::text,
             snapshot_value.revision, snapshot_value.content_hash::text
        FROM old_mike_production_private.project_snapshots snapshot_value
       WHERE snapshot_value.workspace_id = p_workspace_id AND snapshot_value.project_id = p_project_id
       ORDER BY snapshot_value.revision DESC LIMIT 1;
    RETURN;
  END IF;
  IF p_event_id IS NULL OR p_evidence_hash IS NULL THEN
    RAISE EXCEPTION 'm1a_c1_terminal_event_and_evidence_required';
  END IF;
  IF attempt_row.state = 'MAY_HAVE_SUBMITTED' AND p_outcome = 'COMPLETE' THEN
    IF p_acceptance_evidence_hash IS NULL THEN
      RAISE EXCEPTION 'm1a_c1_direct_complete_acceptance_evidence_required';
    END IF;
    PERFORM old_mike_production_private.append_provider_receipt(
      p_workspace_id,p_project_id,p_job_id,'SUBMISSION_ACCEPTED',
      p_acceptance_evidence_hash,NULL,NULL,NULL,NULL
    );
    UPDATE old_mike_production_private.provider_attempts
       SET state = 'ACCEPTED', accepted_at = pg_catalog.statement_timestamp()
     WHERE workspace_id = p_workspace_id AND project_id = p_project_id AND job_id = p_job_id AND attempt_no = 1;
    UPDATE old_mike_production_private.ai_jobs
       SET state = 'ACCEPTED', accepted_at = pg_catalog.statement_timestamp(), updated_at = pg_catalog.statement_timestamp()
     WHERE workspace_id = p_workspace_id AND project_id = p_project_id AND job_id = p_job_id;
    attempt_row.state := 'ACCEPTED';
    job_row.state := 'ACCEPTED';
  ELSIF p_acceptance_evidence_hash IS NOT NULL THEN
    RAISE EXCEPTION 'm1a_c1_unexpected_acceptance_evidence';
  END IF;
  IF p_outcome = 'COMPLETE' THEN
    IF p_result_hash IS NULL OR p_rejection_authority_hash IS NOT NULL
       OR p_non_submission_proof_hash IS NOT NULL OR p_sanitized_code IS NOT NULL THEN
      RAISE EXCEPTION 'm1a_c1_complete_shape_invalid';
    END IF;
    receipt_kind := 'COMPLETION_OBSERVED'; event_kind := 'GENERATION_COMPLETE';
    terminal_hash := p_result_hash;
  ELSIF p_outcome = 'TERMINAL_REJECTED' THEN
    IF p_result_hash IS NOT NULL OR p_rejection_authority_hash IS NULL
       OR p_non_submission_proof_hash IS NOT NULL OR p_sanitized_code !~ '^[A-Z0-9_]{3,80}$'
       OR p_snapshot_payload IS NOT NULL THEN
      RAISE EXCEPTION 'm1a_c1_terminal_rejected_shape_invalid';
    END IF;
    receipt_kind := 'TERMINAL_REJECTED'; event_kind := 'GENERATION_REJECTED';
    terminal_hash := p_rejection_authority_hash;
  ELSIF p_outcome = 'COMPLETION_UNKNOWN' THEN
    IF p_result_hash IS NOT NULL OR p_rejection_authority_hash IS NOT NULL
       OR p_non_submission_proof_hash IS NOT NULL OR p_sanitized_code !~ '^[A-Z0-9_]{3,80}$'
       OR p_snapshot_payload IS NOT NULL THEN
      RAISE EXCEPTION 'm1a_c1_completion_unknown_shape_invalid';
    END IF;
    receipt_kind := 'COMPLETION_UNKNOWN'; event_kind := 'GENERATION_UNKNOWN';
    terminal_hash := NULL;
  ELSE
    IF attempt_row.state <> 'MAY_HAVE_SUBMITTED' OR p_result_hash IS NOT NULL
       OR p_rejection_authority_hash IS NOT NULL OR p_non_submission_proof_hash IS NULL
       OR p_sanitized_code !~ '^[A-Z0-9_]{3,80}$' OR p_snapshot_payload IS NOT NULL THEN
      RAISE EXCEPTION 'm1a_c1_proven_not_submitted_shape_invalid';
    END IF;
    receipt_kind := 'PROVEN_NOT_SUBMITTED'; event_kind := 'GENERATION_PROVEN_NOT_SUBMITTED';
    terminal_hash := p_non_submission_proof_hash;
  END IF;
  PERFORM old_mike_production_private.append_provider_receipt(
    p_workspace_id,p_project_id,p_job_id,receipt_kind,p_evidence_hash,
    p_result_hash,p_rejection_authority_hash,p_non_submission_proof_hash,p_sanitized_code
  );
  UPDATE old_mike_production_private.provider_attempts
     SET state = target_attempt_state,
         terminal_at = CASE WHEN p_outcome IN ('COMPLETE','TERMINAL_REJECTED','PROVEN_NOT_SUBMITTED')
                            THEN pg_catalog.statement_timestamp() ELSE NULL END,
         terminal_result_hash = p_result_hash,
         terminal_rejection_hash = p_rejection_authority_hash,
         terminal_non_submission_proof_hash = p_non_submission_proof_hash
   WHERE workspace_id = p_workspace_id AND project_id = p_project_id AND job_id = p_job_id AND attempt_no = 1;
  UPDATE old_mike_production_private.ai_jobs
     SET state = target_job_state,
         terminal_at = CASE WHEN p_outcome IN ('COMPLETE','TERMINAL_REJECTED','PROVEN_NOT_SUBMITTED')
                            THEN pg_catalog.statement_timestamp() ELSE NULL END,
         terminal_outcome_hash = terminal_hash,
         updated_at = pg_catalog.statement_timestamp()
   WHERE workspace_id = p_workspace_id AND project_id = p_project_id AND job_id = p_job_id;
  SELECT * INTO STRICT event_row FROM old_mike_production_private.commit_job_event(
    p_workspace_id,p_project_id,p_job_id,p_event_id,event_kind,
    p_result_hash,p_rejection_authority_hash,p_non_submission_proof_hash,
    p_snapshot_schema_version,p_snapshot_payload,p_snapshot_payload_hash,
    p_snapshot_content_hash,p_outcome = 'COMPLETE',true
  );
  RETURN QUERY SELECT 'COMMITTED'::text, target_job_state, event_row.event_hash::text,
                      event_row.snapshot_revision, event_row.snapshot_content_hash::text;
END
$function$;

CREATE FUNCTION old_mike_production_private.record_provider_lookup(
  p_workspace_id text,
  p_project_id text,
  p_job_id text,
  p_lookup_receipt_id text,
  p_lookup_outcome text,
  p_result_hash text,
  p_rejection_authority_hash text,
  p_lookup_authority_hash text
)
RETURNS TABLE(disposition text, lookup_receipt_id text)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog
AS $function$
DECLARE
  attempt_row old_mike_production_private.provider_attempts%ROWTYPE;
  expected_hash text;
  existing old_mike_production_private.provider_lookup_receipts%ROWTYPE;
BEGIN
  SELECT * INTO STRICT attempt_row FROM old_mike_production_private.provider_attempts row_value
   WHERE row_value.workspace_id=p_workspace_id AND row_value.project_id=p_project_id
     AND row_value.job_id=p_job_id AND row_value.attempt_no=1 FOR SHARE;
  IF attempt_row.state <> 'COMPLETION_UNKNOWN' THEN
    RAISE EXCEPTION 'm1a_c1_lookup_requires_completion_unknown';
  END IF;
  IF (p_lookup_outcome='COMPLETE' AND (p_result_hash IS NULL OR p_rejection_authority_hash IS NOT NULL))
     OR (p_lookup_outcome='TERMINAL_REJECTED' AND (p_result_hash IS NOT NULL OR p_rejection_authority_hash IS NULL))
     OR (p_lookup_outcome IN ('NOT_FOUND','PENDING','UNKNOWN') AND (p_result_hash IS NOT NULL OR p_rejection_authority_hash IS NOT NULL))
     OR p_lookup_outcome NOT IN ('NOT_FOUND','PENDING','COMPLETE','TERMINAL_REJECTED','UNKNOWN') THEN
    RAISE EXCEPTION 'm1a_c1_lookup_shape_invalid';
  END IF;
  expected_hash := old_mike_production_private.hash_parts(
    p_workspace_id,p_project_id,p_job_id,attempt_row.provider_class,
    attempt_row.provider_request_id,attempt_row.request_hash,attempt_row.request_authority_hash,
    attempt_row.external_ledger_key_hash,attempt_row.external_ledger_commitment_hash,
    p_lookup_receipt_id,p_lookup_outcome,p_result_hash,p_rejection_authority_hash
  );
  IF p_lookup_authority_hash <> expected_hash THEN RAISE EXCEPTION 'm1a_c1_lookup_authority_hash_invalid'; END IF;
  SELECT * INTO existing FROM old_mike_production_private.provider_lookup_receipts row_value
   WHERE row_value.workspace_id=p_workspace_id AND row_value.project_id=p_project_id
     AND row_value.lookup_receipt_id=p_lookup_receipt_id;
  IF FOUND THEN
    IF existing.lookup_authority_hash=p_lookup_authority_hash THEN
      RETURN QUERY SELECT 'REPLAYED'::text,p_lookup_receipt_id; RETURN;
    END IF;
    RAISE EXCEPTION 'm1a_c1_lookup_receipt_conflict';
  END IF;
  INSERT INTO old_mike_production_private.provider_lookup_receipts (
    workspace_id,project_id,job_id,attempt_no,provider_class,provider_request_id,
    request_hash,request_authority_hash,external_ledger_key_hash,external_ledger_commitment_hash,
    lookup_receipt_id,lookup_outcome,result_hash,rejection_authority_hash,lookup_authority_hash
  ) VALUES (
    p_workspace_id,p_project_id,p_job_id,1,attempt_row.provider_class,attempt_row.provider_request_id,
    attempt_row.request_hash,attempt_row.request_authority_hash,attempt_row.external_ledger_key_hash,
    attempt_row.external_ledger_commitment_hash,p_lookup_receipt_id,p_lookup_outcome,
    p_result_hash,p_rejection_authority_hash,p_lookup_authority_hash
  );
  RETURN QUERY SELECT 'RECORDED'::text,p_lookup_receipt_id;
END
$function$;

CREATE FUNCTION old_mike_production_private.receive_provider_webhook(
  p_workspace_id text,
  p_project_id text,
  p_job_id text,
  p_webhook_id text,
  p_provider_event_id text,
  p_key_version text,
  p_raw_body_byte_length bigint,
  p_raw_body_hash text,
  p_body_object_id text,
  p_body_object_version_id text,
  p_body_object_key_hash text,
  p_storage_receipt_hash text,
  p_signature_authority_hash text,
  p_validation_state text,
  p_outcome text,
  p_result_hash text,
  p_rejection_authority_hash text
)
RETURNS TABLE(disposition text, webhook_state text)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog
AS $function$
DECLARE
  attempt_row old_mike_production_private.provider_attempts%ROWTYPE;
  existing old_mike_production_private.webhook_inbox%ROWTYPE;
BEGIN
  SELECT * INTO STRICT attempt_row FROM old_mike_production_private.provider_attempts row_value
   WHERE row_value.workspace_id=p_workspace_id AND row_value.project_id=p_project_id
     AND row_value.job_id=p_job_id AND row_value.attempt_no=1 FOR SHARE;
  SELECT * INTO existing FROM old_mike_production_private.webhook_inbox row_value
   WHERE row_value.provider_class=attempt_row.provider_class
     AND row_value.provider_event_id=p_provider_event_id AND row_value.key_version=p_key_version
     AND row_value.raw_body_hash=p_raw_body_hash;
  IF FOUND THEN
    IF existing.workspace_id=p_workspace_id AND existing.project_id=p_project_id
       AND existing.job_id=p_job_id AND existing.webhook_id=p_webhook_id
       AND existing.signature_authority_hash=p_signature_authority_hash
       AND existing.outcome=p_outcome AND existing.result_hash IS NOT DISTINCT FROM p_result_hash
       AND existing.rejection_authority_hash IS NOT DISTINCT FROM p_rejection_authority_hash THEN
      RETURN QUERY SELECT 'REPLAYED'::text,existing.state; RETURN;
    END IF;
    RAISE EXCEPTION 'm1a_c1_webhook_dedup_conflict';
  END IF;
  INSERT INTO old_mike_production_private.webhook_inbox (
    workspace_id,project_id,webhook_id,job_id,attempt_no,provider_class,provider_request_id,
    request_hash,request_authority_hash,external_ledger_key_hash,external_ledger_commitment_hash,
    provider_event_id,key_version,raw_body_byte_length,raw_body_hash,body_object_id,
    body_object_version_id,body_object_key_hash,storage_receipt_hash,signature_authority_hash,
    validation_state,outcome,result_hash,rejection_authority_hash,state,terminal_at
  ) VALUES (
    p_workspace_id,p_project_id,p_webhook_id,p_job_id,1,attempt_row.provider_class,
    attempt_row.provider_request_id,attempt_row.request_hash,attempt_row.request_authority_hash,
    attempt_row.external_ledger_key_hash,attempt_row.external_ledger_commitment_hash,
    p_provider_event_id,p_key_version,p_raw_body_byte_length,p_raw_body_hash,p_body_object_id,
    p_body_object_version_id,p_body_object_key_hash,p_storage_receipt_hash,p_signature_authority_hash,
    p_validation_state,p_outcome,p_result_hash,p_rejection_authority_hash,
    CASE WHEN p_validation_state='VALID' THEN 'RECEIVED' ELSE 'BLOCKED' END,
    CASE WHEN p_validation_state='VALID' THEN NULL ELSE pg_catalog.statement_timestamp() END
  );
  RETURN QUERY SELECT 'RECORDED'::text,CASE WHEN p_validation_state='VALID' THEN 'RECEIVED' ELSE 'BLOCKED' END;
END
$function$;

CREATE FUNCTION old_mike_production_private.claim_provider_webhook(
  p_workspace_id text,p_project_id text,p_webhook_id text,
  p_lease_owner_hash text,p_lease_seconds integer
)
RETURNS TABLE(disposition text,lease_generation bigint)
LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog
AS $function$
DECLARE row_value old_mike_production_private.webhook_inbox%ROWTYPE;
BEGIN
  IF p_lease_seconds NOT BETWEEN 1 AND 300 THEN RAISE EXCEPTION 'm1a_c1_webhook_lease_seconds_invalid'; END IF;
  SELECT * INTO STRICT row_value FROM old_mike_production_private.webhook_inbox row_lock
   WHERE row_lock.workspace_id=p_workspace_id AND row_lock.project_id=p_project_id
     AND row_lock.webhook_id=p_webhook_id FOR UPDATE;
  IF row_value.validation_state<>'VALID' OR row_value.state NOT IN ('RECEIVED','LEASED') THEN
    RAISE EXCEPTION 'm1a_c1_webhook_not_claimable';
  END IF;
  IF row_value.state='LEASED' AND row_value.lease_expires_at>pg_catalog.statement_timestamp() THEN
    RAISE EXCEPTION 'm1a_c1_webhook_live_lease';
  END IF;
  UPDATE old_mike_production_private.webhook_inbox SET state='LEASED',
    lease_generation=row_value.lease_generation+1,lease_owner_hash=p_lease_owner_hash,
    lease_expires_at=pg_catalog.statement_timestamp()+pg_catalog.make_interval(secs=>p_lease_seconds)
   WHERE workspace_id=p_workspace_id AND project_id=p_project_id AND webhook_id=p_webhook_id;
  RETURN QUERY SELECT 'LEASED'::text,row_value.lease_generation+1;
END
$function$;

CREATE FUNCTION old_mike_production_private.authorize_human_reconciliation(
  p_workspace_id text,p_project_id text,p_actor_user_id text,p_job_id text,
  p_human_authority_id text,p_membership_authority_hash text,
  p_authorization_scope_hash text,p_authorization_policy_hash text,
  p_outcome text,p_result_hash text,p_rejection_authority_hash text,p_decision_hash text
)
RETURNS TABLE(disposition text,human_authority_id text)
LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog
AS $function$
DECLARE attempt_row old_mike_production_private.provider_attempts%ROWTYPE;
  expected_membership_hash text; expected_decision_hash text;
  existing old_mike_production_private.human_reconciliation_authorities%ROWTYPE;
BEGIN
  PERFORM old_mike_production_private.assert_active_member(p_workspace_id,p_project_id,p_actor_user_id);
  SELECT * INTO STRICT attempt_row FROM old_mike_production_private.provider_attempts row_value
   WHERE row_value.workspace_id=p_workspace_id AND row_value.project_id=p_project_id
     AND row_value.job_id=p_job_id AND row_value.attempt_no=1 FOR SHARE;
  IF attempt_row.state<>'COMPLETION_UNKNOWN' THEN RAISE EXCEPTION 'm1a_c1_human_reconcile_requires_unknown'; END IF;
  expected_membership_hash:=old_mike_production_private.hash_parts(p_workspace_id,p_project_id,p_actor_user_id,'ACTIVE_MEMBER');
  expected_decision_hash:=old_mike_production_private.hash_parts(
    p_workspace_id,p_project_id,p_job_id,p_human_authority_id,p_actor_user_id,
    expected_membership_hash,p_authorization_scope_hash,p_authorization_policy_hash,
    p_outcome,p_result_hash,p_rejection_authority_hash
  );
  IF p_membership_authority_hash<>expected_membership_hash OR p_decision_hash<>expected_decision_hash THEN
    RAISE EXCEPTION 'm1a_c1_human_reconcile_authority_invalid';
  END IF;
  SELECT * INTO existing FROM old_mike_production_private.human_reconciliation_authorities row_value
   WHERE row_value.workspace_id=p_workspace_id AND row_value.project_id=p_project_id
     AND row_value.human_authority_id=p_human_authority_id;
  IF FOUND THEN
    IF existing.decision_hash=p_decision_hash THEN RETURN QUERY SELECT 'REPLAYED'::text,p_human_authority_id; RETURN; END IF;
    RAISE EXCEPTION 'm1a_c1_human_reconcile_conflict';
  END IF;
  INSERT INTO old_mike_production_private.human_reconciliation_authorities (
    workspace_id,project_id,human_authority_id,job_id,attempt_no,provider_class,
    provider_request_id,request_hash,request_authority_hash,external_ledger_key_hash,
    external_ledger_commitment_hash,actor_user_id,membership_authority_hash,
    authorization_scope_hash,authorization_policy_hash,outcome,result_hash,
    rejection_authority_hash,decision_hash
  ) VALUES (
    p_workspace_id,p_project_id,p_human_authority_id,p_job_id,1,attempt_row.provider_class,
    attempt_row.provider_request_id,attempt_row.request_hash,attempt_row.request_authority_hash,
    attempt_row.external_ledger_key_hash,attempt_row.external_ledger_commitment_hash,
    p_actor_user_id,p_membership_authority_hash,p_authorization_scope_hash,
    p_authorization_policy_hash,p_outcome,p_result_hash,p_rejection_authority_hash,p_decision_hash
  );
  RETURN QUERY SELECT 'AUTHORIZED'::text,p_human_authority_id;
END
$function$;

CREATE FUNCTION old_mike_production_private.commit_reconciliation(
  p_workspace_id text,
  p_project_id text,
  p_job_id text,
  p_observation_id text,
  p_method text,
  p_evidence_id text,
  p_outcome text,
  p_result_hash text,
  p_rejection_authority_hash text,
  p_observation_hash text,
  p_event_id text,
  p_snapshot_schema_version text,
  p_snapshot_payload jsonb,
  p_snapshot_payload_hash text,
  p_snapshot_content_hash text,
  p_lease_owner_hash text DEFAULT NULL,
  p_lease_generation bigint DEFAULT NULL
)
RETURNS TABLE(disposition text,job_state text,event_hash text,snapshot_revision bigint,snapshot_content_hash text)
LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog
AS $function$
DECLARE
  job_row old_mike_production_private.ai_jobs%ROWTYPE;
  attempt_row old_mike_production_private.provider_attempts%ROWTYPE;
  lookup_row old_mike_production_private.provider_lookup_receipts%ROWTYPE;
  webhook_row old_mike_production_private.webhook_inbox%ROWTYPE;
  human_row old_mike_production_private.human_reconciliation_authorities%ROWTYPE;
  existing old_mike_production_private.reconciliation_observations%ROWTYPE;
  expected_outcome text;
  expected_hash text;
  event_row record;
BEGIN
  SELECT * INTO existing FROM old_mike_production_private.reconciliation_observations row_value
   WHERE row_value.workspace_id=p_workspace_id AND row_value.project_id=p_project_id
     AND row_value.observation_id=p_observation_id;
  IF FOUND THEN
    IF existing.job_id=p_job_id AND existing.method=p_method
       AND existing.outcome=p_outcome AND existing.observation_hash=p_observation_hash THEN
      RETURN QUERY
        SELECT 'REPLAYED'::text,job_value.state,event_value.event_hash::text,
               snapshot_value.revision,snapshot_value.content_hash::text
          FROM old_mike_production_private.ai_jobs job_value
          JOIN old_mike_production_private.project_snapshots snapshot_value
            ON snapshot_value.workspace_id=job_value.workspace_id AND snapshot_value.project_id=job_value.project_id
          LEFT JOIN old_mike_production_private.project_events event_value
            ON event_value.workspace_id=job_value.workspace_id AND event_value.project_id=job_value.project_id
           AND event_value.job_id=job_value.job_id
           AND event_value.event_kind IN ('RECONCILIATION_COMPLETE','RECONCILIATION_REJECTED')
         WHERE job_value.workspace_id=p_workspace_id AND job_value.project_id=p_project_id
           AND job_value.job_id=p_job_id ORDER BY snapshot_value.revision DESC LIMIT 1;
      RETURN;
    END IF;
    RAISE EXCEPTION 'm1a_c1_reconciliation_observation_conflict';
  END IF;
  PERFORM 1 FROM public.projects project_value
   WHERE project_value.workspace_id=p_workspace_id AND project_value.project_id=p_project_id FOR UPDATE;
  SELECT * INTO STRICT job_row FROM old_mike_production_private.ai_jobs row_value
   WHERE row_value.workspace_id=p_workspace_id AND row_value.project_id=p_project_id
     AND row_value.job_id=p_job_id FOR UPDATE;
  SELECT * INTO STRICT attempt_row FROM old_mike_production_private.provider_attempts row_value
   WHERE row_value.workspace_id=p_workspace_id AND row_value.project_id=p_project_id
     AND row_value.job_id=p_job_id AND row_value.attempt_no=1 FOR UPDATE;
  IF job_row.state<>'COMPLETION_UNKNOWN' OR attempt_row.state<>'COMPLETION_UNKNOWN' THEN
    RAISE EXCEPTION 'm1a_c1_reconciliation_requires_completion_unknown';
  END IF;
  IF p_method='LOOKUP' THEN
    SELECT * INTO STRICT lookup_row FROM old_mike_production_private.provider_lookup_receipts row_value
     WHERE row_value.workspace_id=p_workspace_id AND row_value.project_id=p_project_id
       AND row_value.lookup_receipt_id=p_evidence_id FOR SHARE;
    IF lookup_row.job_id<>p_job_id OR lookup_row.attempt_no<>1
       OR lookup_row.provider_class<>attempt_row.provider_class
       OR lookup_row.provider_request_id<>attempt_row.provider_request_id
       OR lookup_row.request_hash<>attempt_row.request_hash
       OR lookup_row.request_authority_hash<>attempt_row.request_authority_hash
       OR lookup_row.external_ledger_key_hash<>attempt_row.external_ledger_key_hash
       OR lookup_row.external_ledger_commitment_hash<>attempt_row.external_ledger_commitment_hash THEN
      RAISE EXCEPTION 'm1a_c1_cross_attempt_lookup_forbidden';
    END IF;
    expected_outcome:=CASE lookup_row.lookup_outcome WHEN 'NOT_FOUND' THEN 'UNKNOWN' ELSE lookup_row.lookup_outcome END;
    IF p_result_hash IS DISTINCT FROM lookup_row.result_hash
       OR p_rejection_authority_hash IS DISTINCT FROM lookup_row.rejection_authority_hash THEN
      RAISE EXCEPTION 'm1a_c1_lookup_outcome_authority_mismatch';
    END IF;
  ELSIF p_method='SIGNED_WEBHOOK' THEN
    SELECT * INTO STRICT webhook_row FROM old_mike_production_private.webhook_inbox row_value
     WHERE row_value.workspace_id=p_workspace_id AND row_value.project_id=p_project_id
       AND row_value.webhook_id=p_evidence_id FOR UPDATE;
    IF webhook_row.validation_state<>'VALID' OR webhook_row.state<>'LEASED'
       OR webhook_row.lease_owner_hash<>p_lease_owner_hash
       OR webhook_row.lease_generation<>p_lease_generation
       OR webhook_row.lease_expires_at<=pg_catalog.statement_timestamp()
       OR webhook_row.job_id<>p_job_id OR webhook_row.attempt_no<>1
       OR webhook_row.provider_class<>attempt_row.provider_class
       OR webhook_row.provider_request_id<>attempt_row.provider_request_id
       OR webhook_row.request_hash<>attempt_row.request_hash
       OR webhook_row.request_authority_hash<>attempt_row.request_authority_hash
       OR webhook_row.external_ledger_key_hash<>attempt_row.external_ledger_key_hash
       OR webhook_row.external_ledger_commitment_hash<>attempt_row.external_ledger_commitment_hash THEN
      RAISE EXCEPTION 'm1a_c1_webhook_authority_or_lease_invalid';
    END IF;
    expected_outcome:=webhook_row.outcome;
    IF p_result_hash IS DISTINCT FROM webhook_row.result_hash
       OR p_rejection_authority_hash IS DISTINCT FROM webhook_row.rejection_authority_hash THEN
      RAISE EXCEPTION 'm1a_c1_webhook_outcome_authority_mismatch';
    END IF;
  ELSIF p_method='AUTHORIZED_HUMAN' THEN
    SELECT * INTO STRICT human_row FROM old_mike_production_private.human_reconciliation_authorities row_value
     WHERE row_value.workspace_id=p_workspace_id AND row_value.project_id=p_project_id
       AND row_value.human_authority_id=p_evidence_id FOR SHARE;
    IF human_row.job_id<>p_job_id OR human_row.attempt_no<>1
       OR human_row.provider_class<>attempt_row.provider_class
       OR human_row.provider_request_id<>attempt_row.provider_request_id
       OR human_row.request_hash<>attempt_row.request_hash
       OR human_row.request_authority_hash<>attempt_row.request_authority_hash
       OR human_row.external_ledger_key_hash<>attempt_row.external_ledger_key_hash
       OR human_row.external_ledger_commitment_hash<>attempt_row.external_ledger_commitment_hash THEN
      RAISE EXCEPTION 'm1a_c1_human_reconciliation_authority_cross_attempt';
    END IF;
    expected_outcome:=human_row.outcome;
    IF p_result_hash IS DISTINCT FROM human_row.result_hash
       OR p_rejection_authority_hash IS DISTINCT FROM human_row.rejection_authority_hash THEN
      RAISE EXCEPTION 'm1a_c1_human_outcome_authority_mismatch';
    END IF;
  ELSE
    RAISE EXCEPTION 'm1a_c1_reconciliation_method_invalid';
  END IF;
  IF p_outcome<>expected_outcome OR p_outcome NOT IN ('PENDING','UNKNOWN','COMPLETE','TERMINAL_REJECTED') THEN
    RAISE EXCEPTION 'm1a_c1_reconciliation_outcome_invalid';
  END IF;
  expected_hash:=old_mike_production_private.hash_parts(
    p_workspace_id,p_project_id,p_job_id,'1',attempt_row.provider_class,
    attempt_row.provider_request_id,attempt_row.request_hash,attempt_row.request_authority_hash,
    attempt_row.external_ledger_key_hash,attempt_row.external_ledger_commitment_hash,
    p_method,p_evidence_id,p_outcome,p_result_hash,p_rejection_authority_hash
  );
  IF p_observation_hash<>expected_hash THEN RAISE EXCEPTION 'm1a_c1_reconciliation_observation_hash_invalid'; END IF;
  INSERT INTO old_mike_production_private.reconciliation_observations (
    workspace_id,project_id,observation_id,job_id,attempt_no,provider_class,
    provider_request_id,request_hash,request_authority_hash,external_ledger_key_hash,
    external_ledger_commitment_hash,method,lookup_receipt_id,webhook_id,human_authority_id,
    outcome,result_hash,rejection_authority_hash,observation_hash
  ) VALUES (
    p_workspace_id,p_project_id,p_observation_id,p_job_id,1,attempt_row.provider_class,
    attempt_row.provider_request_id,attempt_row.request_hash,attempt_row.request_authority_hash,
    attempt_row.external_ledger_key_hash,attempt_row.external_ledger_commitment_hash,p_method,
    CASE WHEN p_method='LOOKUP' THEN p_evidence_id END,
    CASE WHEN p_method='SIGNED_WEBHOOK' THEN p_evidence_id END,
    CASE WHEN p_method='AUTHORIZED_HUMAN' THEN p_evidence_id END,
    p_outcome,p_result_hash,p_rejection_authority_hash,p_observation_hash
  );
  IF p_method='SIGNED_WEBHOOK' THEN
    UPDATE old_mike_production_private.webhook_inbox SET state='APPLIED',
      lease_owner_hash=NULL,lease_expires_at=NULL,applied_observation_id=p_observation_id,
      terminal_at=pg_catalog.statement_timestamp()
     WHERE workspace_id=p_workspace_id AND project_id=p_project_id AND webhook_id=p_evidence_id;
  END IF;
  IF p_outcome IN ('PENDING','UNKNOWN') THEN
    IF p_event_id IS NOT NULL OR p_snapshot_payload IS NOT NULL THEN RAISE EXCEPTION 'm1a_c1_nonterminal_reconcile_forbids_truth_delta'; END IF;
    RETURN QUERY
      SELECT 'OBSERVED_NO_TRUTH_ADVANCE'::text,'COMPLETION_UNKNOWN'::text,NULL::text,
             snapshot_value.revision,snapshot_value.content_hash::text
        FROM old_mike_production_private.project_snapshots snapshot_value
       WHERE snapshot_value.workspace_id=p_workspace_id AND snapshot_value.project_id=p_project_id
       ORDER BY snapshot_value.revision DESC LIMIT 1;
    RETURN;
  END IF;
  IF p_event_id IS NULL THEN RAISE EXCEPTION 'm1a_c1_terminal_reconciliation_event_required'; END IF;
  IF p_outcome='COMPLETE' THEN
    PERFORM old_mike_production_private.append_provider_receipt(
      p_workspace_id,p_project_id,p_job_id,'COMPLETION_OBSERVED',p_observation_hash,p_result_hash,NULL,NULL,NULL
    );
    UPDATE old_mike_production_private.provider_attempts SET state='SUCCEEDED',
      terminal_at=pg_catalog.statement_timestamp(),terminal_result_hash=p_result_hash
     WHERE workspace_id=p_workspace_id AND project_id=p_project_id AND job_id=p_job_id AND attempt_no=1;
    UPDATE old_mike_production_private.ai_jobs SET state='SUCCEEDED',
      terminal_at=pg_catalog.statement_timestamp(),terminal_outcome_hash=p_result_hash,
      updated_at=pg_catalog.statement_timestamp()
     WHERE workspace_id=p_workspace_id AND project_id=p_project_id AND job_id=p_job_id;
  ELSE
    IF p_snapshot_payload IS NOT NULL OR p_snapshot_payload_hash IS NOT NULL OR p_snapshot_content_hash IS NOT NULL THEN
      RAISE EXCEPTION 'm1a_c1_rejected_reconcile_forbids_snapshot';
    END IF;
    PERFORM old_mike_production_private.append_provider_receipt(
      p_workspace_id,p_project_id,p_job_id,'TERMINAL_REJECTED',p_observation_hash,NULL,p_rejection_authority_hash,NULL,'RECONCILED_REJECTED'
    );
    UPDATE old_mike_production_private.provider_attempts SET state='TERMINAL_REJECTED',
      terminal_at=pg_catalog.statement_timestamp(),terminal_rejection_hash=p_rejection_authority_hash
     WHERE workspace_id=p_workspace_id AND project_id=p_project_id AND job_id=p_job_id AND attempt_no=1;
    UPDATE old_mike_production_private.ai_jobs SET state='TERMINAL_REJECTED',
      terminal_at=pg_catalog.statement_timestamp(),terminal_outcome_hash=p_rejection_authority_hash,
      updated_at=pg_catalog.statement_timestamp()
     WHERE workspace_id=p_workspace_id AND project_id=p_project_id AND job_id=p_job_id;
  END IF;
  SELECT * INTO STRICT event_row FROM old_mike_production_private.commit_job_event(
    p_workspace_id,p_project_id,p_job_id,p_event_id,
    CASE WHEN p_outcome='COMPLETE' THEN 'RECONCILIATION_COMPLETE' ELSE 'RECONCILIATION_REJECTED' END,
    p_result_hash,p_rejection_authority_hash,NULL,p_snapshot_schema_version,p_snapshot_payload,
    p_snapshot_payload_hash,p_snapshot_content_hash,p_outcome='COMPLETE',false
  );
  RETURN QUERY SELECT 'COMMITTED'::text,
    CASE WHEN p_outcome='COMPLETE' THEN 'SUCCEEDED' ELSE 'TERMINAL_REJECTED' END,
    event_row.event_hash::text,event_row.snapshot_revision,event_row.snapshot_content_hash::text;
END
$function$;

CREATE FUNCTION old_mike_production_private.record_usage(
  p_workspace_id text,p_project_id text,p_job_id text,p_reservation_id text,
  p_usage_id text,p_consumed_units bigint,p_cost_minor bigint,p_provider_usage_receipt_hash text
)
RETURNS TABLE(disposition text,usage_id text)
LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog
AS $function$
DECLARE reservation_row old_mike_production_private.budget_reservations%ROWTYPE;
  attempt_row old_mike_production_private.provider_attempts%ROWTYPE;
  used_units bigint; used_cost bigint; expected_hash text;
  existing old_mike_production_private.usage_ledger%ROWTYPE;
BEGIN
  SELECT * INTO STRICT reservation_row FROM old_mike_production_private.budget_reservations row_value
   WHERE row_value.workspace_id=p_workspace_id AND row_value.project_id=p_project_id
     AND row_value.reservation_id=p_reservation_id FOR SHARE;
  SELECT * INTO STRICT attempt_row FROM old_mike_production_private.provider_attempts row_value
   WHERE row_value.workspace_id=p_workspace_id AND row_value.project_id=p_project_id
     AND row_value.job_id=p_job_id AND row_value.attempt_no=1 FOR SHARE;
  IF reservation_row.job_id<>p_job_id THEN RAISE EXCEPTION 'm1a_c1_cross_job_budget_usage_forbidden'; END IF;
  expected_hash:=old_mike_production_private.hash_parts(
    p_workspace_id,p_project_id,p_usage_id,p_reservation_id,p_job_id,
    attempt_row.provider_class,attempt_row.provider_request_id,attempt_row.request_hash,
    reservation_row.currency,reservation_row.unit,reservation_row.policy_id,
    reservation_row.policy_version::text,reservation_row.policy_hash,
    p_consumed_units::text,p_cost_minor::text
  );
  IF p_provider_usage_receipt_hash<>expected_hash THEN RAISE EXCEPTION 'm1a_c1_usage_receipt_hash_invalid'; END IF;
  SELECT * INTO existing FROM old_mike_production_private.usage_ledger row_value
   WHERE row_value.workspace_id=p_workspace_id AND row_value.project_id=p_project_id
     AND row_value.usage_id=p_usage_id;
  IF FOUND THEN
    IF existing.provider_usage_receipt_hash=p_provider_usage_receipt_hash THEN
      RETURN QUERY SELECT 'REPLAYED'::text,p_usage_id; RETURN;
    END IF;
    RAISE EXCEPTION 'm1a_c1_usage_conflict';
  END IF;
  SELECT COALESCE(pg_catalog.sum(row_value.consumed_units),0),COALESCE(pg_catalog.sum(row_value.cost_minor),0)
    INTO used_units,used_cost FROM old_mike_production_private.usage_ledger row_value
   WHERE row_value.workspace_id=p_workspace_id AND row_value.project_id=p_project_id
     AND row_value.reservation_id=p_reservation_id;
  IF used_units+p_consumed_units>reservation_row.reserved_units
     OR used_cost+p_cost_minor>reservation_row.reserved_cost_minor THEN
    RAISE EXCEPTION 'm1a_c1_budget_reservation_exceeded';
  END IF;
  INSERT INTO old_mike_production_private.usage_ledger (
    workspace_id,project_id,usage_id,reservation_id,job_id,attempt_no,provider_class,
    provider_request_id,request_hash,request_authority_hash,external_ledger_key_hash,
    external_ledger_commitment_hash,currency,unit,policy_id,policy_version,policy_hash,
    consumed_units,cost_minor,provider_usage_receipt_hash
  ) VALUES (
    p_workspace_id,p_project_id,p_usage_id,p_reservation_id,p_job_id,1,attempt_row.provider_class,
    attempt_row.provider_request_id,attempt_row.request_hash,attempt_row.request_authority_hash,
    attempt_row.external_ledger_key_hash,attempt_row.external_ledger_commitment_hash,
    reservation_row.currency,reservation_row.unit,reservation_row.policy_id,
    reservation_row.policy_version,reservation_row.policy_hash,p_consumed_units,p_cost_minor,
    p_provider_usage_receipt_hash
  );
  RETURN QUERY SELECT 'RECORDED'::text,p_usage_id;
END
$function$;

CREATE FUNCTION old_mike_production_private.request_human_gate(
  p_workspace_id text,p_tenant_id text,p_project_id text,p_actor_user_id text,
  p_gate_request_id text,p_snapshot_revision bigint,p_snapshot_content_hash text,
  p_operation text,p_schema_version text,p_authority_payload jsonb,p_authority_payload_hash text
)
RETURNS TABLE(disposition text,gate_request_id text)
LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog
AS $function$
DECLARE expected_payload jsonb; existing old_mike_production_private.human_gate_requests%ROWTYPE;
  head_row old_mike_production_private.project_snapshots%ROWTYPE;
BEGIN
  IF p_tenant_id<>p_workspace_id THEN RAISE EXCEPTION 'm1a_c1_tenant_workspace_mismatch'; END IF;
  PERFORM old_mike_production_private.assert_active_member(p_workspace_id,p_project_id,p_actor_user_id);
  PERFORM 1 FROM public.projects project_row
   WHERE project_row.workspace_id=p_workspace_id AND project_row.project_id=p_project_id FOR UPDATE;
  SELECT * INTO STRICT head_row FROM old_mike_production_private.project_snapshots row_value
   WHERE row_value.workspace_id=p_workspace_id AND row_value.project_id=p_project_id
   ORDER BY row_value.revision DESC LIMIT 1 FOR SHARE;
  IF head_row.revision<>p_snapshot_revision OR head_row.content_hash<>p_snapshot_content_hash THEN
    RAISE EXCEPTION 'm1a_c1_gate_requires_current_snapshot';
  END IF;
  expected_payload:=pg_catalog.jsonb_build_object(
    'actorUserId',p_actor_user_id,'gateRequestId',p_gate_request_id,
    'operation',p_operation,'projectId',p_project_id,'schemaVersion',p_schema_version,
    'snapshotContentHash',p_snapshot_content_hash,'snapshotRevision',p_snapshot_revision,
    'tenantId',p_tenant_id,'workspaceId',p_workspace_id
  );
  PERFORM old_mike_production_private.assert_exact_payload(
    p_authority_payload,expected_payload,p_authority_payload_hash
  );
  SELECT * INTO existing FROM old_mike_production_private.human_gate_requests row_value
   WHERE row_value.workspace_id=p_workspace_id AND row_value.project_id=p_project_id
     AND row_value.gate_request_id=p_gate_request_id;
  IF FOUND THEN
    IF existing.authority_payload_hash=p_authority_payload_hash THEN
      RETURN QUERY SELECT 'REPLAYED'::text,p_gate_request_id; RETURN;
    END IF;
    RAISE EXCEPTION 'm1a_c1_gate_request_conflict';
  END IF;
  INSERT INTO old_mike_production_private.human_gate_requests (
    workspace_id,tenant_id,project_id,gate_request_id,snapshot_revision,snapshot_content_hash,
    actor_user_id,operation,schema_version,authority_payload,authority_payload_hash
  ) VALUES (
    p_workspace_id,p_tenant_id,p_project_id,p_gate_request_id,p_snapshot_revision,
    p_snapshot_content_hash,p_actor_user_id,p_operation,p_schema_version,
    p_authority_payload,p_authority_payload_hash
  );
  RETURN QUERY SELECT 'CREATED'::text,p_gate_request_id;
END
$function$;

CREATE FUNCTION old_mike_production_private.decide_human_gate(
  p_workspace_id text,p_project_id text,p_gate_request_id text,
  p_decision text,p_decision_actor_user_id text,p_decision_hash text
)
RETURNS TABLE(disposition text,decision text,decision_hash text)
LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog
AS $function$
DECLARE request_row old_mike_production_private.human_gate_requests%ROWTYPE;
  existing old_mike_production_private.human_gate_decisions%ROWTYPE;
  expected_hash text;
BEGIN
  IF p_decision NOT IN ('CONFIRMED','REJECTED') THEN RAISE EXCEPTION 'm1a_c1_gate_decision_invalid'; END IF;
  PERFORM old_mike_production_private.assert_active_member(p_workspace_id,p_project_id,p_decision_actor_user_id);
  SELECT * INTO STRICT request_row FROM old_mike_production_private.human_gate_requests row_value
   WHERE row_value.workspace_id=p_workspace_id AND row_value.project_id=p_project_id
     AND row_value.gate_request_id=p_gate_request_id FOR UPDATE;
  expected_hash:=old_mike_production_private.hash_parts(
    p_workspace_id,p_project_id,p_gate_request_id,request_row.snapshot_revision::text,
    request_row.snapshot_content_hash,request_row.authority_payload_hash,
    p_decision,p_decision_actor_user_id
  );
  IF p_decision_hash<>expected_hash THEN RAISE EXCEPTION 'm1a_c1_gate_decision_hash_invalid'; END IF;
  SELECT * INTO existing FROM old_mike_production_private.human_gate_decisions row_value
   WHERE row_value.workspace_id=p_workspace_id AND row_value.project_id=p_project_id
     AND row_value.gate_request_id=p_gate_request_id;
  IF FOUND THEN
    IF existing.decision=p_decision AND existing.decision_hash=p_decision_hash
       AND existing.decision_actor_user_id=p_decision_actor_user_id THEN
      RETURN QUERY SELECT 'REPLAYED'::text,existing.decision,existing.decision_hash::text; RETURN;
    END IF;
    RAISE EXCEPTION 'm1a_c1_gate_already_decided';
  END IF;
  INSERT INTO old_mike_production_private.human_gate_decisions (
    workspace_id,tenant_id,project_id,gate_request_id,decision,
    decision_actor_user_id,decision_hash
  ) VALUES (
    p_workspace_id,request_row.tenant_id,p_project_id,p_gate_request_id,p_decision,
    p_decision_actor_user_id,p_decision_hash
  );
  RETURN QUERY SELECT 'DECIDED'::text,p_decision,p_decision_hash;
END
$function$;

CREATE FUNCTION old_mike_production_private.authorize_formal_effect(
  p_workspace_id text,p_project_id text,p_formal_effect_id text,p_gate_request_id text,
  p_actor_user_id text,p_dispatch_id text,p_schema_version text,
  p_authority_payload jsonb,p_authority_payload_hash text,p_authorization_hash text
)
RETURNS TABLE(disposition text,formal_effect_id text,dispatch_id text,authorization_hash text)
LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog
AS $function$
DECLARE request_row old_mike_production_private.human_gate_requests%ROWTYPE;
  decision_row old_mike_production_private.human_gate_decisions%ROWTYPE;
  head_row old_mike_production_private.project_snapshots%ROWTYPE;
  existing old_mike_production_private.formal_effect_authorizations%ROWTYPE;
  expected_payload jsonb; expected_hash text; dispatch_payload jsonb;
BEGIN
  PERFORM old_mike_production_private.assert_active_member(p_workspace_id,p_project_id,p_actor_user_id);
  PERFORM 1 FROM public.projects project_row
   WHERE project_row.workspace_id=p_workspace_id AND project_row.project_id=p_project_id FOR UPDATE;
  SELECT * INTO STRICT request_row FROM old_mike_production_private.human_gate_requests row_value
   WHERE row_value.workspace_id=p_workspace_id AND row_value.project_id=p_project_id
     AND row_value.gate_request_id=p_gate_request_id FOR SHARE;
  SELECT * INTO STRICT decision_row FROM old_mike_production_private.human_gate_decisions row_value
   WHERE row_value.workspace_id=p_workspace_id AND row_value.project_id=p_project_id
     AND row_value.gate_request_id=p_gate_request_id FOR SHARE;
  IF decision_row.decision<>'CONFIRMED' THEN RAISE EXCEPTION 'm1a_c1_formal_effect_requires_confirmed_gate'; END IF;
  SELECT * INTO STRICT head_row FROM old_mike_production_private.project_snapshots row_value
   WHERE row_value.workspace_id=p_workspace_id AND row_value.project_id=p_project_id
   ORDER BY row_value.revision DESC LIMIT 1 FOR SHARE;
  IF head_row.revision<>request_row.snapshot_revision OR head_row.content_hash<>request_row.snapshot_content_hash THEN
    RAISE EXCEPTION 'm1a_c1_formal_effect_snapshot_drift';
  END IF;
  expected_payload:=pg_catalog.jsonb_build_object(
    'actorUserId',p_actor_user_id,'formalEffectId',p_formal_effect_id,
    'gateDecisionHash',decision_row.decision_hash,'gateRequestId',p_gate_request_id,
    'operation',request_row.operation,'projectId',p_project_id,'schemaVersion',p_schema_version,
    'snapshotContentHash',request_row.snapshot_content_hash,
    'snapshotRevision',request_row.snapshot_revision,'tenantId',request_row.tenant_id,
    'workspaceId',p_workspace_id
  );
  PERFORM old_mike_production_private.assert_exact_payload(
    p_authority_payload,expected_payload,p_authority_payload_hash
  );
  expected_hash:=old_mike_production_private.hash_parts(
    p_workspace_id,p_project_id,p_formal_effect_id,p_gate_request_id,
    decision_row.decision_hash,request_row.snapshot_revision::text,
    request_row.snapshot_content_hash,p_actor_user_id,request_row.operation,
    p_schema_version,p_authority_payload_hash
  );
  IF p_authorization_hash<>expected_hash THEN RAISE EXCEPTION 'm1a_c1_formal_authorization_hash_invalid'; END IF;
  SELECT * INTO existing FROM old_mike_production_private.formal_effect_authorizations row_value
   WHERE row_value.workspace_id=p_workspace_id AND row_value.project_id=p_project_id
     AND (row_value.formal_effect_id=p_formal_effect_id OR row_value.gate_request_id=p_gate_request_id)
   LIMIT 1;
  IF FOUND THEN
    IF existing.formal_effect_id=p_formal_effect_id AND existing.authorization_hash=p_authorization_hash THEN
      RETURN QUERY
        SELECT 'REPLAYED'::text,p_formal_effect_id,outbox_row.dispatch_id::text,p_authorization_hash
          FROM old_mike_production_private.dispatch_outbox outbox_row
         WHERE outbox_row.workspace_id=p_workspace_id AND outbox_row.project_id=p_project_id
           AND outbox_row.formal_effect_id=p_formal_effect_id;
      RETURN;
    END IF;
    RAISE EXCEPTION 'm1a_c1_formal_authorization_conflict';
  END IF;
  INSERT INTO old_mike_production_private.formal_effect_authorizations (
    workspace_id,tenant_id,project_id,formal_effect_id,gate_request_id,gate_decision_hash,
    snapshot_revision,snapshot_content_hash,gate_request_actor_user_id,
    gate_request_schema_version,gate_request_payload_hash,actor_user_id,operation,schema_version,
    authority_payload,authority_payload_hash,authorization_hash
  ) VALUES (
    p_workspace_id,request_row.tenant_id,p_project_id,p_formal_effect_id,p_gate_request_id,
    decision_row.decision_hash,request_row.snapshot_revision,request_row.snapshot_content_hash,
    request_row.actor_user_id,request_row.schema_version,request_row.authority_payload_hash,p_actor_user_id,
    request_row.operation,p_schema_version,p_authority_payload,p_authority_payload_hash,
    p_authorization_hash
  );
  dispatch_payload:=pg_catalog.jsonb_build_object(
    'authorizationHash',p_authorization_hash,'formalEffectId',p_formal_effect_id,
    'kind','FORMAL_EFFECT_READY','projectId',p_project_id,
    'schemaVersion',p_schema_version,'workspaceId',p_workspace_id
  );
  INSERT INTO old_mike_production_private.dispatch_outbox (
    workspace_id,project_id,dispatch_id,formal_effect_id,authorization_hash,
    kind,schema_version,payload,payload_hash
  ) VALUES (
    p_workspace_id,p_project_id,p_dispatch_id,p_formal_effect_id,p_authorization_hash,
    'FORMAL_EFFECT_READY',p_schema_version,dispatch_payload,
    old_mike_production_private.canonical_json_hash(dispatch_payload)
  );
  RETURN QUERY SELECT 'AUTHORIZED'::text,p_formal_effect_id,p_dispatch_id,p_authorization_hash;
END
$function$;

CREATE FUNCTION old_mike_production_private.claim_dispatch_outbox(
  p_workspace_id text,p_project_id text,p_dispatch_id text,
  p_lease_owner_hash text,p_lease_seconds integer
)
RETURNS TABLE(disposition text,lease_generation bigint)
LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog
AS $function$
DECLARE row_value old_mike_production_private.dispatch_outbox%ROWTYPE;
BEGIN
  IF p_lease_seconds NOT BETWEEN 1 AND 300 THEN RAISE EXCEPTION 'm1a_c1_dispatch_lease_seconds_invalid'; END IF;
  SELECT * INTO STRICT row_value FROM old_mike_production_private.dispatch_outbox row_lock
   WHERE row_lock.workspace_id=p_workspace_id AND row_lock.project_id=p_project_id
     AND row_lock.dispatch_id=p_dispatch_id FOR UPDATE;
  IF EXISTS (SELECT 1 FROM old_mike_production_private.formal_effect_terminal_events event_row
      WHERE event_row.workspace_id=p_workspace_id AND event_row.project_id=p_project_id
        AND event_row.formal_effect_id=row_value.formal_effect_id) THEN
    RAISE EXCEPTION 'm1a_c1_terminal_formal_effect_not_dispatchable';
  END IF;
  IF row_value.state NOT IN ('PENDING','LEASED') THEN RAISE EXCEPTION 'm1a_c1_dispatch_not_claimable'; END IF;
  IF row_value.state='LEASED' AND row_value.lease_expires_at>pg_catalog.statement_timestamp() THEN
    RAISE EXCEPTION 'm1a_c1_dispatch_live_lease';
  END IF;
  UPDATE old_mike_production_private.dispatch_outbox SET state='LEASED',
    lease_generation=row_value.lease_generation+1,lease_owner_hash=p_lease_owner_hash,
    lease_expires_at=pg_catalog.statement_timestamp()+pg_catalog.make_interval(secs=>p_lease_seconds)
   WHERE workspace_id=p_workspace_id AND project_id=p_project_id AND dispatch_id=p_dispatch_id;
  RETURN QUERY SELECT 'LEASED'::text,row_value.lease_generation+1;
END
$function$;

CREATE FUNCTION old_mike_production_private.publish_dispatch_outbox(
  p_workspace_id text,p_project_id text,p_dispatch_id text,
  p_lease_owner_hash text,p_lease_generation bigint,p_message_id_hash text
)
RETURNS TABLE(disposition text,message_id_hash text)
LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog
AS $function$
DECLARE row_value old_mike_production_private.dispatch_outbox%ROWTYPE;
BEGIN
  SELECT * INTO STRICT row_value FROM old_mike_production_private.dispatch_outbox row_lock
   WHERE row_lock.workspace_id=p_workspace_id AND row_lock.project_id=p_project_id
     AND row_lock.dispatch_id=p_dispatch_id FOR UPDATE;
  IF row_value.state='PUBLISHED' THEN
    IF row_value.published_message_id_hash=p_message_id_hash THEN
      RETURN QUERY SELECT 'REPLAYED'::text,p_message_id_hash; RETURN;
    END IF;
    RAISE EXCEPTION 'm1a_c1_dispatch_publish_conflict';
  END IF;
  IF EXISTS (SELECT 1 FROM old_mike_production_private.formal_effect_terminal_events event_row
      WHERE event_row.workspace_id=p_workspace_id AND event_row.project_id=p_project_id
        AND event_row.formal_effect_id=row_value.formal_effect_id) THEN
    RAISE EXCEPTION 'm1a_c1_revoked_formal_effect_publish_forbidden';
  END IF;
  IF row_value.state<>'LEASED' OR row_value.lease_owner_hash<>p_lease_owner_hash
     OR row_value.lease_generation<>p_lease_generation
     OR row_value.lease_expires_at<=pg_catalog.statement_timestamp() THEN
    RAISE EXCEPTION 'm1a_c1_dispatch_stale_lease_commit';
  END IF;
  UPDATE old_mike_production_private.dispatch_outbox SET state='PUBLISHED',
    lease_owner_hash=NULL,lease_expires_at=NULL,published_message_id_hash=p_message_id_hash,
    published_at=pg_catalog.statement_timestamp()
   WHERE workspace_id=p_workspace_id AND project_id=p_project_id AND dispatch_id=p_dispatch_id;
  RETURN QUERY SELECT 'PUBLISHED'::text,p_message_id_hash;
END
$function$;

CREATE FUNCTION old_mike_production_private.terminalize_formal_effect(
  p_workspace_id text,p_project_id text,p_formal_effect_id text,p_actor_user_id text,
  p_outcome text,p_terminal_authority_hash text
)
RETURNS TABLE(disposition text,outcome text,terminal_authority_hash text)
LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog
AS $function$
DECLARE authorization_row old_mike_production_private.formal_effect_authorizations%ROWTYPE;
  outbox_row old_mike_production_private.dispatch_outbox%ROWTYPE;
  existing old_mike_production_private.formal_effect_terminal_events%ROWTYPE;
  expected_hash text;
BEGIN
  IF p_outcome NOT IN ('EXECUTED','REVOKED_BEFORE_EXECUTION') THEN RAISE EXCEPTION 'm1a_c1_formal_terminal_outcome_invalid'; END IF;
  PERFORM old_mike_production_private.assert_active_member(p_workspace_id,p_project_id,p_actor_user_id);
  PERFORM 1 FROM public.projects project_row
   WHERE project_row.workspace_id=p_workspace_id AND project_row.project_id=p_project_id FOR UPDATE;
  SELECT * INTO STRICT authorization_row FROM old_mike_production_private.formal_effect_authorizations row_value
   WHERE row_value.workspace_id=p_workspace_id AND row_value.project_id=p_project_id
     AND row_value.formal_effect_id=p_formal_effect_id FOR SHARE;
  SELECT * INTO STRICT outbox_row FROM old_mike_production_private.dispatch_outbox row_value
   WHERE row_value.workspace_id=p_workspace_id AND row_value.project_id=p_project_id
     AND row_value.formal_effect_id=p_formal_effect_id FOR UPDATE;
  IF (p_outcome='EXECUTED' AND outbox_row.state<>'PUBLISHED')
     OR (p_outcome='REVOKED_BEFORE_EXECUTION' AND outbox_row.state='PUBLISHED') THEN
    RAISE EXCEPTION 'm1a_c1_formal_terminal_dispatch_state_invalid';
  END IF;
  expected_hash:=old_mike_production_private.hash_parts(
    p_workspace_id,p_project_id,p_formal_effect_id,authorization_row.authorization_hash,
    p_outcome,p_actor_user_id
  );
  IF p_terminal_authority_hash<>expected_hash THEN RAISE EXCEPTION 'm1a_c1_formal_terminal_hash_invalid'; END IF;
  SELECT * INTO existing FROM old_mike_production_private.formal_effect_terminal_events row_value
   WHERE row_value.workspace_id=p_workspace_id AND row_value.project_id=p_project_id
     AND row_value.formal_effect_id=p_formal_effect_id;
  IF FOUND THEN
    IF existing.outcome=p_outcome AND existing.terminal_authority_hash=p_terminal_authority_hash THEN
      RETURN QUERY SELECT 'REPLAYED'::text,p_outcome,p_terminal_authority_hash; RETURN;
    END IF;
    RAISE EXCEPTION 'm1a_c1_formal_effect_already_terminal';
  END IF;
  INSERT INTO old_mike_production_private.formal_effect_terminal_events (
    workspace_id,project_id,formal_effect_id,authorization_hash,outcome,
    actor_user_id,terminal_authority_hash
  ) VALUES (
    p_workspace_id,p_project_id,p_formal_effect_id,authorization_row.authorization_hash,
    p_outcome,p_actor_user_id,p_terminal_authority_hash
  );
  RETURN QUERY SELECT 'TERMINALIZED'::text,p_outcome,p_terminal_authority_hash;
END
$function$;

REVOKE ALL PRIVILEGES ON SCHEMA old_mike_production_private FROM PUBLIC;
REVOKE ALL PRIVILEGES ON ALL TABLES IN SCHEMA old_mike_production_private
  FROM PUBLIC, old_mike_prod_web, old_mike_prod_worker, old_mike_prod_relay, old_mike_prod_observer;
REVOKE ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA old_mike_production_private
  FROM PUBLIC, old_mike_prod_web, old_mike_prod_worker, old_mike_prod_relay, old_mike_prod_observer;
REVOKE ALL PRIVILEGES ON ALL FUNCTIONS IN SCHEMA old_mike_production_private
  FROM PUBLIC, old_mike_prod_web, old_mike_prod_worker, old_mike_prod_relay, old_mike_prod_observer;

GRANT USAGE ON SCHEMA old_mike_production_private
  TO old_mike_prod_web, old_mike_prod_worker, old_mike_prod_relay, old_mike_prod_observer;
GRANT SELECT ON old_mike_production_private.observer_job_metrics,
                old_mike_production_private.observer_queue_metrics,
                old_mike_production_private.observer_usage_metrics
  TO old_mike_prod_observer;

GRANT EXECUTE ON FUNCTION old_mike_production_private.bootstrap_project_snapshot
  TO old_mike_prod_web;
GRANT EXECUTE ON FUNCTION old_mike_production_private.create_ai_job
  TO old_mike_prod_web;
GRANT EXECUTE ON FUNCTION old_mike_production_private.request_human_gate
  TO old_mike_prod_web;
GRANT EXECUTE ON FUNCTION old_mike_production_private.decide_human_gate
  TO old_mike_prod_web;
GRANT EXECUTE ON FUNCTION old_mike_production_private.authorize_formal_effect
  TO old_mike_prod_web;
GRANT EXECUTE ON FUNCTION old_mike_production_private.authorize_human_reconciliation
  TO old_mike_prod_web;
GRANT EXECUTE ON FUNCTION old_mike_production_private.terminalize_formal_effect
  TO old_mike_prod_web;

GRANT EXECUTE ON FUNCTION old_mike_production_private.claim_ai_job
  TO old_mike_prod_worker;
GRANT EXECUTE ON FUNCTION old_mike_production_private.reserve_budget
  TO old_mike_prod_worker;
GRANT EXECUTE ON FUNCTION old_mike_production_private.prepare_provider_attempt
  TO old_mike_prod_worker;
GRANT EXECUTE ON FUNCTION old_mike_production_private.begin_provider_io
  TO old_mike_prod_worker;
GRANT EXECUTE ON FUNCTION old_mike_production_private.commit_provider_outcome
  TO old_mike_prod_worker;
GRANT EXECUTE ON FUNCTION old_mike_production_private.record_provider_lookup
  TO old_mike_prod_worker;
GRANT EXECUTE ON FUNCTION old_mike_production_private.claim_provider_webhook
  TO old_mike_prod_worker;
GRANT EXECUTE ON FUNCTION old_mike_production_private.commit_reconciliation
  TO old_mike_prod_worker;
GRANT EXECUTE ON FUNCTION old_mike_production_private.record_usage
  TO old_mike_prod_worker;

GRANT EXECUTE ON FUNCTION old_mike_production_private.claim_ai_outbox
  TO old_mike_prod_relay;
GRANT EXECUTE ON FUNCTION old_mike_production_private.publish_ai_outbox
  TO old_mike_prod_relay;
GRANT EXECUTE ON FUNCTION old_mike_production_private.receive_provider_webhook
  TO old_mike_prod_relay;
GRANT EXECUTE ON FUNCTION old_mike_production_private.claim_dispatch_outbox
  TO old_mike_prod_relay;
GRANT EXECUTE ON FUNCTION old_mike_production_private.publish_dispatch_outbox
  TO old_mike_prod_relay;

ALTER DEFAULT PRIVILEGES FOR ROLE old_mike_prod_owner IN SCHEMA old_mike_production_private
  REVOKE ALL PRIVILEGES ON TABLES FROM PUBLIC;
ALTER DEFAULT PRIVILEGES FOR ROLE old_mike_prod_owner IN SCHEMA old_mike_production_private
  REVOKE ALL PRIVILEGES ON SEQUENCES FROM PUBLIC;
ALTER DEFAULT PRIVILEGES FOR ROLE old_mike_prod_owner IN SCHEMA old_mike_production_private
  REVOKE ALL PRIVILEGES ON FUNCTIONS FROM PUBLIC;

RESET ROLE;
COMMIT;
