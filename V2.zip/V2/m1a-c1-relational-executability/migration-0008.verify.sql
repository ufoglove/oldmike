\set ON_ERROR_STOP on

BEGIN READ ONLY;
SET LOCAL statement_timeout = '60s';
SET LOCAL lock_timeout = '5s';

DO $verify$
DECLARE
  actual text[];
  expected text[];
  role_name text;
  bad_count bigint;
BEGIN
  IF current_setting('server_version_num')::integer < 180000
     OR current_setting('server_version_num')::integer >= 190000 THEN
    RAISE EXCEPTION 'm1a_c1_verify_postgresql_18_required';
  END IF;

  expected := ARRAY[
    'account','account_admin_events','account_provisioning_state','audit_events',
    'portal_administrator','portal_rate_limits','project_artifacts','projects','rateLimit',
    'registration_invites','research_analysis_plans','research_analysis_runs',
    'research_claim_evidence','research_claims','research_datasets','research_documents',
    'research_evidence_sources','research_human_gates','research_studies',
    'research_topic_lab_promotions','research_topic_lab_runs','research_workflow_events',
    'session','user','user_consents','verification','workspace_members','workspaces'
  ]::text[];
  SELECT pg_catalog.array_agg(table_name ORDER BY table_name) INTO actual
    FROM information_schema.tables
   WHERE table_schema='public' AND table_type='BASE TABLE';
  IF actual IS DISTINCT FROM expected THEN
    RAISE EXCEPTION 'm1a_c1_baseline_object_set_mismatch:%', actual;
  END IF;

  expected := ARRAY[
    'ai_jobs','ai_outbox','authority_registry','budget_reservations','dispatch_outbox',
    'formal_effect_authorizations','formal_effect_terminal_events','human_gate_decisions',
    'human_gate_requests','human_reconciliation_authorities','migration_authority',
    'operation_intents','project_events','project_snapshots','provider_attempts',
    'provider_lookup_receipts','provider_receipts','reconciliation_observations',
    'registry_status_events','source_bundle_members','source_bundles','source_objects',
    'usage_ledger','webhook_inbox'
  ]::text[];
  SELECT pg_catalog.array_agg(table_name ORDER BY table_name) INTO actual
    FROM information_schema.tables
   WHERE table_schema='old_mike_production_private' AND table_type='BASE TABLE';
  IF actual IS DISTINCT FROM expected THEN
    RAISE EXCEPTION 'm1a_c1_private_table_set_mismatch:%', actual;
  END IF;

  expected := ARRAY['observer_job_metrics','observer_queue_metrics','observer_usage_metrics']::text[];
  SELECT pg_catalog.array_agg(table_name ORDER BY table_name) INTO actual
    FROM information_schema.views WHERE table_schema='old_mike_production_private';
  IF actual IS DISTINCT FROM expected THEN
    RAISE EXCEPTION 'm1a_c1_private_view_set_mismatch:%', actual;
  END IF;

  expected := ARRAY[
    'append_provider_receipt','assert_active_member','assert_exact_payload',
    'assert_registry_approved','authorize_formal_effect','authorize_human_reconciliation',
    'begin_provider_io','bootstrap_project_snapshot','canonical_json_hash','claim_ai_job',
    'claim_ai_outbox','claim_dispatch_outbox','claim_provider_webhook','commit_job_event',
    'commit_provider_outcome','commit_reconciliation','compute_source_bundle_hash',
    'create_ai_job','decide_human_gate','guard_attempt_mutation','guard_job_mutation',
    'guard_leased_message_mutation','guard_operation_intent_mutation',
    'guard_registry_status_insert','guard_webhook_mutation','hash_parts',
    'prepare_provider_attempt','publish_ai_outbox','publish_dispatch_outbox',
    'receive_provider_webhook','record_provider_lookup','record_usage',
    'reject_append_only_mutation','request_human_gate','reserve_budget',
    'terminalize_formal_effect'
  ]::text[];
  SELECT pg_catalog.array_agg(proc.proname ORDER BY proc.proname) INTO actual
    FROM pg_catalog.pg_proc proc
    JOIN pg_catalog.pg_namespace namespace_row ON namespace_row.oid=proc.pronamespace
   WHERE namespace_row.nspname='old_mike_production_private';
  IF actual IS DISTINCT FROM expected THEN
    RAISE EXCEPTION 'm1a_c1_private_function_set_mismatch:%', actual;
  END IF;

  expected := ARRAY[
    'ai_jobs_delete_guard','ai_jobs_guard','ai_outbox_delete_guard','ai_outbox_guard',
    'authority_registry_append_only','budget_reservations_append_only',
    'dispatch_outbox_delete_guard','dispatch_outbox_guard',
    'formal_effect_authorizations_append_only','formal_effect_terminal_events_append_only',
    'human_gate_decisions_append_only','human_gate_requests_append_only',
    'human_reconciliation_authorities_append_only','migration_authority_append_only',
    'operation_intents_delete_guard','operation_intents_guard','project_events_append_only',
    'project_snapshots_append_only','provider_attempts_delete_guard','provider_attempts_guard',
    'provider_lookup_receipts_append_only','provider_receipts_append_only',
    'reconciliation_observations_append_only','registry_status_events_append_only',
    'registry_status_events_insert_guard','source_bundle_members_append_only',
    'source_bundles_append_only','source_objects_append_only','usage_ledger_append_only',
    'webhook_inbox_delete_guard','webhook_inbox_guard'
  ]::text[];
  SELECT pg_catalog.array_agg(trigger_row.tgname ORDER BY trigger_row.tgname) INTO actual
    FROM pg_catalog.pg_trigger trigger_row
    JOIN pg_catalog.pg_class class_row ON class_row.oid=trigger_row.tgrelid
    JOIN pg_catalog.pg_namespace namespace_row ON namespace_row.oid=class_row.relnamespace
   WHERE namespace_row.nspname='old_mike_production_private' AND NOT trigger_row.tgisinternal;
  IF actual IS DISTINCT FROM expected THEN
    RAISE EXCEPTION 'm1a_c1_private_trigger_set_mismatch:%', actual;
  END IF;

  SELECT pg_catalog.count(*) INTO bad_count
    FROM pg_catalog.pg_class class_row
    JOIN pg_catalog.pg_namespace namespace_row ON namespace_row.oid=class_row.relnamespace
    JOIN pg_catalog.pg_roles owner_row ON owner_row.oid=class_row.relowner
   WHERE namespace_row.nspname='old_mike_production_private'
     AND class_row.relkind IN ('r','v','S') AND owner_row.rolname<>'old_mike_prod_owner';
  IF bad_count<>0 THEN RAISE EXCEPTION 'm1a_c1_private_object_owner_invalid:%',bad_count; END IF;

  SELECT pg_catalog.count(*) INTO bad_count
    FROM pg_catalog.pg_proc proc
    JOIN pg_catalog.pg_namespace namespace_row ON namespace_row.oid=proc.pronamespace
    JOIN pg_catalog.pg_roles owner_row ON owner_row.oid=proc.proowner
   WHERE namespace_row.nspname='old_mike_production_private'
     AND (owner_row.rolname<>'old_mike_prod_owner'
       OR proc.proconfig IS DISTINCT FROM ARRAY['search_path=pg_catalog']::text[]);
  IF bad_count<>0 THEN RAISE EXCEPTION 'm1a_c1_function_owner_or_search_path_invalid:%',bad_count; END IF;

  SELECT pg_catalog.count(*) INTO bad_count
    FROM pg_catalog.pg_proc proc
    JOIN pg_catalog.pg_namespace namespace_row ON namespace_row.oid=proc.pronamespace
   WHERE namespace_row.nspname='old_mike_production_private'
     AND proc.prosecdef AND proc.prosrc ~ '\mEXECUTE\M';
  IF bad_count<>0 THEN RAISE EXCEPTION 'm1a_c1_security_definer_dynamic_sql_forbidden:%',bad_count; END IF;

  SELECT pg_catalog.count(*) INTO bad_count
    FROM pg_catalog.pg_constraint constraint_row
    JOIN pg_catalog.pg_namespace namespace_row ON namespace_row.oid=constraint_row.connamespace
   WHERE namespace_row.nspname='old_mike_production_private' AND NOT constraint_row.convalidated;
  IF bad_count<>0 THEN RAISE EXCEPTION 'm1a_c1_unvalidated_constraint_forbidden:%',bad_count; END IF;

  FOREACH role_name IN ARRAY ARRAY[
    'old_mike_prod_owner','old_mike_prod_migrator','old_mike_prod_web',
    'old_mike_prod_worker','old_mike_prod_relay','old_mike_prod_observer'
  ] LOOP
    SELECT pg_catalog.count(*) INTO bad_count FROM pg_catalog.pg_roles role_row
     WHERE role_row.rolname=role_name AND NOT role_row.rolsuper AND NOT role_row.rolinherit
       AND NOT role_row.rolcreaterole AND NOT role_row.rolcreatedb AND NOT role_row.rolcanlogin
       AND NOT role_row.rolreplication AND NOT role_row.rolbypassrls;
    IF bad_count<>1 THEN RAISE EXCEPTION 'm1a_c1_role_posture_invalid:%',role_name; END IF;
  END LOOP;

  SELECT pg_catalog.count(*) INTO bad_count
    FROM pg_catalog.pg_auth_members membership
    JOIN pg_catalog.pg_roles granted_role ON granted_role.oid=membership.roleid
    JOIN pg_catalog.pg_roles member_role ON member_role.oid=membership.member
   WHERE granted_role.rolname='old_mike_prod_owner'
     AND member_role.rolname='old_mike_prod_migrator'
     AND NOT membership.admin_option AND NOT membership.inherit_option AND membership.set_option;
  IF bad_count<>1 THEN RAISE EXCEPTION 'm1a_c1_owner_migrator_membership_invalid'; END IF;

  FOREACH role_name IN ARRAY ARRAY[
    'old_mike_prod_web','old_mike_prod_worker','old_mike_prod_relay','old_mike_prod_observer'
  ] LOOP
    SELECT pg_catalog.count(*) INTO bad_count
      FROM pg_catalog.pg_class class_row
      JOIN pg_catalog.pg_namespace namespace_row ON namespace_row.oid=class_row.relnamespace
     WHERE namespace_row.nspname='old_mike_production_private' AND class_row.relkind='r'
       AND (pg_catalog.has_table_privilege(role_name,class_row.oid,'INSERT')
         OR pg_catalog.has_table_privilege(role_name,class_row.oid,'UPDATE')
         OR pg_catalog.has_table_privilege(role_name,class_row.oid,'DELETE')
         OR pg_catalog.has_table_privilege(role_name,class_row.oid,'TRUNCATE'));
    IF bad_count<>0 THEN RAISE EXCEPTION 'm1a_c1_raw_dml_grant_forbidden:%:%',role_name,bad_count; END IF;
  END LOOP;

  SELECT pg_catalog.count(*) INTO bad_count
    FROM pg_catalog.pg_proc proc
    JOIN pg_catalog.pg_namespace namespace_row ON namespace_row.oid=proc.pronamespace
   WHERE namespace_row.nspname='old_mike_production_private'
     AND pg_catalog.has_function_privilege('public',proc.oid,'EXECUTE');
  IF bad_count<>0 THEN RAISE EXCEPTION 'm1a_c1_public_function_execute_forbidden:%',bad_count; END IF;

  SELECT pg_catalog.count(*) INTO bad_count
    FROM old_mike_production_private.migration_authority row_value
   WHERE row_value.migration_id='0008_production_ai_foundation'
     AND row_value.schema_version='old-mike-v2-production-ai/migration-0008/1'
     AND row_value.applied_by_role='old_mike_prod_owner'
     AND pg_catalog.jsonb_array_length(row_value.baseline_files)=14;
  IF bad_count<>1 THEN RAISE EXCEPTION 'm1a_c1_migration_authority_invalid'; END IF;

  IF pg_catalog.has_table_privilege('old_mike_prod_observer','public."user"','SELECT')
     OR pg_catalog.has_table_privilege('old_mike_prod_observer','public.projects','SELECT')
     OR NOT pg_catalog.has_table_privilege(
       'old_mike_prod_observer','old_mike_production_private.observer_job_metrics','SELECT'
     ) THEN
    RAISE EXCEPTION 'm1a_c1_observer_privilege_boundary_invalid';
  END IF;
END
$verify$;

SELECT pg_catalog.jsonb_build_object(
  'baselineTableCount',(
    SELECT pg_catalog.count(*) FROM information_schema.tables
     WHERE table_schema='public' AND table_type='BASE TABLE'
  ),
  'constraintCount',(
    SELECT pg_catalog.count(*) FROM pg_catalog.pg_constraint constraint_row
    JOIN pg_catalog.pg_namespace namespace_row ON namespace_row.oid=constraint_row.connamespace
    WHERE namespace_row.nspname='old_mike_production_private'
  ),
  'functionCount',(
    SELECT pg_catalog.count(*) FROM pg_catalog.pg_proc proc
    JOIN pg_catalog.pg_namespace namespace_row ON namespace_row.oid=proc.pronamespace
    WHERE namespace_row.nspname='old_mike_production_private'
  ),
  'schema','old_mike_production_private',
  'status','PASS',
  'tableCount',(
    SELECT pg_catalog.count(*) FROM information_schema.tables
     WHERE table_schema='old_mike_production_private' AND table_type='BASE TABLE'
  ),
  'triggerCount',(
    SELECT pg_catalog.count(*) FROM pg_catalog.pg_trigger trigger_row
    JOIN pg_catalog.pg_class class_row ON class_row.oid=trigger_row.tgrelid
    JOIN pg_catalog.pg_namespace namespace_row ON namespace_row.oid=class_row.relnamespace
    WHERE namespace_row.nspname='old_mike_production_private' AND NOT trigger_row.tgisinternal
  ),
  'viewCount',(
    SELECT pg_catalog.count(*) FROM information_schema.views
     WHERE table_schema='old_mike_production_private'
  )
)::text AS verification_result;

ROLLBACK;
