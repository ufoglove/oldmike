# Security, data-flow, and threat model

## Trust boundaries

- Better Auth session plus active workspace membership and active nonlegacy
  project is the entry authority. Unknown/cross-tenant/project is generic 404
  before truth or provider effects.
- Web/BFF, worker and relay use distinct NOLOGIN database roles through
  workload login/identity mapping. No role inherits another.
- All new relational writes are exact owner-owned `SECURITY DEFINER`
  capabilities with `search_path=pg_catalog`; application roles have no raw
  table DML.
- Raw materials are versioned object bytes. PostgreSQL stores immutable object
  version, byte length and hash plus ordered bundle membership.
- Provider output is untrusted advisory data. Host parser/domain/evidence and
  Human Gate logic own all IDs, hashes, citations and formal-effect authority.

## Data flow

1. Authenticated command resolves exact tenant/project and operation tuple.
2. PostgreSQL validates source bundle and approved registry/policy tuples, then
   atomically records intent, queued job and typed outbox.
3. Relay publishes only IDs/hashes. Queue payload has no source text, provider
   body, credential, auth token or secret.
4. Worker claims by DB time/generation, locks budget, and conditionally creates
   the external egress-ledger item.
5. PostgreSQL records MAY_HAVE_SUBMITTED before provider I/O. Broker verifies
   ledger, egress policy, provider config and exact request authority.
6. Strict outcome parsing commits immutable attempt receipts and either project
   truth, terminal rejection, proven-not-submitted, or completion unknown.
7. Unknown is reconciled only by exact lookup, signed recoverable webhook, or
   separately authorized active-member decision.
8. Human Gate and formal effect require separate append-only request/decision,
   authorization/outbox, and terminal-event authorities.

## Principal threats and controls

- **Tenant/project swap:** composite FKs, member check under project lock,
  generic 404, cross-tenant capability tests.
- **SQL owner/search-path takeover:** private owner schema, fully qualified
  objects, pg_catalog-only definer search path, exact owner/proconfig verifier,
  no dynamic SQL, PUBLIC execute revoked.
- **Privilege inheritance/bypass:** NOLOGIN/NOINHERIT/NOSUPERUSER/NOBYPASSRLS
  roles, exact membership options, default-deny ACLs, effective privilege
  tests, no observer `ALL TABLES` grant.
- **Operation replay/conflict:** global key/request uniqueness and immutable
  canonical tuple; exact replay returns original result; mismatch is zero-effect
  conflict.
- **Queue duplication:** PostgreSQL business idempotency plus typed outbox and
  worker lease; SQS deduplication is only transport help.
- **Provider double submission:** external conditional ledger primary fence,
  PostgreSQL MAY_HAVE_SUBMITTED before I/O, one attempt, no unknown retry,
  provider-native key secondary.
- **PITR duplicate after restore:** broker disabled; external ledger plus exact
  provider lookup/webhook reconciliation required before re-enable.
- **Lease theft/stale commit:** database time, monotonic generation, exact token
  checked on every commit; expired recovery is one CAS.
- **Webhook replay/stranding:** dedup tuple, immutable body-object authority,
  durable inbox lease and replay, signature/key version, atomic observation.
- **Human spoofing:** active membership plus separate immutable scope/policy/
  decision hash and timestamp; method-discriminated reconciliation.
- **Source normalization/substitution:** exact object version/bytes/hash,
  ordered bundle recomputation, ORIGINAL/DERIVATIVE separation.
- **Registry drift:** immutable id/version/hash/approval event, terminal
  retirement chain, exact job FKs and pre-I/O recheck.
- **Budget bypass:** job/policy/currency/unit-bound immutable reservation,
  append-only usage under lock, hard aggregate cap.
- **Human Gate/formal rewrite:** separate append-only rows, one decision and one
  terminal event, same-snapshot FKs, duplicate concurrency tests.
- **SSRF/egress:** web has no provider path; broker allowlists exact hosts,
  protocol, DNS/IP classes, redirects and byte/deadline limits.
- **CSP/client leakage:** no server module or environment/provider identity in
  client bundle; strict CSP and output encoding.
- **Log leakage:** only IDs, hashes, states, durations, bounded usage and
  sanitized codes; source text/provider bodies/auth secrets forbidden.

## Observer boundary

Observer receives SELECT only on explicit aggregate views containing states,
counts, timing buckets and usage aggregates. It receives no access to Better
Auth tables, workspace members, raw research tables, source/object identity,
provider request/response bodies, webhook bodies, decisions, credentials or
application rows. Default privileges do not grant future tables or functions.

## Unresolved decisions

AWS account/region capability, data residency, provider DPA/retention/training,
object retention/legal hold, backup retention, egress allowlist, model/prompt/
evaluation approval and production identity remain blocked. No secret value or
real research data is accessed by this package.

