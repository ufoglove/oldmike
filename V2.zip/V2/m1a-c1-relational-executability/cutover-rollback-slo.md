# Migration, cutover, rollback, and SLO boundary

## Preconditions

No executable M1 action begins until M0_C1 proves current public/control-plane,
database migration, backup/PITR and recoverable rollback identities. AWS
account/region capability evidence and Owner account, residency, retention,
provider and paid-service decisions must also pass.

## Expand and reconcile

1. Freeze exact source commit, OCI digest, migration files/digests and runtime
   configuration schema.
2. Capture a read-only production metadata baseline and backup/PITR authority.
3. Apply additive 0008 through the exact non-superuser migrator with statement
   and lock timeouts. No startup migration.
4. Verify owner, ACL, default ACL, schema, table, constraint, trigger, function,
   `proconfig`, FK and baseline N-1 compatibility before application traffic.
5. Backfill only immutable IDs/hashes/authority metadata in bounded batches.
   Never manufacture source bytes, evidence, citations, Human Gates or formal
   effects.
6. Reconcile every backfilled row against N-1 truth and report zero orphan,
   gap, cross-tenant, hash or chronology mismatch.
7. Enable dual-read comparison with old writes authoritative and provider
   execution disabled.
8. Canary the exact OCI digest with web/BFF only, then relay, then worker with
   deterministic fake traffic. Live provider remains disabled until M2.
9. Soak with invariant alarms, connection budget, queue age, lease recovery,
   idempotency and no-resend monitoring.
10. Contract old paths only after N-1 rollback window and exact reconciliation
    are complete.

## Rollback

Application rollback means route the exact previous compatible OCI digest while
keeping additive 0008 objects. Do not run a destructive down migration.
Workers and provider egress are disabled first; reconcile the external egress
ledger, provider lookup/webhook authority and PostgreSQL before any re-enable.

Data recovery is separate: restore an exact tested database/object-store point,
then keep egress disabled until the external conditional ledger is reconciled.
`PREPARED`, `MAY_HAVE_SUBMITTED`, missing, conflicting or unknown ledger state
is blocking and never permits resend.

Formal dispatch rows and Human Gate/formal terminal events are append-only and
must survive application rollback. A rollback cannot reverse a terminal
decision or execute a second formal effect.

## SLOs (targets, currently unproven)

- Authenticated web availability target: 99.9% monthly.
- Durable command accepted-or-typed-failure target: 99.9% within 5 seconds,
  excluding provider completion latency.
- Outbox publication p99 target: 30 seconds.
- Reconciliation visibility p99 target: 5 minutes after trusted evidence.
- RPO target: 5 minutes for PostgreSQL and versioned objects.
- RTO target: 60 minutes.
- Provider duplicate-submission objective: exactly zero.
- Cross-tenant data exposure and formal effect without authority: exactly zero.

Every RPO/RTO/SLO is `UNPROVEN` until account-bound load, failover, backup,
restore and canary drills bind exact evidence. Targets do not authorize spend,
provisioning, traffic or data transfer.

