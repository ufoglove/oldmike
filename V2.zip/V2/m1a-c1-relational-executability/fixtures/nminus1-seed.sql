\set ON_ERROR_STOP on

BEGIN;
INSERT INTO public."user" (
  id,name,email,"emailVerified","createdAt","updatedAt"
) VALUES (
  'user-fixture-01','M1A C1 Fixture','m1a-c1-fixture@example.invalid',true,
  pg_catalog.statement_timestamp(),pg_catalog.statement_timestamp()
);
INSERT INTO public.workspaces (id,name,owner_user_id)
VALUES ('workspace-fixture-01','M1A C1 Disposable Workspace','user-fixture-01');
INSERT INTO public.workspace_members (workspace_id,user_id,role)
VALUES ('workspace-fixture-01','user-fixture-01','owner');
INSERT INTO public.projects (
  project_id,workspace_id,created_by,title,status,legacy,storage_backend
) VALUES (
  'project-fixture-01','workspace-fixture-01','user-fixture-01',
  'M1A C1 Disposable Project','ACTIVE',false,'POSTGRES_INDEX_PENDING_SAFE_STORAGE'
);
COMMIT;
