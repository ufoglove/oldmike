\set ON_ERROR_STOP on
SET ROLE old_mike_prod_owner;

SELECT authorization_hash::text AS authorization_hash
  FROM old_mike_production_private.formal_effect_authorizations
 WHERE workspace_id='workspace-fixture-01' AND project_id='project-fixture-06'
   AND formal_effect_id='formal-effect-concurrent-06' \gset
SELECT old_mike_production_private.hash_parts(
  'workspace-fixture-01','project-fixture-06','formal-effect-concurrent-06',
  :'authorization_hash','REVOKED_BEFORE_EXECUTION','user-fixture-01'
) AS revoked_terminal_hash \gset
SET ROLE old_mike_prod_web;
SELECT * FROM old_mike_production_private.terminalize_formal_effect(
  'workspace-fixture-01','project-fixture-06','formal-effect-concurrent-06',
  'user-fixture-01','REVOKED_BEFORE_EXECUTION',:'revoked_terminal_hash'
);
SET ROLE old_mike_prod_owner;

DO $assertions$
BEGIN
  IF (SELECT pg_catalog.count(*) FROM old_mike_production_private.human_gate_decisions
       WHERE workspace_id='workspace-fixture-01' AND project_id='project-fixture-02'
         AND gate_request_id='gate-concurrent-02')<>1 THEN
    RAISE EXCEPTION 'm1a_c1_concurrent_gate_not_exactly_one';
  END IF;
  IF (SELECT pg_catalog.count(*) FROM old_mike_production_private.formal_effect_authorizations
       WHERE workspace_id='workspace-fixture-01' AND project_id='project-fixture-06'
         AND formal_effect_id='formal-effect-concurrent-06')<>1
     OR (SELECT pg_catalog.count(*) FROM old_mike_production_private.dispatch_outbox
       WHERE workspace_id='workspace-fixture-01' AND project_id='project-fixture-06'
         AND formal_effect_id='formal-effect-concurrent-06')<>1 THEN
    RAISE EXCEPTION 'm1a_c1_concurrent_formal_authorization_not_exactly_one';
  END IF;
  IF (SELECT outcome FROM old_mike_production_private.formal_effect_terminal_events
       WHERE workspace_id='workspace-fixture-01' AND project_id='project-fixture-06'
         AND formal_effect_id='formal-effect-concurrent-06')<>'REVOKED_BEFORE_EXECUTION' THEN
    RAISE EXCEPTION 'm1a_c1_revoked_terminal_authority_missing';
  END IF;
END
$assertions$;

SELECT pg_catalog.jsonb_build_object(
  'concurrentFormalAuthorizationCount',(SELECT pg_catalog.count(*) FROM old_mike_production_private.formal_effect_authorizations WHERE formal_effect_id='formal-effect-concurrent-06'),
  'concurrentGateDecisionCount',(SELECT pg_catalog.count(*) FROM old_mike_production_private.human_gate_decisions WHERE gate_request_id='gate-concurrent-02'),
  'status','PASS'
)::text AS concurrency_result;
