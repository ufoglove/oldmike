\set ON_ERROR_STOP on
SET ROLE old_mike_prod_owner;
SELECT old_mike_production_private.hash_parts(
  request_row.workspace_id,request_row.project_id,request_row.gate_request_id,
  request_row.snapshot_revision::text,request_row.snapshot_content_hash,
  request_row.authority_payload_hash,'REJECTED','user-fixture-01'
) AS decision_hash
FROM old_mike_production_private.human_gate_requests request_row
WHERE request_row.workspace_id='workspace-fixture-01'
  AND request_row.project_id='project-fixture-02'
  AND request_row.gate_request_id='gate-concurrent-02' \gset
SET ROLE old_mike_prod_web;
SELECT * FROM old_mike_production_private.decide_human_gate(
  'workspace-fixture-01','project-fixture-02','gate-concurrent-02',
  'REJECTED','user-fixture-01',:'decision_hash'
);

