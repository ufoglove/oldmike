\set ON_ERROR_STOP on
\pset tuples_only on

SET ROLE old_mike_prod_owner;

INSERT INTO old_mike_production_private.authority_registry (
  registry_kind,authority_id,version,authority_hash,approval_event_hash,review_class
) VALUES
  ('PROMPT','prompt-01',1,repeat('a',64),repeat('1',64),NULL),
  ('SCHEMA','schema-01',1,repeat('b',64),repeat('2',64),NULL),
  ('MODEL','model-01',1,repeat('c',64),repeat('3',64),NULL),
  ('EVAL','eval-01',1,repeat('d',64),repeat('4',64),'PROFESSIONAL_RESEARCH'),
  ('PROVIDER_CONFIG','provider-config-01',1,repeat('e',64),repeat('5',64),NULL),
  ('PRIVACY','privacy-01',1,repeat('f',64),repeat('6',64),NULL),
  ('RETENTION','retention-01',1,repeat('0',64),repeat('7',64),NULL);

INSERT INTO old_mike_production_private.registry_status_events (
  registry_kind,authority_id,version,authority_hash,approval_event_hash,
  sequence,status,predecessor_event_hash,event_hash,actor_user_id
)
SELECT registry_kind,authority_id,version,authority_hash,approval_event_hash,
       1,'APPROVED',NULL,approval_event_hash,'user-fixture-01'
  FROM old_mike_production_private.authority_registry;

INSERT INTO old_mike_production_private.source_objects (
  workspace_id,project_id,source_object_id,object_kind,object_store_version_id,
  byte_length,content_sha256
) VALUES (
  'workspace-fixture-01','project-fixture-01','source-object-01','ORIGINAL',
  'object-version-01',12,repeat('8',64)
);

SELECT pg_catalog.encode(
  pg_catalog.sha256(
    pg_catalog.convert_to('1','UTF8')||pg_catalog.decode('00','hex')||
    pg_catalog.convert_to('source-object-01','UTF8')||pg_catalog.decode('00','hex')||
    pg_catalog.convert_to('object-version-01','UTF8')||pg_catalog.decode('00','hex')||
    pg_catalog.convert_to('12','UTF8')||pg_catalog.decode('00','hex')||
    pg_catalog.convert_to(repeat('8',64),'UTF8')||pg_catalog.decode('0a','hex')
  ),'hex'
) AS bundle_hash \gset

INSERT INTO old_mike_production_private.source_bundles (
  workspace_id,project_id,source_bundle_id,version,member_count,bundle_hash
) VALUES (
  'workspace-fixture-01','project-fixture-01','source-bundle-01',1,1,:'bundle_hash'
);
INSERT INTO old_mike_production_private.source_bundle_members (
  workspace_id,project_id,source_bundle_id,bundle_version,ordinal,
  source_object_id,object_store_version_id,byte_length,content_sha256
) VALUES (
  'workspace-fixture-01','project-fixture-01','source-bundle-01',1,1,
  'source-object-01','object-version-01',12,repeat('8',64)
);

SELECT pg_catalog.jsonb_build_object(
  'actorUserId','user-fixture-01','idempotencyKey','bootstrap-key-01',
  'operation','BOOTSTRAP_PROJECT_SNAPSHOT','projectId','project-fixture-01',
  'requestHash',repeat('9',64),'requestId','bootstrap-request-01',
  'schemaVersion','m1a-c1-snapshot/1','workspaceId','workspace-fixture-01'
)::text AS bootstrap_payload \gset
SELECT old_mike_production_private.canonical_json_hash(:'bootstrap_payload'::jsonb)
  AS bootstrap_payload_hash \gset
SELECT old_mike_production_private.hash_parts(
  'workspace-fixture-01','project-fixture-01','0','m1a-c1-snapshot/1',
  :'bootstrap_payload_hash'
) AS bootstrap_content_hash \gset

SET ROLE old_mike_prod_web;
SELECT * FROM old_mike_production_private.bootstrap_project_snapshot(
  'workspace-fixture-01','project-fixture-01','user-fixture-01',
  'bootstrap-request-01','bootstrap-key-01',repeat('9',64),
  'm1a-c1-snapshot/1',:'bootstrap_content_hash',
  :'bootstrap_payload'::jsonb,:'bootstrap_payload_hash'
);

DO $raw_dml_denied$
BEGIN
  BEGIN
    INSERT INTO old_mike_production_private.project_events (
      workspace_id,project_id,event_id,sequence,event_hash,operation,request_id,
      idempotency_key,request_hash,base_revision,base_content_hash,
      operation_identity_hash,snapshot_revision,snapshot_content_hash,job_id,
      event_kind,response_authority_hash
    ) VALUES (
      'workspace-fixture-01','project-fixture-01','forbidden-event',1,repeat('a',64),
      'FORBIDDEN','forbidden-request','forbidden-key',repeat('b',64),0,repeat('c',64),
      repeat('d',64),0,repeat('e',64),'forbidden-job','GENERATION_COMPLETE',repeat('f',64)
    );
    RAISE EXCEPTION 'm1a_c1_expected_raw_dml_denial';
  EXCEPTION WHEN insufficient_privilege THEN
    NULL;
  END;
END
$raw_dml_denied$;

RESET ROLE;
SET ROLE old_mike_prod_owner;

SELECT old_mike_production_private.hash_parts(
  'workspace-fixture-01','project-fixture-01','stage-01','0',:'bootstrap_content_hash'
) AS effect_lineage_hash_1 \gset
SELECT pg_catalog.jsonb_build_object(
  'actorUserId','user-fixture-01','baseContentHash',:'bootstrap_content_hash',
  'baseRevision',0,'effectLineageHash',:'effect_lineage_hash_1',
  'evalAuthority',pg_catalog.jsonb_build_object('hash',repeat('d',64),'id','eval-01','reviewClass','PROFESSIONAL_RESEARCH','version',1),
  'idempotencyKey','generate-key-01','jobId','job-01',
  'modelAuthority',pg_catalog.jsonb_build_object('hash',repeat('c',64),'id','model-01','version',1),
  'operation','GENERATE_DURABLE_CORE',
  'outputSchemaAuthority',pg_catalog.jsonb_build_object('hash',repeat('b',64),'id','schema-01','version',1),
  'privacyAuthority',pg_catalog.jsonb_build_object('hash',repeat('f',64),'id','privacy-01','version',1),
  'projectId','project-fixture-01',
  'promptAuthority',pg_catalog.jsonb_build_object('hash',repeat('a',64),'id','prompt-01','version',1),
  'providerConfigAuthority',pg_catalog.jsonb_build_object('hash',repeat('e',64),'id','provider-config-01','version',1),
  'requestId','generate-request-01',
  'retentionAuthority',pg_catalog.jsonb_build_object('hash',repeat('0',64),'id','retention-01','version',1),
  'schemaVersion','m1a-c1-job/1','sourceBundleHash',:'bundle_hash',
  'sourceBundleId','source-bundle-01','sourceBundleVersion',1,'stageId','stage-01',
  'workspaceId','workspace-fixture-01'
)::text AS job_payload_1 \gset
SELECT old_mike_production_private.canonical_json_hash(:'job_payload_1'::jsonb)
  AS job_payload_hash_1 \gset
SELECT old_mike_production_private.hash_parts('GENERATE_DURABLE_CORE',:'job_payload_hash_1')
  AS request_hash_1 \gset
SELECT old_mike_production_private.hash_parts(
  'workspace-fixture-01','project-fixture-01','GENERATE_DURABLE_CORE',
  'generate-request-01','generate-key-01',:'request_hash_1','0',:'bootstrap_content_hash'
) AS operation_identity_hash_1 \gset

SET ROLE old_mike_prod_web;
SELECT * FROM old_mike_production_private.create_ai_job(
  'workspace-fixture-01','project-fixture-01','user-fixture-01','job-01','outbox-01','stage-01',
  'GENERATE_DURABLE_CORE','generate-request-01','generate-key-01',0,:'bootstrap_content_hash',
  'source-bundle-01',1,:'bundle_hash',
  'prompt-01',1,repeat('a',64),repeat('1',64),
  'schema-01',1,repeat('b',64),repeat('2',64),
  'model-01',1,repeat('c',64),repeat('3',64),
  'eval-01',1,repeat('d',64),repeat('4',64),'PROFESSIONAL_RESEARCH',
  'provider-config-01',1,repeat('e',64),repeat('5',64),
  'privacy-01',1,repeat('f',64),repeat('6',64),
  'retention-01',1,repeat('0',64),repeat('7',64),
  :'effect_lineage_hash_1',:'operation_identity_hash_1',:'request_hash_1',
  'm1a-c1-job/1',:'job_payload_1'::jsonb,:'job_payload_hash_1'
);

SET ROLE old_mike_prod_relay;
SELECT * FROM old_mike_production_private.claim_ai_outbox(
  'workspace-fixture-01','project-fixture-01','outbox-01',repeat('a',64),1
);
DO $live_outbox_lease$
BEGIN
  BEGIN
    PERFORM * FROM old_mike_production_private.claim_ai_outbox(
      'workspace-fixture-01','project-fixture-01','outbox-01',repeat('b',64),1
    );
    RAISE EXCEPTION 'm1a_c1_expected_live_outbox_lease_rejection';
  EXCEPTION WHEN raise_exception THEN
    IF SQLERRM<>'m1a_c1_outbox_live_lease' THEN RAISE; END IF;
  END;
END
$live_outbox_lease$;
SELECT pg_catalog.pg_sleep(1.05);
SELECT * FROM old_mike_production_private.claim_ai_outbox(
  'workspace-fixture-01','project-fixture-01','outbox-01',repeat('b',64),30
);
DO $stale_outbox_commit$
BEGIN
  BEGIN
    PERFORM * FROM old_mike_production_private.publish_ai_outbox(
      'workspace-fixture-01','project-fixture-01','outbox-01',repeat('a',64),1,repeat('c',64)
    );
    RAISE EXCEPTION 'm1a_c1_expected_stale_outbox_commit_rejection';
  EXCEPTION WHEN raise_exception THEN
    IF SQLERRM<>'m1a_c1_outbox_stale_lease_commit' THEN RAISE; END IF;
  END;
END
$stale_outbox_commit$;
SELECT * FROM old_mike_production_private.publish_ai_outbox(
  'workspace-fixture-01','project-fixture-01','outbox-01',repeat('b',64),2,repeat('c',64)
);

SET ROLE old_mike_prod_worker;
SELECT * FROM old_mike_production_private.reserve_budget(
  'workspace-fixture-01','project-fixture-01','job-01','reservation-01','USD','TOKEN',
  'budget-policy-01',1,repeat('9',64),1000,10000,
  pg_catalog.statement_timestamp()+interval '1 hour'
);
SELECT * FROM old_mike_production_private.claim_ai_job(
  'workspace-fixture-01','project-fixture-01','job-01',repeat('d',64),30
);
SELECT * FROM old_mike_production_private.prepare_provider_attempt(
  'workspace-fixture-01','project-fixture-01','job-01',repeat('d',64),1,
  'DETERMINISTIC_FAKE','provider-request-01',repeat('e',64),repeat('f',64),repeat('1',64)
);
SELECT * FROM old_mike_production_private.begin_provider_io(
  'workspace-fixture-01','project-fixture-01','job-01',repeat('d',64),1,repeat('1',64)
);

RESET ROLE;
SET ROLE old_mike_prod_owner;
SELECT pg_catalog.jsonb_build_object(
  'jobId','job-01','operation','GENERATE_DURABLE_CORE','projectId','project-fixture-01',
  'resultHash',repeat('2',64),'schemaVersion','m1a-c1-snapshot/1',
  'sourceBundleHash',:'bundle_hash','workspaceId','workspace-fixture-01'
)::text AS success_payload_1 \gset
SELECT old_mike_production_private.canonical_json_hash(:'success_payload_1'::jsonb)
  AS success_payload_hash_1 \gset
SELECT old_mike_production_private.hash_parts(
  'workspace-fixture-01','project-fixture-01','1',:'bootstrap_content_hash',
  'job-01',repeat('2',64),:'success_payload_hash_1'
) AS success_content_hash_1 \gset

SET ROLE old_mike_prod_worker;
SELECT * FROM old_mike_production_private.commit_provider_outcome(
  'workspace-fixture-01','project-fixture-01','job-01','COMPLETE',repeat('3',64),repeat('4',64),
  repeat('2',64),NULL,NULL,NULL,'event-generation-complete-01','m1a-c1-snapshot/1',
  :'success_payload_1'::jsonb,:'success_payload_hash_1',:'success_content_hash_1'
);
SELECT * FROM old_mike_production_private.commit_provider_outcome(
  'workspace-fixture-01','project-fixture-01','job-01','COMPLETE',repeat('3',64),NULL,
  repeat('2',64),NULL,NULL,NULL,'event-generation-complete-01','m1a-c1-snapshot/1',
  :'success_payload_1'::jsonb,:'success_payload_hash_1',:'success_content_hash_1'
);

RESET ROLE;
SET ROLE old_mike_prod_owner;
SELECT old_mike_production_private.hash_parts(
  'workspace-fixture-01','project-fixture-01','usage-01','reservation-01','job-01',
  'DETERMINISTIC_FAKE','provider-request-01',:'request_hash_1','USD','TOKEN',
  'budget-policy-01','1',repeat('9',64),'120','1200'
) AS usage_hash_1 \gset
SET ROLE old_mike_prod_worker;
SELECT * FROM old_mike_production_private.record_usage(
  'workspace-fixture-01','project-fixture-01','job-01','reservation-01',
  'usage-01',120,1200,:'usage_hash_1'
);

RESET ROLE;
SET ROLE old_mike_prod_owner;
SELECT pg_catalog.jsonb_build_object(
  'actorUserId','user-fixture-01','gateRequestId','gate-request-01',
  'operation','FORMAL_RESEARCH_WRITE','projectId','project-fixture-01',
  'schemaVersion','m1a-c1-gate/1','snapshotContentHash',:'success_content_hash_1',
  'snapshotRevision',1,'tenantId','workspace-fixture-01','workspaceId','workspace-fixture-01'
)::text AS gate_payload_1 \gset
SELECT old_mike_production_private.canonical_json_hash(:'gate_payload_1'::jsonb)
 AS gate_payload_hash_1 \gset
SET ROLE old_mike_prod_web;
SELECT * FROM old_mike_production_private.request_human_gate(
  'workspace-fixture-01','workspace-fixture-01','project-fixture-01','user-fixture-01',
  'gate-request-01',1,:'success_content_hash_1','FORMAL_RESEARCH_WRITE','m1a-c1-gate/1',
  :'gate_payload_1'::jsonb,:'gate_payload_hash_1'
);

RESET ROLE;
SET ROLE old_mike_prod_owner;
SELECT old_mike_production_private.hash_parts(
  'workspace-fixture-01','project-fixture-01','gate-request-01','1',
  :'success_content_hash_1',:'gate_payload_hash_1','CONFIRMED','user-fixture-01'
) AS gate_decision_hash_1 \gset
SET ROLE old_mike_prod_web;
SELECT * FROM old_mike_production_private.decide_human_gate(
  'workspace-fixture-01','project-fixture-01','gate-request-01','CONFIRMED',
  'user-fixture-01',:'gate_decision_hash_1'
);

RESET ROLE;
SET ROLE old_mike_prod_owner;
SELECT pg_catalog.jsonb_build_object(
  'actorUserId','user-fixture-01','formalEffectId','formal-effect-01',
  'gateDecisionHash',:'gate_decision_hash_1','gateRequestId','gate-request-01',
  'operation','FORMAL_RESEARCH_WRITE','projectId','project-fixture-01',
  'schemaVersion','m1a-c1-formal/1','snapshotContentHash',:'success_content_hash_1',
  'snapshotRevision',1,'tenantId','workspace-fixture-01','workspaceId','workspace-fixture-01'
)::text AS formal_payload_1 \gset
SELECT old_mike_production_private.canonical_json_hash(:'formal_payload_1'::jsonb)
  AS formal_payload_hash_1 \gset
SELECT old_mike_production_private.hash_parts(
  'workspace-fixture-01','project-fixture-01','formal-effect-01','gate-request-01',
  :'gate_decision_hash_1','1',:'success_content_hash_1','user-fixture-01',
  'FORMAL_RESEARCH_WRITE','m1a-c1-formal/1',:'formal_payload_hash_1'
) AS formal_authorization_hash_1 \gset
SET ROLE old_mike_prod_web;
SELECT * FROM old_mike_production_private.authorize_formal_effect(
  'workspace-fixture-01','project-fixture-01','formal-effect-01','gate-request-01',
  'user-fixture-01','dispatch-01','m1a-c1-formal/1',:'formal_payload_1'::jsonb,
  :'formal_payload_hash_1',:'formal_authorization_hash_1'
);

SET ROLE old_mike_prod_relay;
SELECT * FROM old_mike_production_private.claim_dispatch_outbox(
  'workspace-fixture-01','project-fixture-01','dispatch-01',repeat('5',64),30
);
SELECT * FROM old_mike_production_private.publish_dispatch_outbox(
  'workspace-fixture-01','project-fixture-01','dispatch-01',repeat('5',64),1,repeat('6',64)
);

RESET ROLE;
SET ROLE old_mike_prod_owner;
SELECT old_mike_production_private.hash_parts(
  'workspace-fixture-01','project-fixture-01','formal-effect-01',
  :'formal_authorization_hash_1','EXECUTED','user-fixture-01'
) AS formal_terminal_hash_1 \gset
SET ROLE old_mike_prod_web;
SELECT * FROM old_mike_production_private.terminalize_formal_effect(
  'workspace-fixture-01','project-fixture-01','formal-effect-01','user-fixture-01',
  'EXECUTED',:'formal_terminal_hash_1'
);

RESET ROLE;
SET ROLE old_mike_prod_owner;

DO $final_assertions$
DECLARE counts record;
BEGIN
  SELECT
    (SELECT pg_catalog.count(*) FROM old_mike_production_private.ai_jobs) AS jobs,
    (SELECT pg_catalog.count(*) FROM old_mike_production_private.provider_attempts) AS attempts,
    (SELECT pg_catalog.count(*) FROM old_mike_production_private.provider_receipts) AS receipts,
    (SELECT pg_catalog.count(*) FROM old_mike_production_private.project_snapshots) AS snapshots,
    (SELECT pg_catalog.count(*) FROM old_mike_production_private.project_events) AS events,
    (SELECT pg_catalog.count(*) FROM old_mike_production_private.human_gate_decisions) AS decisions,
    (SELECT pg_catalog.count(*) FROM old_mike_production_private.formal_effect_authorizations) AS authorizations,
    (SELECT pg_catalog.count(*) FROM old_mike_production_private.formal_effect_terminal_events) AS terminals
  INTO counts;
  IF counts.jobs<>1 OR counts.attempts<>1 OR counts.receipts<>3
     OR counts.snapshots<>2 OR counts.events<>1 OR counts.decisions<>1
     OR counts.authorizations<>1 OR counts.terminals<>1 THEN
    RAISE EXCEPTION 'm1a_c1_capability_count_mismatch:%',pg_catalog.to_jsonb(counts);
  END IF;
  IF (SELECT state FROM old_mike_production_private.ai_jobs
       WHERE workspace_id='workspace-fixture-01' AND project_id='project-fixture-01' AND job_id='job-01')<>'SUCCEEDED' THEN
    RAISE EXCEPTION 'm1a_c1_job_not_succeeded';
  END IF;
END
$final_assertions$;

SELECT pg_catalog.jsonb_build_object(
  'appRawDmlDenied',true,
  'formalEffectTerminalCount',(SELECT pg_catalog.count(*) FROM old_mike_production_private.formal_effect_terminal_events),
  'humanGateDecisionCount',(SELECT pg_catalog.count(*) FROM old_mike_production_private.human_gate_decisions),
  'jobCount',(SELECT pg_catalog.count(*) FROM old_mike_production_private.ai_jobs),
  'projectEventCount',(SELECT pg_catalog.count(*) FROM old_mike_production_private.project_events),
  'providerReceiptCount',(SELECT pg_catalog.count(*) FROM old_mike_production_private.provider_receipts),
  'snapshotCount',(SELECT pg_catalog.count(*) FROM old_mike_production_private.project_snapshots),
  'status','PASS'
)::text AS capability_result;
