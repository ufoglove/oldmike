\set ON_ERROR_STOP on
\pset tuples_only on
\pset format unaligned

WITH authority_lines AS (
  SELECT '01_OBJECT|'||namespace_row.nspname||'|'||class_row.relname||'|'||class_row.relkind::text||'|'||owner_row.rolname AS line
    FROM pg_catalog.pg_class class_row
    JOIN pg_catalog.pg_namespace namespace_row ON namespace_row.oid=class_row.relnamespace
    JOIN pg_catalog.pg_roles owner_row ON owner_row.oid=class_row.relowner
   WHERE namespace_row.nspname IN ('public','old_mike_production_private')
     AND class_row.relkind IN ('r','v','S')
  UNION ALL
  SELECT '02_COLUMN|'||namespace_row.nspname||'|'||class_row.relname||'|'||attribute_row.attnum||'|'||
         attribute_row.attname||'|'||pg_catalog.format_type(attribute_row.atttypid,attribute_row.atttypmod)||'|'||
         attribute_row.attnotnull||'|'||COALESCE(pg_catalog.pg_get_expr(default_row.adbin,default_row.adrelid),'')
    FROM pg_catalog.pg_attribute attribute_row
    JOIN pg_catalog.pg_class class_row ON class_row.oid=attribute_row.attrelid
    JOIN pg_catalog.pg_namespace namespace_row ON namespace_row.oid=class_row.relnamespace
    LEFT JOIN pg_catalog.pg_attrdef default_row
      ON default_row.adrelid=class_row.oid AND default_row.adnum=attribute_row.attnum
   WHERE namespace_row.nspname IN ('public','old_mike_production_private')
     AND class_row.relkind IN ('r','v') AND attribute_row.attnum>0 AND NOT attribute_row.attisdropped
  UNION ALL
  SELECT '03_CONSTRAINT|'||namespace_row.nspname||'|'||class_row.relname||'|'||constraint_row.conname||'|'||
         constraint_row.contype::text||'|'||constraint_row.condeferrable||'|'||constraint_row.condeferred||'|'||
         constraint_row.convalidated||'|'||pg_catalog.pg_get_constraintdef(constraint_row.oid,true)
    FROM pg_catalog.pg_constraint constraint_row
    JOIN pg_catalog.pg_namespace namespace_row ON namespace_row.oid=constraint_row.connamespace
    LEFT JOIN pg_catalog.pg_class class_row ON class_row.oid=constraint_row.conrelid
   WHERE namespace_row.nspname IN ('public','old_mike_production_private')
  UNION ALL
  SELECT '04_FUNCTION|'||namespace_row.nspname||'|'||proc.proname||'|'||
         pg_catalog.pg_get_function_identity_arguments(proc.oid)||'|'||owner_row.rolname||'|'||
         proc.prosecdef||'|'||COALESCE(pg_catalog.array_to_string(proc.proconfig,','),'')
    FROM pg_catalog.pg_proc proc
    JOIN pg_catalog.pg_namespace namespace_row ON namespace_row.oid=proc.pronamespace
    JOIN pg_catalog.pg_roles owner_row ON owner_row.oid=proc.proowner
   WHERE namespace_row.nspname IN ('public','old_mike_production_private')
  UNION ALL
  SELECT '05_TRIGGER|'||namespace_row.nspname||'|'||class_row.relname||'|'||trigger_row.tgname||'|'||
         pg_catalog.pg_get_triggerdef(trigger_row.oid,true)
    FROM pg_catalog.pg_trigger trigger_row
    JOIN pg_catalog.pg_class class_row ON class_row.oid=trigger_row.tgrelid
    JOIN pg_catalog.pg_namespace namespace_row ON namespace_row.oid=class_row.relnamespace
   WHERE namespace_row.nspname IN ('public','old_mike_production_private') AND NOT trigger_row.tgisinternal
  UNION ALL
  SELECT '06_ROLE|'||role_row.rolname||'|'||role_row.rolsuper||'|'||role_row.rolinherit||'|'||
         role_row.rolcreaterole||'|'||role_row.rolcreatedb||'|'||role_row.rolcanlogin||'|'||
         role_row.rolreplication||'|'||role_row.rolbypassrls
    FROM pg_catalog.pg_roles role_row
   WHERE role_row.rolname LIKE 'old_mike_prod_%' OR role_row.rolname='m1a_c1_fixture_runner'
  UNION ALL
  SELECT '07_MEMBERSHIP|'||granted_role.rolname||'|'||member_role.rolname||'|'||
         membership.admin_option||'|'||membership.inherit_option||'|'||membership.set_option
    FROM pg_catalog.pg_auth_members membership
    JOIN pg_catalog.pg_roles granted_role ON granted_role.oid=membership.roleid
    JOIN pg_catalog.pg_roles member_role ON member_role.oid=membership.member
   WHERE granted_role.rolname LIKE 'old_mike_prod_%' OR member_role.rolname LIKE 'old_mike_prod_%'
  UNION ALL
  SELECT '08_SCHEMA_ACL|'||namespace_row.nspname||'|'||COALESCE(grantee_role.rolname,'PUBLIC')||'|'||acl_row.privilege_type||'|'||acl_row.is_grantable
    FROM pg_catalog.pg_namespace namespace_row
    CROSS JOIN LATERAL pg_catalog.aclexplode(COALESCE(namespace_row.nspacl,pg_catalog.acldefault('n',namespace_row.nspowner))) acl_row
    LEFT JOIN pg_catalog.pg_roles grantee_role ON grantee_role.oid=acl_row.grantee
   WHERE namespace_row.nspname IN ('public','old_mike_production_private')
  UNION ALL
  SELECT '09_OBJECT_ACL|'||namespace_row.nspname||'|'||class_row.relname||'|'||
         COALESCE(grantee_role.rolname,'PUBLIC')||'|'||acl_row.privilege_type||'|'||acl_row.is_grantable
    FROM pg_catalog.pg_class class_row
    JOIN pg_catalog.pg_namespace namespace_row ON namespace_row.oid=class_row.relnamespace
    CROSS JOIN LATERAL pg_catalog.aclexplode(COALESCE(class_row.relacl,pg_catalog.acldefault(CASE WHEN class_row.relkind='S' THEN 'S'::"char" ELSE 'r'::"char" END,class_row.relowner))) acl_row
    LEFT JOIN pg_catalog.pg_roles grantee_role ON grantee_role.oid=acl_row.grantee
   WHERE namespace_row.nspname IN ('public','old_mike_production_private')
     AND class_row.relkind IN ('r','v','S')
  UNION ALL
  SELECT '10_DEFAULT_ACL|'||owner_row.rolname||'|'||COALESCE(namespace_row.nspname,'')||'|'||
         default_row.defaclobjtype::text||'|'||COALESCE(grantee_role.rolname,'PUBLIC')||'|'||
         acl_row.privilege_type||'|'||acl_row.is_grantable
    FROM pg_catalog.pg_default_acl default_row
    JOIN pg_catalog.pg_roles owner_row ON owner_row.oid=default_row.defaclrole
    LEFT JOIN pg_catalog.pg_namespace namespace_row ON namespace_row.oid=default_row.defaclnamespace
    CROSS JOIN LATERAL pg_catalog.aclexplode(default_row.defaclacl) acl_row
    LEFT JOIN pg_catalog.pg_roles grantee_role ON grantee_role.oid=acl_row.grantee
   WHERE owner_row.rolname='old_mike_prod_owner'
)
SELECT line FROM authority_lines ORDER BY line COLLATE "C";
