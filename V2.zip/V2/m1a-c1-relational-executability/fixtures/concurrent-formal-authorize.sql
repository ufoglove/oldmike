\set ON_ERROR_STOP on
SET ROLE old_mike_prod_owner;
SELECT request_row.snapshot_revision,request_row.snapshot_content_hash::text AS snapshot_content_hash,
       request_row.operation,decision_row.decision_hash::text AS gate_decision_hash
  FROM old_mike_production_private.human_gate_requests request_row
  JOIN old_mike_production_private.human_gate_decisions decision_row
    ON decision_row.workspace_id=request_row.workspace_id
   AND decision_row.project_id=request_row.project_id
   AND decision_row.gate_request_id=request_row.gate_request_id
 WHERE request_row.workspace_id='workspace-fixture-01'
   AND request_row.project_id='project-fixture-06'
   AND request_row.gate_request_id='gate-formal-concurrent-06' \gset
SELECT pg_catalog.jsonb_build_object(
  'actorUserId','user-fixture-01','formalEffectId','formal-effect-concurrent-06',
  'gateDecisionHash',:'gate_decision_hash','gateRequestId','gate-formal-concurrent-06',
  'operation',:'operation','projectId','project-fixture-06',
  'schemaVersion','m1a-c1-formal/1','snapshotContentHash',:'snapshot_content_hash',
  'snapshotRevision',:'snapshot_revision'::bigint,'tenantId','workspace-fixture-01',
  'workspaceId','workspace-fixture-01'
)::text AS formal_payload \gset
SELECT old_mike_production_private.canonical_json_hash(:'formal_payload'::jsonb)
  AS formal_payload_hash \gset
SELECT old_mike_production_private.hash_parts(
  'workspace-fixture-01','project-fixture-06','formal-effect-concurrent-06',
  'gate-formal-concurrent-06',:'gate_decision_hash',:'snapshot_revision',
  :'snapshot_content_hash','user-fixture-01',:'operation','m1a-c1-formal/1',
  :'formal_payload_hash'
) AS formal_authorization_hash \gset
SET ROLE old_mike_prod_web;
SELECT * FROM old_mike_production_private.authorize_formal_effect(
  'workspace-fixture-01','project-fixture-06','formal-effect-concurrent-06',
  'gate-formal-concurrent-06','user-fixture-01','dispatch-concurrent-06',
  'm1a-c1-formal/1',:'formal_payload'::jsonb,:'formal_payload_hash',
  :'formal_authorization_hash'
);

