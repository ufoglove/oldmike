\set ON_ERROR_STOP on
\pset tuples_only on

SET ROLE old_mike_prod_owner;

CREATE FUNCTION pg_temp.seed_submitting_case(p_suffix text)
RETURNS TABLE(
  suffix text,project_id text,job_id text,outbox_id text,base_content_hash text,
  bundle_hash text,request_hash text,operation_identity_hash text,
  request_authority_hash text,ledger_key_hash text,ledger_commitment_hash text
)
LANGUAGE plpgsql
SET search_path=pg_catalog
AS $function$
DECLARE
  v_project_id text:='project-fixture-'||p_suffix;
  v_job_id text:='job-'||p_suffix;
  v_outbox_id text:='outbox-'||p_suffix;
  v_stage_id text:='stage-'||p_suffix;
  v_source_id text:='source-object-'||p_suffix;
  v_object_version text:='object-version-'||p_suffix;
  v_bundle_id text:='source-bundle-'||p_suffix;
  v_bootstrap_request text:='bootstrap-request-'||p_suffix;
  v_bootstrap_key text:='bootstrap-key-'||p_suffix;
  v_generate_request text:='generate-request-'||p_suffix;
  v_generate_key text:='generate-key-'||p_suffix;
  v_payload jsonb;
  v_payload_hash text;
  v_base_hash text;
  v_bundle_hash text;
  v_effect_hash text;
  v_request_hash text;
  v_operation_hash text;
  v_request_authority_hash text:=old_mike_production_private.hash_parts('request-authority',p_suffix);
  v_ledger_key_hash text:=old_mike_production_private.hash_parts('external-ledger-key',p_suffix);
  v_ledger_commitment_hash text:=old_mike_production_private.hash_parts('external-ledger-commitment',p_suffix);
  v_lease_hash text:=old_mike_production_private.hash_parts('lease',p_suffix);
  v_content_hash text:=old_mike_production_private.hash_parts('source-content',p_suffix);
BEGIN
  INSERT INTO public.projects (
    project_id,workspace_id,created_by,title,status,legacy,storage_backend
  ) VALUES (
    v_project_id,'workspace-fixture-01','user-fixture-01','Disposable case '||p_suffix,
    'ACTIVE',false,'POSTGRES_INDEX_PENDING_SAFE_STORAGE'
  );
  INSERT INTO old_mike_production_private.source_objects (
    workspace_id,project_id,source_object_id,object_kind,object_store_version_id,
    byte_length,content_sha256
  ) VALUES (
    'workspace-fixture-01',v_project_id,v_source_id,'ORIGINAL',v_object_version,12,v_content_hash
  );
  v_bundle_hash:=pg_catalog.encode(
    pg_catalog.sha256(
      pg_catalog.convert_to('1','UTF8')||pg_catalog.decode('00','hex')||
      pg_catalog.convert_to(v_source_id,'UTF8')||pg_catalog.decode('00','hex')||
      pg_catalog.convert_to(v_object_version,'UTF8')||pg_catalog.decode('00','hex')||
      pg_catalog.convert_to('12','UTF8')||pg_catalog.decode('00','hex')||
      pg_catalog.convert_to(v_content_hash,'UTF8')||pg_catalog.decode('0a','hex')
    ),'hex'
  );
  INSERT INTO old_mike_production_private.source_bundles (
    workspace_id,project_id,source_bundle_id,version,member_count,bundle_hash
  ) VALUES ('workspace-fixture-01',v_project_id,v_bundle_id,1,1,v_bundle_hash);
  INSERT INTO old_mike_production_private.source_bundle_members (
    workspace_id,project_id,source_bundle_id,bundle_version,ordinal,source_object_id,
    object_store_version_id,byte_length,content_sha256
  ) VALUES (
    'workspace-fixture-01',v_project_id,v_bundle_id,1,1,v_source_id,v_object_version,12,v_content_hash
  );
  v_payload:=pg_catalog.jsonb_build_object(
    'actorUserId','user-fixture-01','idempotencyKey',v_bootstrap_key,
    'operation','BOOTSTRAP_PROJECT_SNAPSHOT','projectId',v_project_id,
    'requestHash',old_mike_production_private.hash_parts('bootstrap-request-hash',p_suffix),
    'requestId',v_bootstrap_request,'schemaVersion','m1a-c1-snapshot/1',
    'workspaceId','workspace-fixture-01'
  );
  v_payload_hash:=old_mike_production_private.canonical_json_hash(v_payload);
  v_base_hash:=old_mike_production_private.hash_parts(
    'workspace-fixture-01',v_project_id,'0','m1a-c1-snapshot/1',v_payload_hash
  );
  PERFORM * FROM old_mike_production_private.bootstrap_project_snapshot(
    'workspace-fixture-01',v_project_id,'user-fixture-01',v_bootstrap_request,v_bootstrap_key,
    old_mike_production_private.hash_parts('bootstrap-request-hash',p_suffix),
    'm1a-c1-snapshot/1',v_base_hash,v_payload,v_payload_hash
  );
  v_effect_hash:=old_mike_production_private.hash_parts(
    'workspace-fixture-01',v_project_id,v_stage_id,'0',v_base_hash
  );
  v_payload:=pg_catalog.jsonb_build_object(
    'actorUserId','user-fixture-01','baseContentHash',v_base_hash,'baseRevision',0,
    'effectLineageHash',v_effect_hash,
    'evalAuthority',pg_catalog.jsonb_build_object('hash',repeat('d',64),'id','eval-01','reviewClass','PROFESSIONAL_RESEARCH','version',1),
    'idempotencyKey',v_generate_key,'jobId',v_job_id,
    'modelAuthority',pg_catalog.jsonb_build_object('hash',repeat('c',64),'id','model-01','version',1),
    'operation','GENERATE_DURABLE_CORE',
    'outputSchemaAuthority',pg_catalog.jsonb_build_object('hash',repeat('b',64),'id','schema-01','version',1),
    'privacyAuthority',pg_catalog.jsonb_build_object('hash',repeat('f',64),'id','privacy-01','version',1),
    'projectId',v_project_id,
    'promptAuthority',pg_catalog.jsonb_build_object('hash',repeat('a',64),'id','prompt-01','version',1),
    'providerConfigAuthority',pg_catalog.jsonb_build_object('hash',repeat('e',64),'id','provider-config-01','version',1),
    'requestId',v_generate_request,
    'retentionAuthority',pg_catalog.jsonb_build_object('hash',repeat('0',64),'id','retention-01','version',1),
    'schemaVersion','m1a-c1-job/1','sourceBundleHash',v_bundle_hash,
    'sourceBundleId',v_bundle_id,'sourceBundleVersion',1,'stageId',v_stage_id,
    'workspaceId','workspace-fixture-01'
  );
  v_payload_hash:=old_mike_production_private.canonical_json_hash(v_payload);
  v_request_hash:=old_mike_production_private.hash_parts('GENERATE_DURABLE_CORE',v_payload_hash);
  v_operation_hash:=old_mike_production_private.hash_parts(
    'workspace-fixture-01',v_project_id,'GENERATE_DURABLE_CORE',v_generate_request,
    v_generate_key,v_request_hash,'0',v_base_hash
  );
  PERFORM * FROM old_mike_production_private.create_ai_job(
    'workspace-fixture-01',v_project_id,'user-fixture-01',v_job_id,v_outbox_id,v_stage_id,
    'GENERATE_DURABLE_CORE',v_generate_request,v_generate_key,0,v_base_hash,
    v_bundle_id,1,v_bundle_hash,'prompt-01',1,repeat('a',64),repeat('1',64),
    'schema-01',1,repeat('b',64),repeat('2',64),'model-01',1,repeat('c',64),repeat('3',64),
    'eval-01',1,repeat('d',64),repeat('4',64),'PROFESSIONAL_RESEARCH',
    'provider-config-01',1,repeat('e',64),repeat('5',64),
    'privacy-01',1,repeat('f',64),repeat('6',64),
    'retention-01',1,repeat('0',64),repeat('7',64),v_effect_hash,v_operation_hash,
    v_request_hash,'m1a-c1-job/1',v_payload,v_payload_hash
  );
  PERFORM * FROM old_mike_production_private.claim_ai_outbox(
    'workspace-fixture-01',v_project_id,v_outbox_id,v_lease_hash,30
  );
  PERFORM * FROM old_mike_production_private.publish_ai_outbox(
    'workspace-fixture-01',v_project_id,v_outbox_id,v_lease_hash,1,
    old_mike_production_private.hash_parts('queue-message',p_suffix)
  );
  PERFORM * FROM old_mike_production_private.reserve_budget(
    'workspace-fixture-01',v_project_id,v_job_id,'reservation-'||p_suffix,'USD','TOKEN',
    'budget-policy-01',1,repeat('9',64),1000,10000,
    pg_catalog.statement_timestamp()+interval '1 hour'
  );
  PERFORM * FROM old_mike_production_private.claim_ai_job(
    'workspace-fixture-01',v_project_id,v_job_id,v_lease_hash,30
  );
  PERFORM * FROM old_mike_production_private.prepare_provider_attempt(
    'workspace-fixture-01',v_project_id,v_job_id,v_lease_hash,1,'DETERMINISTIC_FAKE',
    'provider-request-'||p_suffix,v_request_authority_hash,v_ledger_key_hash,v_ledger_commitment_hash
  );
  PERFORM * FROM old_mike_production_private.begin_provider_io(
    'workspace-fixture-01',v_project_id,v_job_id,v_lease_hash,1,v_ledger_commitment_hash
  );
  RETURN QUERY SELECT p_suffix,v_project_id,v_job_id,v_outbox_id,v_base_hash,v_bundle_hash,
    v_request_hash,v_operation_hash,v_request_authority_hash,v_ledger_key_hash,v_ledger_commitment_hash;
END
$function$;

CREATE TEMP TABLE case_authority AS SELECT * FROM pg_temp.seed_submitting_case('02');
INSERT INTO case_authority SELECT * FROM pg_temp.seed_submitting_case('03');
INSERT INTO case_authority SELECT * FROM pg_temp.seed_submitting_case('04');
INSERT INTO case_authority SELECT * FROM pg_temp.seed_submitting_case('05');
INSERT INTO case_authority SELECT * FROM pg_temp.seed_submitting_case('06');
INSERT INTO case_authority SELECT * FROM pg_temp.seed_submitting_case('07');

-- 02: durable completion unknown, lookup-only reconciliation, and zero resend.
SELECT * FROM old_mike_production_private.commit_provider_outcome(
  'workspace-fixture-01','project-fixture-02','job-02','COMPLETION_UNKNOWN',
  old_mike_production_private.hash_parts('unknown-evidence','02'),NULL,NULL,NULL,NULL,
  'PROVIDER_DISCONNECTED','event-generation-unknown-02',NULL,NULL,NULL,NULL
);
SELECT * FROM old_mike_production_private.begin_provider_io(
  'workspace-fixture-01','project-fixture-02','job-02',repeat('0',64),0,
  (SELECT ledger_commitment_hash FROM case_authority WHERE suffix='02')
);
SELECT old_mike_production_private.hash_parts(
  'workspace-fixture-01','project-fixture-02','job-02','DETERMINISTIC_FAKE',
  'provider-request-02',(SELECT request_hash FROM case_authority WHERE suffix='02'),
  (SELECT request_authority_hash FROM case_authority WHERE suffix='02'),
  (SELECT ledger_key_hash FROM case_authority WHERE suffix='02'),
  (SELECT ledger_commitment_hash FROM case_authority WHERE suffix='02'),
  'lookup-receipt-02','COMPLETE',old_mike_production_private.hash_parts('result','02'),NULL
) AS lookup_hash_02 \gset
SELECT * FROM old_mike_production_private.record_provider_lookup(
  'workspace-fixture-01','project-fixture-02','job-02','lookup-receipt-02','COMPLETE',
  old_mike_production_private.hash_parts('result','02'),NULL,:'lookup_hash_02'
);
SELECT old_mike_production_private.hash_parts(
  'workspace-fixture-01','project-fixture-02','job-02','1','DETERMINISTIC_FAKE',
  'provider-request-02',(SELECT request_hash FROM case_authority WHERE suffix='02'),
  (SELECT request_authority_hash FROM case_authority WHERE suffix='02'),
  (SELECT ledger_key_hash FROM case_authority WHERE suffix='02'),
  (SELECT ledger_commitment_hash FROM case_authority WHERE suffix='02'),
  'LOOKUP','lookup-receipt-02','COMPLETE',old_mike_production_private.hash_parts('result','02'),NULL
) AS observation_hash_02 \gset
SELECT pg_catalog.jsonb_build_object(
  'jobId','job-02','operation','GENERATE_DURABLE_CORE','projectId','project-fixture-02',
  'resultHash',old_mike_production_private.hash_parts('result','02'),
  'schemaVersion','m1a-c1-snapshot/1','sourceBundleHash',(SELECT bundle_hash FROM case_authority WHERE suffix='02'),
  'workspaceId','workspace-fixture-01'
)::text AS reconcile_payload_02 \gset
SELECT old_mike_production_private.canonical_json_hash(:'reconcile_payload_02'::jsonb)
  AS reconcile_payload_hash_02 \gset
SELECT old_mike_production_private.hash_parts(
  'workspace-fixture-01','project-fixture-02','1',(SELECT base_content_hash FROM case_authority WHERE suffix='02'),
  'job-02',old_mike_production_private.hash_parts('result','02'),:'reconcile_payload_hash_02'
) AS reconcile_content_hash_02 \gset
SELECT * FROM old_mike_production_private.commit_reconciliation(
  'workspace-fixture-01','project-fixture-02','job-02','observation-02','LOOKUP','lookup-receipt-02',
  'COMPLETE',old_mike_production_private.hash_parts('result','02'),NULL,:'observation_hash_02',
  'event-reconciliation-complete-02','m1a-c1-snapshot/1',:'reconcile_payload_02'::jsonb,
  :'reconcile_payload_hash_02',:'reconcile_content_hash_02'
);

-- 03: terminal provider rejection.
SELECT * FROM old_mike_production_private.commit_provider_outcome(
  'workspace-fixture-01','project-fixture-03','job-03','TERMINAL_REJECTED',
  old_mike_production_private.hash_parts('rejection-evidence','03'),NULL,NULL,
  old_mike_production_private.hash_parts('rejection-authority','03'),NULL,'POLICY_REJECTED',
  'event-generation-rejected-03',NULL,NULL,NULL,NULL
);

-- 04: independent proof that no provider submission occurred; the attempt remains immutable.
SELECT * FROM old_mike_production_private.commit_provider_outcome(
  'workspace-fixture-01','project-fixture-04','job-04','PROVEN_NOT_SUBMITTED',
  old_mike_production_private.hash_parts('non-submit-evidence','04'),NULL,NULL,NULL,
  old_mike_production_private.hash_parts('non-submit-proof','04'),'LEDGER_PROVES_NOT_SUBMITTED',
  'event-proven-not-submitted-04',NULL,NULL,NULL,NULL
);

-- 05: accepted first, then completion.
SELECT * FROM old_mike_production_private.commit_provider_outcome(
  'workspace-fixture-01','project-fixture-05','job-05','ACCEPTED',NULL,
  old_mike_production_private.hash_parts('accepted-evidence','05'),NULL,NULL,NULL,NULL,
  NULL,NULL,NULL,NULL,NULL
);
SELECT pg_catalog.jsonb_build_object(
  'jobId','job-05','operation','GENERATE_DURABLE_CORE','projectId','project-fixture-05',
  'resultHash',old_mike_production_private.hash_parts('result','05'),
  'schemaVersion','m1a-c1-snapshot/1','sourceBundleHash',(SELECT bundle_hash FROM case_authority WHERE suffix='05'),
  'workspaceId','workspace-fixture-01'
)::text AS complete_payload_05 \gset
SELECT old_mike_production_private.canonical_json_hash(:'complete_payload_05'::jsonb)
  AS complete_payload_hash_05 \gset
SELECT old_mike_production_private.hash_parts(
  'workspace-fixture-01','project-fixture-05','1',(SELECT base_content_hash FROM case_authority WHERE suffix='05'),
  'job-05',old_mike_production_private.hash_parts('result','05'),:'complete_payload_hash_05'
) AS complete_content_hash_05 \gset
SELECT * FROM old_mike_production_private.commit_provider_outcome(
  'workspace-fixture-01','project-fixture-05','job-05','COMPLETE',
  old_mike_production_private.hash_parts('complete-evidence','05'),NULL,
  old_mike_production_private.hash_parts('result','05'),NULL,NULL,NULL,
  'event-generation-complete-05','m1a-c1-snapshot/1',:'complete_payload_05'::jsonb,
  :'complete_payload_hash_05',:'complete_content_hash_05'
);

-- 06: signed webhook recovery uses its exact attempt tuple and fencing token.
SELECT * FROM old_mike_production_private.commit_provider_outcome(
  'workspace-fixture-01','project-fixture-06','job-06','COMPLETION_UNKNOWN',
  old_mike_production_private.hash_parts('unknown-evidence','06'),NULL,NULL,NULL,NULL,
  'PROVIDER_DISCONNECTED','event-generation-unknown-06',NULL,NULL,NULL,NULL
);
SELECT * FROM old_mike_production_private.receive_provider_webhook(
  'workspace-fixture-01','project-fixture-06','job-06','webhook-06','provider-event-06','key-version-01',
  128,old_mike_production_private.hash_parts('raw-body','06'),'body-object-06','body-version-06',
  old_mike_production_private.hash_parts('body-key','06'),old_mike_production_private.hash_parts('storage-receipt','06'),
  old_mike_production_private.hash_parts('signature','06'),'VALID','COMPLETE',
  old_mike_production_private.hash_parts('result','06'),NULL
);
SELECT * FROM old_mike_production_private.claim_provider_webhook(
  'workspace-fixture-01','project-fixture-06','webhook-06',old_mike_production_private.hash_parts('webhook-lease','06'),30
);
SELECT old_mike_production_private.hash_parts(
  'workspace-fixture-01','project-fixture-06','job-06','1','DETERMINISTIC_FAKE','provider-request-06',
  (SELECT request_hash FROM case_authority WHERE suffix='06'),
  (SELECT request_authority_hash FROM case_authority WHERE suffix='06'),
  (SELECT ledger_key_hash FROM case_authority WHERE suffix='06'),
  (SELECT ledger_commitment_hash FROM case_authority WHERE suffix='06'),
  'SIGNED_WEBHOOK','webhook-06','COMPLETE',old_mike_production_private.hash_parts('result','06'),NULL
) AS observation_hash_06 \gset
SELECT pg_catalog.jsonb_build_object(
  'jobId','job-06','operation','GENERATE_DURABLE_CORE','projectId','project-fixture-06',
  'resultHash',old_mike_production_private.hash_parts('result','06'),
  'schemaVersion','m1a-c1-snapshot/1','sourceBundleHash',(SELECT bundle_hash FROM case_authority WHERE suffix='06'),
  'workspaceId','workspace-fixture-01'
)::text AS reconcile_payload_06 \gset
SELECT old_mike_production_private.canonical_json_hash(:'reconcile_payload_06'::jsonb)
 AS reconcile_payload_hash_06 \gset
SELECT old_mike_production_private.hash_parts(
  'workspace-fixture-01','project-fixture-06','1',(SELECT base_content_hash FROM case_authority WHERE suffix='06'),
  'job-06',old_mike_production_private.hash_parts('result','06'),:'reconcile_payload_hash_06'
) AS reconcile_content_hash_06 \gset

SELECT * FROM old_mike_production_private.commit_reconciliation(
  'workspace-fixture-01','project-fixture-06','job-06','observation-06','SIGNED_WEBHOOK','webhook-06',
  'COMPLETE',old_mike_production_private.hash_parts('result','06'),NULL,:'observation_hash_06',
  'event-reconciliation-complete-06','m1a-c1-snapshot/1',:'reconcile_payload_06'::jsonb,
  :'reconcile_payload_hash_06',:'reconcile_content_hash_06',
  old_mike_production_private.hash_parts('webhook-lease','06'),1
);

-- 07: separately authorized human reconciliation terminates rejected.
SELECT * FROM old_mike_production_private.commit_provider_outcome(
  'workspace-fixture-01','project-fixture-07','job-07','COMPLETION_UNKNOWN',
  old_mike_production_private.hash_parts('unknown-evidence','07'),NULL,NULL,NULL,NULL,
  'PROVIDER_DISCONNECTED','event-generation-unknown-07',NULL,NULL,NULL,NULL
);
DO $cross_job_webhook_reject$
BEGIN
  BEGIN
    PERFORM * FROM old_mike_production_private.commit_reconciliation(
      'workspace-fixture-01','project-fixture-07','job-07','bad-observation-06','SIGNED_WEBHOOK','webhook-06',
      'COMPLETE',old_mike_production_private.hash_parts('result','06'),NULL,repeat('a',64),
      'bad-event-06','m1a-c1-snapshot/1','{}'::jsonb,repeat('b',64),repeat('c',64),
      old_mike_production_private.hash_parts('webhook-lease','06'),1
    );
    RAISE EXCEPTION 'm1a_c1_expected_cross_job_webhook_rejection';
  EXCEPTION WHEN no_data_found THEN NULL;
  END;
END
$cross_job_webhook_reject$;
SELECT old_mike_production_private.hash_parts(
  'workspace-fixture-01','project-fixture-07','user-fixture-01','ACTIVE_MEMBER'
) AS membership_hash_07 \gset
SELECT old_mike_production_private.hash_parts(
  'workspace-fixture-01','project-fixture-07','job-07','human-authority-07','user-fixture-01',
  :'membership_hash_07',old_mike_production_private.hash_parts('scope','07'),
  old_mike_production_private.hash_parts('policy','07'),'TERMINAL_REJECTED',NULL,
  old_mike_production_private.hash_parts('rejection-authority','07')
) AS human_decision_hash_07 \gset
SELECT * FROM old_mike_production_private.authorize_human_reconciliation(
  'workspace-fixture-01','project-fixture-07','user-fixture-01','job-07','human-authority-07',
  :'membership_hash_07',old_mike_production_private.hash_parts('scope','07'),
  old_mike_production_private.hash_parts('policy','07'),'TERMINAL_REJECTED',NULL,
  old_mike_production_private.hash_parts('rejection-authority','07'),:'human_decision_hash_07'
);
SELECT old_mike_production_private.hash_parts(
  'workspace-fixture-01','project-fixture-07','job-07','1','DETERMINISTIC_FAKE','provider-request-07',
  (SELECT request_hash FROM case_authority WHERE suffix='07'),
  (SELECT request_authority_hash FROM case_authority WHERE suffix='07'),
  (SELECT ledger_key_hash FROM case_authority WHERE suffix='07'),
  (SELECT ledger_commitment_hash FROM case_authority WHERE suffix='07'),
  'AUTHORIZED_HUMAN','human-authority-07','TERMINAL_REJECTED',NULL,
  old_mike_production_private.hash_parts('rejection-authority','07')
) AS observation_hash_07 \gset
SELECT * FROM old_mike_production_private.commit_reconciliation(
  'workspace-fixture-01','project-fixture-07','job-07','observation-07','AUTHORIZED_HUMAN','human-authority-07',
  'TERMINAL_REJECTED',NULL,old_mike_production_private.hash_parts('rejection-authority','07'),
  :'observation_hash_07','event-reconciliation-rejected-07',NULL,NULL,NULL,NULL
);

DO $cross_job_budget_reject$
BEGIN
  BEGIN
    PERFORM * FROM old_mike_production_private.record_usage(
      'workspace-fixture-01','project-fixture-03','job-03','reservation-03',
      'bad-usage-03',1,1,repeat('a',64)
    );
    RAISE EXCEPTION 'm1a_c1_expected_terminal_job_usage_hash_rejection';
  EXCEPTION WHEN raise_exception THEN
    IF SQLERRM NOT IN ('m1a_c1_usage_receipt_hash_invalid','m1a_c1_cross_job_budget_usage_forbidden') THEN RAISE; END IF;
  END;
END
$cross_job_budget_reject$;

-- Create two pending gates for external cross-process concurrency checks.
SELECT pg_catalog.jsonb_build_object(
  'actorUserId','user-fixture-01','gateRequestId','gate-concurrent-02',
  'operation','FORMAL_RESEARCH_WRITE','projectId','project-fixture-02',
  'schemaVersion','m1a-c1-gate/1','snapshotContentHash',:'reconcile_content_hash_02',
  'snapshotRevision',1,'tenantId','workspace-fixture-01','workspaceId','workspace-fixture-01'
)::text AS concurrent_gate_payload_02 \gset
SELECT old_mike_production_private.canonical_json_hash(:'concurrent_gate_payload_02'::jsonb)
 AS concurrent_gate_payload_hash_02 \gset
SELECT * FROM old_mike_production_private.request_human_gate(
  'workspace-fixture-01','workspace-fixture-01','project-fixture-02','user-fixture-01',
  'gate-concurrent-02',1,:'reconcile_content_hash_02','FORMAL_RESEARCH_WRITE','m1a-c1-gate/1',
  :'concurrent_gate_payload_02'::jsonb,:'concurrent_gate_payload_hash_02'
);

SELECT pg_catalog.jsonb_build_object(
  'actorUserId','user-fixture-01','gateRequestId','gate-formal-concurrent-06',
  'operation','FORMAL_RESEARCH_WRITE','projectId','project-fixture-06',
  'schemaVersion','m1a-c1-gate/1','snapshotContentHash',:'reconcile_content_hash_06',
  'snapshotRevision',1,'tenantId','workspace-fixture-01','workspaceId','workspace-fixture-01'
)::text AS formal_gate_payload_06 \gset
SELECT old_mike_production_private.canonical_json_hash(:'formal_gate_payload_06'::jsonb)
 AS formal_gate_payload_hash_06 \gset
SELECT * FROM old_mike_production_private.request_human_gate(
  'workspace-fixture-01','workspace-fixture-01','project-fixture-06','user-fixture-01',
  'gate-formal-concurrent-06',1,:'reconcile_content_hash_06','FORMAL_RESEARCH_WRITE','m1a-c1-gate/1',
  :'formal_gate_payload_06'::jsonb,:'formal_gate_payload_hash_06'
);
SELECT old_mike_production_private.hash_parts(
  'workspace-fixture-01','project-fixture-06','gate-formal-concurrent-06','1',
  :'reconcile_content_hash_06',:'formal_gate_payload_hash_06','CONFIRMED','user-fixture-01'
) AS formal_gate_decision_hash_06 \gset
SELECT * FROM old_mike_production_private.decide_human_gate(
  'workspace-fixture-01','project-fixture-06','gate-formal-concurrent-06','CONFIRMED',
  'user-fixture-01',:'formal_gate_decision_hash_06'
);

-- Malformed exact payload is rejected before any gate row is inserted.
DO $payload_tamper$
DECLARE
  v_snapshot_hash text;
  bad_payload jsonb;
BEGIN
  SELECT content_hash::text INTO STRICT v_snapshot_hash
    FROM old_mike_production_private.project_snapshots
   WHERE workspace_id='workspace-fixture-01' AND project_id='project-fixture-05' AND revision=1;
  bad_payload:=pg_catalog.jsonb_build_object(
    'actorUserId','user-fixture-01','extra',true,'gateRequestId','gate-bad-05',
    'operation','FORMAL_RESEARCH_WRITE','projectId','project-fixture-05',
    'schemaVersion','m1a-c1-gate/1','snapshotContentHash',v_snapshot_hash,
    'snapshotRevision',1,'tenantId','workspace-fixture-01','workspaceId','workspace-fixture-01'
  );
  BEGIN
    PERFORM * FROM old_mike_production_private.request_human_gate(
      'workspace-fixture-01','workspace-fixture-01','project-fixture-05','user-fixture-01',
      'gate-bad-05',1,v_snapshot_hash,'FORMAL_RESEARCH_WRITE','m1a-c1-gate/1',
      bad_payload,old_mike_production_private.canonical_json_hash(bad_payload)
    );
    RAISE EXCEPTION 'm1a_c1_expected_payload_tamper_rejection';
  EXCEPTION WHEN raise_exception THEN
    IF SQLERRM<>'m1a_c1_payload_authority_invalid' THEN RAISE; END IF;
  END;
END
$payload_tamper$;

DO $advanced_assertions$
BEGIN
  IF (SELECT pg_catalog.count(*) FROM old_mike_production_private.ai_jobs WHERE job_id IN ('job-02','job-03','job-04','job-05','job-06','job-07'))<>6 THEN
    RAISE EXCEPTION 'm1a_c1_advanced_job_count_invalid';
  END IF;
  IF (SELECT state FROM old_mike_production_private.ai_jobs WHERE project_id='project-fixture-02')<>'SUCCEEDED'
     OR (SELECT state FROM old_mike_production_private.ai_jobs WHERE project_id='project-fixture-03')<>'TERMINAL_REJECTED'
     OR (SELECT state FROM old_mike_production_private.ai_jobs WHERE project_id='project-fixture-04')<>'PROVEN_NOT_SUBMITTED'
     OR (SELECT state FROM old_mike_production_private.ai_jobs WHERE project_id='project-fixture-05')<>'SUCCEEDED'
     OR (SELECT state FROM old_mike_production_private.ai_jobs WHERE project_id='project-fixture-06')<>'SUCCEEDED'
     OR (SELECT state FROM old_mike_production_private.ai_jobs WHERE project_id='project-fixture-07')<>'TERMINAL_REJECTED' THEN
    RAISE EXCEPTION 'm1a_c1_provider_outcome_totality_invalid';
  END IF;
  IF EXISTS (SELECT 1 FROM old_mike_production_private.ai_jobs WHERE provider_submission_count<>1) THEN
    RAISE EXCEPTION 'm1a_c1_provider_submission_count_not_exact';
  END IF;
  IF EXISTS (SELECT 1 FROM old_mike_production_private.human_gate_requests WHERE gate_request_id='gate-bad-05') THEN
    RAISE EXCEPTION 'm1a_c1_bad_gate_was_persisted';
  END IF;
END
$advanced_assertions$;

SELECT pg_catalog.jsonb_build_object(
  'completionUnknownLookupOnly',true,
  'humanReconciliation',true,
  'providerOutcomeStates',(SELECT pg_catalog.jsonb_agg(state ORDER BY state) FROM old_mike_production_private.ai_jobs WHERE job_id IN ('job-02','job-03','job-04','job-05','job-06','job-07')),
  'signedWebhookRecovery',true,
  'status','PASS',
  'submissionCount',(SELECT pg_catalog.sum(provider_submission_count) FROM old_mike_production_private.ai_jobs)
)::text AS advanced_capability_result;
