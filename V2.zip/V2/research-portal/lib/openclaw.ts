import "server-only";

import type { ResolvedModelRoute } from "./model-route-catalog.ts";
import { RESEARCH_START_STAGE_OUTPUT_LIMIT_BYTES, RESEARCH_START_STAGE_PROVIDER_TIMEOUT_MS, TOPIC_LAB_OUTPUT_LIMIT_BYTES, TOPIC_LAB_PROVIDER_TIMEOUT_MS } from "./topic-lab-runtime-contract.ts";

export type OpenClawMessage = { role: "system" | "user" | "assistant"; content: string };
export type OpenClawChatOperation = "M01_TOPIC_LAB" | "M01_RESEARCH_DIRECTIONS" | "M01_RESEARCH_S0_EXPAND" | "M01_S0_DRAFT" | "M01_HORIZON" | "M01_EVIDENCE" | "M01_FIELD" | "M01_WEB_PREVIEW" | "ACADEMIC_LANGUAGE" | "REVIEW_STUDIO" | "JOURNAL_SUBMISSION" | "PROJECT_CHAT" |
  "ASSIST_S0" | "ASSIST_M01" | "ASSIST_M02" | "ASSIST_M03" | "ASSIST_M04" | "ASSIST_M05_BILINGUAL" | "ASSIST_M05_RATIONALE" | "ASSIST_M05_METHODS" | "ASSIST_M05_MODE" | "ASSIST_M05_EXECUTION" | "ASSIST_M05_BUDGET" | "ASSIST_RESEARCH_DESIGN" | "ASSIST_RESEARCH_CLAIM" | "ASSIST_RESEARCH_DOCUMENT";

export const openClawChatOperationContracts: Readonly<Record<OpenClawChatOperation, Readonly<{ endpointFamily: "CHAT_COMPLETIONS"; endpointFeatureState: "ENABLED" }>>> = Object.freeze({
  M01_TOPIC_LAB: Object.freeze({ endpointFamily: "CHAT_COMPLETIONS", endpointFeatureState: "ENABLED" }),
  M01_RESEARCH_DIRECTIONS: Object.freeze({ endpointFamily: "CHAT_COMPLETIONS", endpointFeatureState: "ENABLED" }),
  M01_RESEARCH_S0_EXPAND: Object.freeze({ endpointFamily: "CHAT_COMPLETIONS", endpointFeatureState: "ENABLED" }),
  M01_S0_DRAFT: Object.freeze({ endpointFamily: "CHAT_COMPLETIONS", endpointFeatureState: "ENABLED" }),
  M01_HORIZON: Object.freeze({ endpointFamily: "CHAT_COMPLETIONS", endpointFeatureState: "ENABLED" }),
  M01_EVIDENCE: Object.freeze({ endpointFamily: "CHAT_COMPLETIONS", endpointFeatureState: "ENABLED" }),
  M01_FIELD: Object.freeze({ endpointFamily: "CHAT_COMPLETIONS", endpointFeatureState: "ENABLED" }),
  M01_WEB_PREVIEW: Object.freeze({ endpointFamily: "CHAT_COMPLETIONS", endpointFeatureState: "ENABLED" }),
  ACADEMIC_LANGUAGE: Object.freeze({ endpointFamily: "CHAT_COMPLETIONS", endpointFeatureState: "ENABLED" }),
  REVIEW_STUDIO: Object.freeze({ endpointFamily: "CHAT_COMPLETIONS", endpointFeatureState: "ENABLED" }),
  JOURNAL_SUBMISSION: Object.freeze({ endpointFamily: "CHAT_COMPLETIONS", endpointFeatureState: "ENABLED" }),
  PROJECT_CHAT: Object.freeze({ endpointFamily: "CHAT_COMPLETIONS", endpointFeatureState: "ENABLED" }),
  ASSIST_S0: Object.freeze({ endpointFamily: "CHAT_COMPLETIONS", endpointFeatureState: "ENABLED" }),
  ASSIST_M01: Object.freeze({ endpointFamily: "CHAT_COMPLETIONS", endpointFeatureState: "ENABLED" }),
  ASSIST_M02: Object.freeze({ endpointFamily: "CHAT_COMPLETIONS", endpointFeatureState: "ENABLED" }),
  ASSIST_M03: Object.freeze({ endpointFamily: "CHAT_COMPLETIONS", endpointFeatureState: "ENABLED" }),
  ASSIST_M04: Object.freeze({ endpointFamily: "CHAT_COMPLETIONS", endpointFeatureState: "ENABLED" }),
  ASSIST_M05_BILINGUAL: Object.freeze({ endpointFamily: "CHAT_COMPLETIONS", endpointFeatureState: "ENABLED" }),
  ASSIST_M05_RATIONALE: Object.freeze({ endpointFamily: "CHAT_COMPLETIONS", endpointFeatureState: "ENABLED" }),
  ASSIST_M05_METHODS: Object.freeze({ endpointFamily: "CHAT_COMPLETIONS", endpointFeatureState: "ENABLED" }),
  ASSIST_M05_MODE: Object.freeze({ endpointFamily: "CHAT_COMPLETIONS", endpointFeatureState: "ENABLED" }),
  ASSIST_M05_EXECUTION: Object.freeze({ endpointFamily: "CHAT_COMPLETIONS", endpointFeatureState: "ENABLED" }),
  ASSIST_M05_BUDGET: Object.freeze({ endpointFamily: "CHAT_COMPLETIONS", endpointFeatureState: "ENABLED" }),
  ASSIST_RESEARCH_DESIGN: Object.freeze({ endpointFamily: "CHAT_COMPLETIONS", endpointFeatureState: "ENABLED" }),
  ASSIST_RESEARCH_CLAIM: Object.freeze({ endpointFamily: "CHAT_COMPLETIONS", endpointFeatureState: "ENABLED" }),
  ASSIST_RESEARCH_DOCUMENT: Object.freeze({ endpointFamily: "CHAT_COMPLETIONS", endpointFeatureState: "ENABLED" }),
});

export type OpenClawCallResult =
  | { kind: "demo" }
  | { kind: "not-configured" }
  | { kind: "invalid-config" }
  | { kind: "upstream-error" }
  | { kind: "success"; content: string };

export type OpenClawChatCompletionProtocolResult =
  | { kind: "success"; content: string }
  | { kind: "proven-not-submitted"; code: "configuration_missing" | "configuration_invalid" | "request_invalid" | "canceled_before_submission" }
  | { kind: "terminal-rejected"; code: "http_rejected" | "content_type_rejected" | "body_rejected" | "response_shape_invalid"; evidence: OpenClawFailureEvidence }
  | { kind: "completion-unknown"; code: "provider_deadline" | "caller_cancel" | "transport_failure_before_headers" | "transport_failure_after_headers"; evidence: OpenClawFailureEvidence };

export type OpenClawFailureReason =
  | "PROVIDER_DEADLINE"
  | "CALLER_CANCEL"
  | "TRANSPORT_FAILURE_BEFORE_HEADERS"
  | "TRANSPORT_FAILURE_AFTER_HEADERS"
  | "UPSTREAM_HTTP_REJECTED"
  | "CONTENT_TYPE_REJECTED"
  | "BODY_REJECTED"
  | "RESPONSE_SHAPE_REJECTED";
export type OpenClawElapsedBucket = "LT_1S" | "S1_TO_LT_5S" | "S5_TO_LT_20S" | "S20_TO_LT_60S" | "GE_60S";
export type OpenClawProviderAttemptClass = "SUBMISSION_POSSIBLE" | "RESPONSE_HEADERS_RECEIVED" | "RESPONSE_COMPLETE";
export type OpenClawFailureEvidence = Readonly<{
  reasonEnum: OpenClawFailureReason;
  elapsedBucket: OpenClawElapsedBucket;
  providerAttemptClass: OpenClawProviderAttemptClass;
}>;

type OpenClawAbortReason = "PROVIDER_DEADLINE" | "CALLER_CANCEL";

class BoundedBodyRejection extends Error {
  constructor() {
    super("bounded_body_rejected");
    this.name = "BoundedBodyRejection";
  }
}

export type OpenClawProtocolRoute = Omit<ResolvedModelRoute, "operation"> & { operation: OpenClawChatOperation };

export function isPrivateGatewayUrl(value: string) {
  try {
    const url = new URL(value);
    const hostname = url.hostname.toLowerCase();
    const isZeaburServiceHostname = /^service-[a-f0-9]{24}$/.test(hostname);
    const isPrivateHostname = hostname === "localhost" || hostname === "127.0.0.1" || hostname.endsWith(".zeabur.internal") || isZeaburServiceHostname;
    return url.protocol === "http:" && isPrivateHostname && !url.username && !url.password && !url.search && !url.hash && url.pathname === "/";
  } catch {
    return false;
  }
}

export function normalizePrivateGatewayBaseUrl(value: string) {
  if (!isPrivateGatewayUrl(value)) return null;
  return new URL(value).toString().replace(/\/$/u, "");
}

async function readBounded(response: Response, maximumBytes: number) {
  const declared = Number(response.headers.get("content-length") || "0");
  if (Number.isFinite(declared) && declared > maximumBytes) {
    await response.body?.cancel().catch(() => undefined);
    throw new BoundedBodyRejection();
  }
  if (!response.body) throw new BoundedBodyRejection();
  const reader = response.body.getReader();
  const chunks: Uint8Array[] = [];
  let total = 0;
  try {
    while (true) {
      const item = await reader.read();
      if (item.done) break;
      total += item.value.byteLength;
      if (total > maximumBytes) { await reader.cancel().catch(() => undefined); throw new BoundedBodyRejection(); }
      chunks.push(item.value);
    }
  } finally { reader.releaseLock(); }
  return Buffer.concat(chunks.map((chunk) => Buffer.from(chunk))).toString("utf8");
}

const existingOperationDefaultRoute = Object.freeze({
  routeProfile: "OLD_MIKE_DEFAULT",
  upstreamBehavior: "DEFER_TO_EXISTING_DEFAULT",
  modelOverride: null,
  inputLimitBytes: 48_000,
  outputLimitBytes: 64_000,
  timeoutMs: 20_000,
  endpointFamily: "CHAT_COMPLETIONS",
  endpointFeatureState: "ENABLED",
} as const);

const OPENCLAW_DEFAULT_AGENT_ALIAS = "openclaw/default";

function elapsedBucket(startedAt: number): OpenClawElapsedBucket {
  const elapsed = Math.max(0, performance.now() - startedAt);
  if (elapsed < 1_000) return "LT_1S";
  if (elapsed < 5_000) return "S1_TO_LT_5S";
  if (elapsed < 20_000) return "S5_TO_LT_20S";
  if (elapsed < 60_000) return "S20_TO_LT_60S";
  return "GE_60S";
}

function failureEvidence(startedAt: number, reasonEnum: OpenClawFailureReason, providerAttemptClass: OpenClawProviderAttemptClass): OpenClawFailureEvidence {
  return Object.freeze({ reasonEnum, elapsedBucket: elapsedBucket(startedAt), providerAttemptClass });
}

function createAbortCauseTracker(callerSignal: AbortSignal | undefined, timeoutSignal: AbortSignal) {
  let firstReason: OpenClawAbortReason | null = null;
  const markCaller = () => { firstReason ??= "CALLER_CANCEL"; };
  const markDeadline = () => { firstReason ??= "PROVIDER_DEADLINE"; };
  callerSignal?.addEventListener("abort", markCaller, { once: true });
  timeoutSignal.addEventListener("abort", markDeadline, { once: true });
  const signal = callerSignal ? AbortSignal.any([callerSignal, timeoutSignal]) : timeoutSignal;
  return {
    signal,
    firstReason: () => firstReason,
    dispose: () => {
      callerSignal?.removeEventListener("abort", markCaller);
      timeoutSignal.removeEventListener("abort", markDeadline);
    },
  };
}

function abortCompletionUnknown(startedAt: number, reason: OpenClawAbortReason, providerAttemptClass: OpenClawProviderAttemptClass): OpenClawChatCompletionProtocolResult {
  return reason === "CALLER_CANCEL"
    ? { kind: "completion-unknown", code: "caller_cancel", evidence: failureEvidence(startedAt, reason, providerAttemptClass) }
    : { kind: "completion-unknown", code: "provider_deadline", evidence: failureEvidence(startedAt, reason, providerAttemptClass) };
}

export function resolveDefaultOpenClawOperationRoute(operation: OpenClawChatOperation): OpenClawProtocolRoute {
  return {
    ...existingOperationDefaultRoute,
    ...(operation === "M01_TOPIC_LAB" ? { timeoutMs: TOPIC_LAB_PROVIDER_TIMEOUT_MS, outputLimitBytes: TOPIC_LAB_OUTPUT_LIMIT_BYTES } : {}),
    ...(["M01_RESEARCH_DIRECTIONS", "M01_RESEARCH_S0_EXPAND"].includes(operation) ? { timeoutMs: RESEARCH_START_STAGE_PROVIDER_TIMEOUT_MS, outputLimitBytes: RESEARCH_START_STAGE_OUTPUT_LIMIT_BYTES } : {}),
    modeProfile: "AUTO",
    operation,
    featureState: "ENABLED",
    costBucket: "MEDIUM",
  };
}

function validMessages(messages: OpenClawMessage[]) {
  return Array.isArray(messages) && messages.length > 0 && messages.length <= 64 && messages.every((message) =>
    message && ["system", "user", "assistant"].includes(message.role) && typeof message.content === "string" && message.content.length > 0 && message.content.length <= 48_000 && !/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/.test(message.content),
  );
}

function record(value: unknown): value is Record<string, unknown> {
  return Boolean(value) && typeof value === "object" && !Array.isArray(value);
}

export async function executeOpenClawChatCompletion(input: {
  messages: OpenClawMessage[];
  sessionKey: string;
  operation: OpenClawChatOperation;
  route: OpenClawProtocolRoute;
  baseUrl: string | undefined;
  bearerToken: string | undefined;
  signal?: AbortSignal;
}): Promise<OpenClawChatCompletionProtocolResult> {
  const operationContract = openClawChatOperationContracts[input.operation];
  if (!input.baseUrl || !input.bearerToken) return { kind: "proven-not-submitted", code: "configuration_missing" };
  const baseUrl = normalizePrivateGatewayBaseUrl(input.baseUrl);
  if (
    !baseUrl ||
    typeof input.bearerToken !== "string" || input.bearerToken.length < 16 || input.bearerToken.length > 4_096 || /[\u0000-\u001f\u007f]/u.test(input.bearerToken)
  ) return { kind: "proven-not-submitted", code: "configuration_invalid" };
  if (
    input.route.routeProfile !== "OLD_MIKE_DEFAULT" ||
    input.route.upstreamBehavior !== "DEFER_TO_EXISTING_DEFAULT" ||
    input.route.modelOverride !== null ||
    input.route.operation !== input.operation ||
    input.route.endpointFamily !== operationContract?.endpointFamily ||
    input.route.endpointFeatureState !== operationContract?.endpointFeatureState ||
    !validMessages(input.messages) ||
    typeof input.sessionKey !== "string" || input.sessionKey.length < 8 || input.sessionKey.length > 256 || /[\u0000-\u001f\u007f]/u.test(input.sessionKey)
  ) return { kind: "proven-not-submitted", code: "request_invalid" };
  if (input.signal?.aborted) return { kind: "proven-not-submitted", code: "canceled_before_submission" };

  const body = JSON.stringify({
    model: OPENCLAW_DEFAULT_AGENT_ALIAS,
    messages: input.messages,
    stream: false,
    user: input.sessionKey,
  });
  if (Buffer.byteLength(body, "utf8") > input.route.inputLimitBytes) return { kind: "proven-not-submitted", code: "request_invalid" };

  const startedAt = performance.now();
  const timeoutSignal = AbortSignal.timeout(input.route.timeoutMs);
  const abortCause = createAbortCauseTracker(input.signal, timeoutSignal);
  try {
    let response: Response;
    try {
      response = await fetch(`${baseUrl}/v1/chat/completions`, {
        method: "POST",
        headers: { Authorization: `Bearer ${input.bearerToken}`, "Content-Type": "application/json" },
        body,
        signal: abortCause.signal,
        cache: "no-store",
        redirect: "manual",
      });
    } catch {
      const reason = abortCause.firstReason();
      if (reason) return abortCompletionUnknown(startedAt, reason, "SUBMISSION_POSSIBLE");
      return { kind: "completion-unknown", code: "transport_failure_before_headers", evidence: failureEvidence(startedAt, "TRANSPORT_FAILURE_BEFORE_HEADERS", "SUBMISSION_POSSIBLE") };
    }
    if (response.status !== 200) {
      await response.body?.cancel().catch(() => undefined);
      return { kind: "terminal-rejected", code: "http_rejected", evidence: failureEvidence(startedAt, "UPSTREAM_HTTP_REJECTED", "RESPONSE_HEADERS_RECEIVED") };
    }
    if (!(response.headers.get("content-type") || "").toLowerCase().startsWith("application/json")) {
      await response.body?.cancel().catch(() => undefined);
      return { kind: "terminal-rejected", code: "content_type_rejected", evidence: failureEvidence(startedAt, "CONTENT_TYPE_REJECTED", "RESPONSE_HEADERS_RECEIVED") };
    }
    let raw: string;
    try {
      raw = await readBounded(response, input.route.outputLimitBytes);
    } catch (error) {
      if (error instanceof BoundedBodyRejection) return { kind: "terminal-rejected", code: "body_rejected", evidence: failureEvidence(startedAt, "BODY_REJECTED", "RESPONSE_HEADERS_RECEIVED") };
      const reason = abortCause.firstReason();
      if (reason) return abortCompletionUnknown(startedAt, reason, "RESPONSE_HEADERS_RECEIVED");
      return { kind: "completion-unknown", code: "transport_failure_after_headers", evidence: failureEvidence(startedAt, "TRANSPORT_FAILURE_AFTER_HEADERS", "RESPONSE_HEADERS_RECEIVED") };
    }
    let data: unknown;
    try { data = JSON.parse(raw) as unknown; }
    catch { return { kind: "terminal-rejected", code: "response_shape_invalid", evidence: failureEvidence(startedAt, "RESPONSE_SHAPE_REJECTED", "RESPONSE_COMPLETE") }; }
    if (!record(data) || data.object !== "chat.completion" || !Array.isArray(data.choices) || data.choices.length !== 1) return { kind: "terminal-rejected", code: "response_shape_invalid", evidence: failureEvidence(startedAt, "RESPONSE_SHAPE_REJECTED", "RESPONSE_COMPLETE") };
    const choice = data.choices[0];
    if (!record(choice) || choice.index !== 0 || choice.finish_reason !== "stop" || !record(choice.message) || choice.message.role !== "assistant" || typeof choice.message.content !== "string") return { kind: "terminal-rejected", code: "response_shape_invalid", evidence: failureEvidence(startedAt, "RESPONSE_SHAPE_REJECTED", "RESPONSE_COMPLETE") };
    const content = choice.message.content.trim();
    return content ? { kind: "success", content } : { kind: "terminal-rejected", code: "response_shape_invalid", evidence: failureEvidence(startedAt, "RESPONSE_SHAPE_REJECTED", "RESPONSE_COMPLETE") };
  } finally {
    abortCause.dispose();
  }
}

export async function executeDefaultOpenClawChatCompletion(
  messages: OpenClawMessage[],
  sessionKey: string,
  operation: OpenClawChatOperation,
  signal?: AbortSignal,
): Promise<OpenClawChatCompletionProtocolResult> {
  if (!operation.startsWith("M01_") && !operation.startsWith("ASSIST_")) return { kind: "proven-not-submitted", code: "request_invalid" };
  return executeOpenClawChatCompletion({
    messages,
    sessionKey,
    operation,
    route: resolveDefaultOpenClawOperationRoute(operation),
    baseUrl: process.env.OPENCLAW_BASE_URL,
    bearerToken: process.env.OPENCLAW_GATEWAY_TOKEN,
    signal,
  });
}

export async function callOpenClaw(messages: OpenClawMessage[], userId: string, operation: OpenClawChatOperation, route?: ResolvedModelRoute, signal?: AbortSignal): Promise<OpenClawCallResult> {
  if (!route && !operation.startsWith("M01_") && !operation.startsWith("ASSIST_")) return { kind: "invalid-config" };
  if (route && route.operation !== operation) return { kind: "invalid-config" };
  const effectiveRoute: OpenClawProtocolRoute = route
    ? { ...route, operation }
    : resolveDefaultOpenClawOperationRoute(operation);
  const result = route
    ? await executeOpenClawChatCompletion({ messages, sessionKey: userId, operation, route: effectiveRoute, baseUrl: process.env.OPENCLAW_BASE_URL, bearerToken: process.env.OPENCLAW_GATEWAY_TOKEN, signal })
    : await executeDefaultOpenClawChatCompletion(messages, userId, operation, signal);
  if (result.kind === "success") return result;
  if (result.kind === "proven-not-submitted") return { kind: result.code === "configuration_missing" ? "not-configured" : "invalid-config" };
  return { kind: "upstream-error" };
}
