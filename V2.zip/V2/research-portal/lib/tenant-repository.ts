import "server-only";

import { createHash, randomUUID } from "node:crypto";
import { Pool, type PoolClient } from "pg";
import { authConfiguration } from "./auth-config.ts";
import { canAccessProject, listProjectsForUser, type ProjectRecord, type TenantFixture, type TenantUser } from "./tenant-model.ts";
import type { S0Intake } from "./project-contract.ts";

const pool = process.env.DATABASE_URL ? new Pool({ connectionString: process.env.DATABASE_URL, max: 5 }) : null;

export type ProjectCreateInput = {
  identity: TenantUser;
  projectId: string;
  previewHash: string;
  intake: S0Intake;
};

export type ProjectCreateResult = {
  projectId: string;
  title: string;
  status: "ACTIVE";
  storageBackend: "POSTGRES_INDEX_PENDING_SAFE_STORAGE";
  intakePersistence: "APPEND_ONLY_RESEARCH_DOCUMENT" | "PENDING_ARTIFACT_COMMITMENT";
  idempotent: boolean;
};

export type TenantRepository = {
  list(identity: TenantUser): Promise<ProjectRecord[]>;
  get(identity: TenantUser, projectId: string): Promise<ProjectRecord | null>;
  canCreate(identity: TenantUser): Promise<boolean>;
  create(input: ProjectCreateInput): Promise<ProjectCreateResult>;
};

export class TenantStorageUnavailable extends Error {
  constructor() { super("tenant_storage_not_ready"); this.name = "TenantStorageUnavailable"; }
}

export class TenantProjectUnauthorized extends Error {
  readonly code = "project_create_unauthorized";
  constructor() { super("project_create_unauthorized"); this.name = "TenantProjectUnauthorized"; }
}

export class TenantProjectConflict extends Error {
  readonly code = "project_create_conflict";
  constructor() { super("project_create_conflict"); this.name = "TenantProjectConflict"; }
}

function sha256(value: string) {
  return createHash("sha256").update(value, "utf8").digest("hex");
}

function canonicalS0Intake(intake: S0Intake) {
  return JSON.stringify({
    contractVersion: "old-mike-s0-intake/1.0.0",
    workingTitle: intake.workingTitle,
    domain: intake.domain,
    outputTrack: intake.outputTrack,
    problemContext: intake.problemContext,
    targetUsers: intake.targetUsers,
    expectedContribution: intake.expectedContribution,
    existingData: intake.existingData,
    availableData: intake.availableData,
    methodIdea: intake.methodIdea,
    timeline: intake.timeline,
    constraints: intake.constraints,
    ethicsPrivacyRisks: intake.ethicsPrivacyRisks,
    unresolvedItems: intake.unresolvedItems,
  });
}

function authorityIds(input: ProjectCreateInput) {
  const scope = sha256(`${input.identity.workspaceId}\n${input.projectId}`);
  return { artifactId: `artifact_s0_${scope.slice(0, 32)}`, documentId: `document_s0_${scope.slice(0, 32)}` };
}

async function coreSchemaAvailable(client: PoolClient) {
  const result = await client.query<{ projects: boolean; artifacts: boolean; members: boolean }>(
    `SELECT to_regclass('public.projects') IS NOT NULL AS projects,
            to_regclass('public.project_artifacts') IS NOT NULL AS artifacts,
            to_regclass('public.workspace_members') IS NOT NULL AS members`,
  );
  const row = result.rows[0];
  return Boolean(row?.projects && row.artifacts && row.members);
}

async function researchDocumentsSupported(client: PoolClient) {
  const required = ["id", "logical_id", "version_number", "workspace_id", "project_id", "created_by_user_id", "document_type", "title", "body", "content_hash", "stage_detail"];
  const result = await client.query<{ relationPresent: boolean; columns: number; appendOnlyTrigger: boolean }>(
    `SELECT to_regclass('public.research_documents') IS NOT NULL AS "relationPresent",
            (SELECT count(*)::int FROM information_schema.columns
              WHERE table_schema='public' AND table_name='research_documents' AND column_name = ANY($1::text[])) AS columns,
            EXISTS (
              SELECT 1 FROM pg_trigger t JOIN pg_class c ON c.oid=t.tgrelid JOIN pg_namespace n ON n.oid=c.relnamespace
               WHERE n.nspname='public' AND c.relname='research_documents'
                 AND t.tgname='research_documents_append_only' AND t.tgenabled IN ('O','A') AND NOT t.tgisinternal
            ) AS "appendOnlyTrigger"`,
    [required],
  );
  const row = result.rows[0];
  return Boolean(row?.relationPresent && row.columns === required.length && row.appendOnlyTrigger);
}

async function auditSupported(client: PoolClient) {
  const required = ["workspace_id", "user_id", "event_type", "outcome", "metadata"];
  const result = await client.query<{ relationPresent: boolean; columns: number }>(
    `SELECT to_regclass('public.audit_events') IS NOT NULL AS "relationPresent",
            (SELECT count(*)::int FROM information_schema.columns
              WHERE table_schema='public' AND table_name='audit_events' AND column_name = ANY($1::text[])) AS columns`,
    [required],
  );
  return Boolean(result.rows[0]?.relationPresent && result.rows[0]?.columns === required.length);
}

/**
 * Better Auth owns account/session records. This hook creates the separate
 * personal workspace index after the user record is created. It never creates
 * an agent directory and it cannot claim the shared legacy project.
 */
export async function ensurePersonalWorkspace(user: { id: string; name?: string | null }) {
  if (!pool || !authConfiguration().ready) throw new TenantStorageUnavailable();
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const workspace = await client.query<{ id: string }>(
      "INSERT INTO workspaces (id, name, owner_user_id) VALUES ($1, $2, $3) ON CONFLICT (owner_user_id) DO UPDATE SET name = EXCLUDED.name RETURNING id",
      [`ws_${randomUUID()}`, `${user.name?.trim() || "Personal"} Workspace`, user.id],
    );
    const workspaceId = workspace.rows[0]?.id;
    if (!workspaceId) throw new TenantStorageUnavailable();
    await client.query(
      "INSERT INTO workspace_members (workspace_id, user_id, role) VALUES ($1, $2, 'owner') ON CONFLICT (workspace_id, user_id) DO UPDATE SET role = 'owner'",
      [workspaceId, user.id],
    );
    await client.query("COMMIT");
    return workspaceId;
  } catch (error) {
    await client.query("ROLLBACK").catch(() => undefined);
    throw error;
  } finally {
    client.release();
  }
}

export class PostgresProjectRepository implements TenantRepository {
  readonly databasePool: Pool | null;
  constructor(databasePool: Pool | null = pool) { this.databasePool = databasePool; }

  async list(identity: TenantUser) {
    if (!this.databasePool || !authConfiguration().ready) throw new TenantStorageUnavailable();
    const result = await this.databasePool.query<ProjectRecord>("SELECT project_id AS \"projectId\", workspace_id AS \"workspaceId\", created_by AS \"ownerUserId\", title, status, legacy FROM projects WHERE workspace_id = $1 AND created_by = $2 AND legacy = false ORDER BY created_at DESC", [identity.workspaceId, identity.userId]);
    return result.rows;
  }

  async get(identity: TenantUser, projectId: string) {
    if (!this.databasePool || !authConfiguration().ready) throw new TenantStorageUnavailable();
    const result = await this.databasePool.query<ProjectRecord>("SELECT project_id AS \"projectId\", workspace_id AS \"workspaceId\", created_by AS \"ownerUserId\", title, status, legacy FROM projects WHERE project_id = $1 AND workspace_id = $2 AND created_by = $3 AND legacy = false", [projectId, identity.workspaceId, identity.userId]);
    return result.rows[0] || null;
  }

  async canCreate(identity: TenantUser) {
    if (!this.databasePool || !authConfiguration().ready) throw new TenantStorageUnavailable();
    const client = await this.databasePool.connect();
    try {
      if (!(await coreSchemaAvailable(client))) return false;
      const membership = await client.query<{ role: "owner" | "member" }>(
        "SELECT role FROM workspace_members WHERE workspace_id=$1 AND user_id=$2 AND role IN ('owner','member')",
        [identity.workspaceId, identity.userId],
      );
      return membership.rows[0]?.role === identity.role;
    } finally {
      client.release();
    }
  }

  async create(input: ProjectCreateInput): Promise<ProjectCreateResult> {
    if (!this.databasePool || !authConfiguration().ready) throw new TenantStorageUnavailable();
    if (!/^[a-z0-9](?:[a-z0-9-]{0,62}[a-z0-9])?$/.test(input.projectId) || !/^[a-f0-9]{64}$/.test(input.previewHash)) throw new TenantProjectConflict();
    const client = await this.databasePool.connect();
    const { artifactId, documentId } = authorityIds(input);
    const body = canonicalS0Intake(input.intake);
    const documentHash = sha256(body);
    try {
      await client.query("BEGIN");
      await client.query("SET LOCAL statement_timeout = '10000ms'");
      await client.query("SET LOCAL lock_timeout = '3000ms'");
      if (!(await coreSchemaAvailable(client))) throw new TenantStorageUnavailable();
      const membership = await client.query<{ role: "owner" | "member" }>(
        "SELECT role FROM workspace_members WHERE workspace_id=$1 AND user_id=$2 AND role IN ('owner','member') FOR SHARE",
        [input.identity.workspaceId, input.identity.userId],
      );
      if (membership.rows[0]?.role !== input.identity.role) throw new TenantProjectUnauthorized();
      await client.query("SELECT pg_advisory_xact_lock(hashtextextended($1, 0))", [input.projectId]);

      const documentPersistence = await researchDocumentsSupported(client);
      const auditAvailable = await auditSupported(client);
      const intakePersistence = documentPersistence ? "APPEND_ONLY_RESEARCH_DOCUMENT" as const : "PENDING_ARTIFACT_COMMITMENT" as const;
      const contentRef = JSON.stringify({
        contractVersion: "old-mike-project-intake-commitment/1.0.0",
        previewHash: input.previewHash,
        documentHash,
        persistence: intakePersistence,
      });
      const existing = await client.query<{ projectId: string; workspaceId: string; ownerUserId: string; title: string; status: string; legacy: boolean; storageBackend: string }>(
        `SELECT project_id AS "projectId", workspace_id AS "workspaceId", created_by AS "ownerUserId", title, status, legacy, storage_backend AS "storageBackend"
           FROM projects WHERE project_id=$1 FOR UPDATE`,
        [input.projectId],
      );
      const prior = existing.rows[0];
      if (prior) {
        const exactProject = prior.workspaceId === input.identity.workspaceId && prior.ownerUserId === input.identity.userId && prior.title === input.intake.workingTitle && prior.status === "ACTIVE" && prior.legacy === false && prior.storageBackend === "POSTGRES_INDEX_PENDING_SAFE_STORAGE";
        const artifact = await client.query<{ contentRef: string }>("SELECT content_ref AS \"contentRef\" FROM project_artifacts WHERE id=$1 AND workspace_id=$2 AND project_id=$3", [artifactId, input.identity.workspaceId, input.projectId]);
        if (!exactProject || artifact.rows[0]?.contentRef !== contentRef) throw new TenantProjectConflict();
        if (documentPersistence) {
          const document = await client.query<{ contentHash: string; body: string }>("SELECT content_hash AS \"contentHash\", body FROM research_documents WHERE id=$1 AND workspace_id=$2 AND project_id=$3", [documentId, input.identity.workspaceId, input.projectId]);
          if (document.rows[0]?.contentHash !== documentHash || document.rows[0]?.body !== body) throw new TenantProjectConflict();
        }
        if (auditAvailable) {
          const audit = await client.query<{ count: number }>(
            `SELECT count(*)::int AS count FROM audit_events
              WHERE workspace_id=$1 AND user_id=$2 AND event_type='PROJECT_CREATED' AND outcome='SUCCESS'
                AND metadata->>'projectCommitment'=$3 AND metadata->>'previewHash'=$4`,
            [input.identity.workspaceId, input.identity.userId, sha256(input.projectId), input.previewHash],
          );
          if (audit.rows[0]?.count !== 1) throw new TenantProjectConflict();
        }
        await client.query("COMMIT");
        return { projectId: input.projectId, title: prior.title, status: "ACTIVE", storageBackend: "POSTGRES_INDEX_PENDING_SAFE_STORAGE", intakePersistence, idempotent: true };
      }

      await client.query(
        `INSERT INTO projects (project_id,workspace_id,created_by,title,status,legacy,storage_backend)
         VALUES ($1,$2,$3,$4,'ACTIVE',false,'POSTGRES_INDEX_PENDING_SAFE_STORAGE')`,
        [input.projectId, input.identity.workspaceId, input.identity.userId, input.intake.workingTitle],
      );
      await client.query(
        "INSERT INTO project_artifacts (id,project_id,workspace_id,artifact_type,content_ref) VALUES ($1,$2,$3,'S0_INTAKE_COMMITMENT',$4)",
        [artifactId, input.projectId, input.identity.workspaceId, contentRef],
      );
      if (documentPersistence) {
        await client.query(
          `INSERT INTO research_documents
             (id,logical_id,version_number,workspace_id,project_id,created_by_user_id,document_type,title,body,content_hash,stage_detail)
           VALUES ($1,'s0-intake',1,$2,$3,$4,'RESEARCH_PLAN',$5,$6,$7,'S0_INTAKE')`,
          [documentId, input.identity.workspaceId, input.projectId, input.identity.userId, input.intake.workingTitle, body, documentHash],
        );
      }
      if (auditAvailable) {
        await client.query(
          `INSERT INTO audit_events (workspace_id,user_id,event_type,outcome,metadata)
           VALUES ($1,$2,'PROJECT_CREATED','SUCCESS',$3::jsonb)`,
          [input.identity.workspaceId, input.identity.userId, JSON.stringify({ projectCommitment: sha256(input.projectId), previewHash: input.previewHash, storageBackend: "POSTGRES_INDEX_PENDING_SAFE_STORAGE", intakePersistence })],
        );
      }
      await client.query("COMMIT");
      return { projectId: input.projectId, title: input.intake.workingTitle, status: "ACTIVE", storageBackend: "POSTGRES_INDEX_PENDING_SAFE_STORAGE", intakePersistence, idempotent: false };
    } catch (error) {
      await client.query("ROLLBACK").catch(() => undefined);
      throw error;
    } finally {
      client.release();
    }
  }
}

export class FixtureProjectRepository implements TenantRepository {
  readonly fixture: TenantFixture;
  constructor(fixture: TenantFixture) { this.fixture = fixture; }
  async list(identity: TenantUser) { return listProjectsForUser(this.fixture, identity); }
  async get(identity: TenantUser, projectId: string) { return canAccessProject(this.fixture, identity, projectId); }
  async canCreate(identity: TenantUser) { return this.fixture.users.some((user) => user.userId === identity.userId && user.workspaceId === identity.workspaceId); }
  async create(input: ProjectCreateInput): Promise<ProjectCreateResult> {
    const prior = this.fixture.projects.find((item) => item.projectId === input.projectId);
    if (prior && (prior.workspaceId !== input.identity.workspaceId || prior.ownerUserId !== input.identity.userId || prior.title !== input.intake.workingTitle)) throw new TenantProjectConflict();
    if (!prior) this.fixture.projects.push({ projectId: input.projectId, workspaceId: input.identity.workspaceId, ownerUserId: input.identity.userId, title: input.intake.workingTitle, status: "ACTIVE", legacy: false });
    return { projectId: input.projectId, title: input.intake.workingTitle, status: "ACTIVE", storageBackend: "POSTGRES_INDEX_PENDING_SAFE_STORAGE", intakePersistence: "PENDING_ARTIFACT_COMMITMENT", idempotent: Boolean(prior) };
  }
}

export class TenantProjectGateway {
  readonly repository: TenantRepository;
  constructor(repository: TenantRepository) { this.repository = repository; }
  list(identity: TenantUser) { return this.repository.list(identity); }
  get(identity: TenantUser, projectId: string) { return this.repository.get(identity, projectId); }
  create(input: ProjectCreateInput) { return this.repository.create(input); }
  async assertCanCreate(identity: TenantUser) { if (!(await this.repository.canCreate(identity))) throw new TenantStorageUnavailable(); }
}

export async function resolveTenantUser(userId: string): Promise<TenantUser | null> {
  if (!pool || !authConfiguration().ready) throw new TenantStorageUnavailable();
  const result = await pool.query<{ workspaceId: string; role: "owner" | "member" }>("SELECT workspace_id AS \"workspaceId\", role FROM workspace_members WHERE user_id = $1 ORDER BY created_at ASC LIMIT 1", [userId]);
  const membership = result.rows[0];
  return membership ? { userId, workspaceId: membership.workspaceId, role: membership.role } : null;
}

export async function closeTenantRepositoryForDisposableTest() {
  if (process.env.INTEGRATION_DATABASE_DISPOSABLE !== "1" || process.env.INTEGRATION_TEST_MODE !== "1" || process.env.TEST_FIXTURE !== "1") throw new TenantStorageUnavailable();
  await pool?.end();
}

export const tenantProjectRepository = new PostgresProjectRepository();
