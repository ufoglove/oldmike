-- Old Mike V2 production AI foundation, migration 0008 verification proposal.
-- NOT EXECUTED by M1A. Run only against an authorized disposable/staging DB.
-- Every query below is fail-on-any-row unless the comment states an exact count.

BEGIN READ ONLY;
SET LOCAL statement_timeout = '15s';
SET LOCAL lock_timeout = '2s';

-- Frozen baseline migration identities. Package validation independently hashes these
-- physical files before any executable 0008 may be approved.
WITH expected(path, sha256) AS (VALUES
  ('migrations/0001_better_auth_core.up.sql','87a62b7b42094e8a41ecd1ddb050ffb3582cb87550a0bf374c314e50334ac768'),
  ('migrations/0002_old_mike_tenant.up.sql','781be7081ea1be0a319496d0fd4f82fbe57fdaa42a9f663504f810eb31f01597'),
  ('migrations/0003_registration_invites.up.sql','dbf7a7af07c1d071cd325cc410600dfc6ef20f682aa2cc384df4072ef7e3cbb0'),
  ('migrations/0004_registration_invite_revocation.up.sql','db6d91c3c04b27c6131feaea7c144780d87e7c9e1123323a08062bcfd108ae64'),
  ('migrations/0005_research_workflow_phase2.up.sql','34d1c22c0965cbe4d8f3241b80a935a6981d7fe51ee1a275bab171889fa3e1d7'),
  ('migrations/0006_admin_provisioned_accounts.up.sql','8ba2a874c5b3df87227303f36799fbb1429d51fe112d1013b1824fee5f7826aa'),
  ('migrations/0007_topic_lab_frontier_radar.up.sql','8dce3d2ef516be42e676c4643a14c253de167469e80f7e86cdf8d20f7f80d815')
)
SELECT 'baseline_migration_literal_invalid', path, sha256
FROM expected
WHERE sha256 !~ '^[0-9a-f]{64}$'
   OR (SELECT count(*) FROM expected) <> 7
   OR (SELECT count(DISTINCT path) FROM expected) <> 7;

-- Exact real 0001..0007 table set required by the additive proposal. These are the
-- physical names in the frozen migrations; nonexistent aliases are forbidden.
WITH required(name) AS (VALUES
  ('account'), ('account_admin_events'), ('account_provisioning_state'), ('audit_events'),
  ('portal_administrator'), ('portal_rate_limits'), ('project_artifacts'), ('projects'),
  ('rateLimit'), ('registration_invites'), ('research_analysis_plans'),
  ('research_analysis_runs'), ('research_claim_evidence'), ('research_claims'),
  ('research_datasets'), ('research_documents'), ('research_evidence_sources'),
  ('research_human_gates'), ('research_studies'), ('research_topic_lab_promotions'),
  ('research_topic_lab_runs'), ('research_workflow_events'), ('session'), ('user'),
  ('user_consents'), ('verification'), ('workspace_members'), ('workspaces')
)
SELECT 'baseline_table_missing', required.name
FROM required
WHERE to_regclass('public.' || quote_ident(required.name)) IS NULL;

-- Exact final 0008 table set: missing and extra production_* base tables both fail.
WITH expected(name) AS (VALUES
  ('production_ai_authority_registry'),
  ('production_ai_budget_reservations'),
  ('production_ai_inbox'),
  ('production_ai_jobs'),
  ('production_ai_outbox'),
  ('production_ai_provider_attempts'),
  ('production_ai_provider_lookup_receipts'),
  ('production_ai_provider_receipts'),
  ('production_ai_reconciliation_human_authorities'),
  ('production_ai_reconciliation_observations'),
  ('production_ai_registry_status_events'),
  ('production_ai_usage_ledger'),
  ('production_ai_webhook_inbox'),
  ('production_citation_authorities'),
  ('production_evidence_authorities'),
  ('production_formal_effect_authorities'),
  ('production_human_gate_authorities'),
  ('production_operation_intents'),
  ('production_project_events'),
  ('production_project_snapshots'),
  ('production_source_bundle_members'),
  ('production_source_bundles'),
  ('production_source_objects')
), actual(name) AS (
  SELECT c.relname
  FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace
  WHERE n.nspname = 'public' AND c.relkind IN ('r','p') AND c.relname LIKE 'production_%'
)
SELECT 'table_missing', expected.name FROM expected LEFT JOIN actual USING (name) WHERE actual.name IS NULL
UNION ALL
SELECT 'table_extra', actual.name FROM actual LEFT JOIN expected USING (name) WHERE expected.name IS NULL;

-- Exact sanitized view set. No observer view may expose raw payload or provider bodies.
WITH expected(name) AS (VALUES
  ('production_observer_job_metrics'),
  ('production_observer_queue_metrics'),
  ('production_observer_usage_metrics')
), actual(name) AS (
  SELECT c.relname
  FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace
  WHERE n.nspname = 'public' AND c.relkind IN ('v','m') AND c.relname LIKE 'production_%'
)
SELECT 'view_missing', expected.name FROM expected LEFT JOIN actual USING (name) WHERE actual.name IS NULL
UNION ALL
SELECT 'view_extra', actual.name FROM actual LEFT JOIN expected USING (name) WHERE expected.name IS NULL;

-- Exact guard-function set in the private schema. Capability bodies are intentionally
-- withheld by M1A; if any appears before the later implementation review, fail closed.
WITH expected(name) AS (VALUES
  ('guard_ai_job_transition'),
  ('guard_formal_effect_transition'),
  ('guard_human_gate_transition'),
  ('guard_operation_intent_transition'),
  ('guard_outbox_transition'),
  ('guard_provider_attempt_transition'),
  ('guard_provider_receipt_insert'),
  ('guard_registry_status_event_insert'),
  ('guard_webhook_inbox_transition'),
  ('reject_append_only_mutation')
), actual(name) AS (
  SELECT p.proname
  FROM pg_proc p JOIN pg_namespace n ON n.oid = p.pronamespace
  WHERE n.nspname = 'old_mike_production_private'
), classified(name) AS (
  SELECT name FROM expected
)
SELECT 'function_missing', expected.name FROM expected LEFT JOIN actual USING (name) WHERE actual.name IS NULL
UNION ALL
SELECT 'function_extra_or_unreviewed_capability', actual.name
FROM actual LEFT JOIN classified USING (name) WHERE classified.name IS NULL;

-- Exact trigger set; each proposal trigger is classified once and extra custom triggers fail.
WITH expected(table_name, trigger_name) AS (VALUES
  ('production_ai_authority_registry','production_authority_registry_append_only'),
  ('production_ai_jobs','production_ai_jobs_transition_guard'),
  ('production_ai_outbox','production_outbox_transition_guard'),
  ('production_ai_provider_attempts','production_provider_attempts_transition_guard'),
  ('production_ai_provider_lookup_receipts','production_provider_lookup_receipts_append_only'),
  ('production_ai_provider_receipts','production_provider_receipt_insert_guard'),
  ('production_ai_provider_receipts','production_provider_receipts_append_only'),
  ('production_ai_reconciliation_human_authorities','production_reconciliation_human_authorities_append_only'),
  ('production_ai_reconciliation_observations','production_reconciliation_observations_append_only'),
  ('production_ai_registry_status_events','production_registry_status_event_insert_guard'),
  ('production_ai_registry_status_events','production_registry_status_events_append_only'),
  ('production_ai_usage_ledger','production_usage_ledger_append_only'),
  ('production_ai_webhook_inbox','production_webhook_inbox_transition_guard'),
  ('production_citation_authorities','production_citations_append_only'),
  ('production_evidence_authorities','production_evidence_append_only'),
  ('production_formal_effect_authorities','production_formal_effect_transition_guard'),
  ('production_human_gate_authorities','production_human_gate_transition_guard'),
  ('production_operation_intents','production_operation_intents_transition_guard'),
  ('production_project_events','production_project_events_append_only'),
  ('production_project_snapshots','production_project_snapshots_append_only'),
  ('production_source_bundle_members','production_source_bundle_members_append_only'),
  ('production_source_bundles','production_source_bundles_append_only'),
  ('production_source_objects','production_source_objects_append_only')
), actual(table_name, trigger_name) AS (
  SELECT c.relname, t.tgname
  FROM pg_trigger t JOIN pg_class c ON c.oid = t.tgrelid
  JOIN pg_namespace n ON n.oid = c.relnamespace
  WHERE NOT t.tgisinternal AND n.nspname = 'public'
    AND c.relname LIKE 'production_%'
)
SELECT 'trigger_missing', expected.table_name || '.' || expected.trigger_name
FROM expected LEFT JOIN actual USING (table_name, trigger_name) WHERE actual.trigger_name IS NULL
UNION ALL
SELECT 'trigger_extra', actual.table_name || '.' || actual.trigger_name
FROM actual LEFT JOIN expected USING (table_name, trigger_name) WHERE expected.trigger_name IS NULL
UNION ALL
SELECT 'trigger_manifest_duplicate', table_name || '.' || trigger_name
FROM expected GROUP BY table_name, trigger_name HAVING count(*) <> 1;

-- Every new table/view and every private function has the exact NOLOGIN owner.
SELECT 'relation_owner_invalid', n.nspname || '.' || c.relname, owner.rolname
FROM pg_class c
JOIN pg_namespace n ON n.oid = c.relnamespace
JOIN pg_roles owner ON owner.oid = c.relowner
WHERE ((n.nspname = 'public' AND c.relname LIKE 'production_%' AND c.relkind IN ('r','p','v','m','i'))
    OR n.nspname = 'old_mike_production_private')
  AND owner.rolname <> 'old_mike_prod_owner';

SELECT 'function_owner_or_security_invalid', p.proname
FROM pg_proc p
JOIN pg_namespace n ON n.oid = p.pronamespace
JOIN pg_roles owner ON owner.oid = p.proowner
WHERE n.nspname = 'old_mike_production_private'
  AND (owner.rolname <> 'old_mike_prod_owner' OR NOT p.prosecdef
    OR p.proconfig IS DISTINCT FROM ARRAY['search_path=pg_catalog, public, old_mike_production_private']::text[]);

-- Exact preprovisioned role attributes and the sole allowed membership edge.
WITH expected(rolname, can_login) AS (VALUES
  ('old_mike_prod_migrator', true),
  ('old_mike_prod_owner', false),
  ('old_mike_prod_web', true),
  ('old_mike_prod_worker', true),
  ('old_mike_prod_relay', true),
  ('old_mike_prod_observer', true)
)
SELECT 'role_missing_or_unsafe', expected.rolname
FROM expected LEFT JOIN pg_roles role USING (rolname)
WHERE role.rolname IS NULL OR role.rolsuper OR role.rolinherit OR role.rolcreaterole
   OR role.rolcreatedb OR role.rolreplication OR role.rolbypassrls
   OR role.rolcanlogin IS DISTINCT FROM expected.can_login;

SELECT 'role_membership_extra', granted_role.rolname || '<-' || member_role.rolname
FROM pg_auth_members membership
JOIN pg_roles granted_role ON granted_role.oid = membership.roleid
JOIN pg_roles member_role ON member_role.oid = membership.member
WHERE (granted_role.rolname LIKE 'old_mike_prod_%' OR member_role.rolname LIKE 'old_mike_prod_%')
  AND NOT (granted_role.rolname = 'old_mike_prod_owner'
    AND member_role.rolname = 'old_mike_prod_migrator' AND NOT membership.admin_option);

SELECT 'schema_owner_invalid'
WHERE (SELECT owner.rolname FROM pg_namespace n JOIN pg_roles owner ON owner.oid=n.nspowner
       WHERE n.nspname='old_mike_production_private') IS DISTINCT FROM 'old_mike_prod_owner';

SELECT 'unsafe_schema_create_privilege', role_name
FROM (VALUES ('old_mike_prod_web'),('old_mike_prod_worker'),
  ('old_mike_prod_relay'),('old_mike_prod_observer')) role(role_name)
WHERE has_schema_privilege(role_name, 'public', 'CREATE');

SELECT 'public_schema_create_privilege'
FROM pg_namespace n
CROSS JOIN LATERAL aclexplode(COALESCE(n.nspacl, acldefault('n',n.nspowner))) acl
WHERE n.nspname='public' AND acl.grantee=0 AND acl.privilege_type='CREATE';

-- Every project-scoped table has workspace/project columns and a composite project FK.
WITH scoped(name) AS (VALUES
  ('production_project_snapshots'), ('production_project_events'), ('production_operation_intents'),
  ('production_source_objects'), ('production_source_bundles'), ('production_source_bundle_members'),
  ('production_ai_jobs'), ('production_ai_outbox'), ('production_ai_inbox'),
  ('production_ai_provider_attempts'), ('production_ai_provider_receipts'),
  ('production_ai_provider_lookup_receipts'), ('production_ai_reconciliation_human_authorities'),
  ('production_ai_reconciliation_observations'), ('production_ai_budget_reservations'),
  ('production_ai_usage_ledger'), ('production_evidence_authorities'),
  ('production_citation_authorities'), ('production_human_gate_authorities'),
  ('production_formal_effect_authorities')
)
SELECT 'project_scope_or_fk_missing', scoped.name
FROM scoped
WHERE NOT EXISTS (SELECT 1 FROM information_schema.columns c
  WHERE c.table_schema='public' AND c.table_name=scoped.name AND c.column_name='workspace_id')
   OR NOT EXISTS (SELECT 1 FROM information_schema.columns c
  WHERE c.table_schema='public' AND c.table_name=scoped.name AND c.column_name='project_id')
   OR NOT EXISTS (
     SELECT 1 FROM pg_constraint con JOIN pg_class child ON child.oid=con.conrelid
     JOIN pg_namespace n ON n.oid=child.relnamespace JOIN pg_class parent ON parent.oid=con.confrelid
     WHERE n.nspname='public' AND child.relname=scoped.name AND con.contype='f'
       AND parent.relname='projects' AND array_length(con.conkey,1)=2 AND array_length(con.confkey,1)=2
   );

-- Application roles have no raw production-table authority; observer gets only three
-- exact sanitized views. PUBLIC and future default privileges remain denied. The
-- migration evidence also snapshots and compares 0001..0007 ACLs before/after: the
-- only permitted delta is owner SELECT/REFERENCES on projects and workspace_members,
-- so Better Auth and every other tenant/research privilege remain unchanged.
SELECT 'raw_application_table_privilege', role_name || ':' || table_name || ':' || privilege
FROM (VALUES ('old_mike_prod_web'),('old_mike_prod_worker'),('old_mike_prod_relay'),('old_mike_prod_observer')) r(role_name)
CROSS JOIN LATERAL (
  SELECT c.oid, c.relname FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace
  WHERE n.nspname='public' AND c.relkind IN ('r','p') AND c.relname LIKE 'production_%'
) t(table_oid, table_name)
CROSS JOIN (VALUES ('SELECT'),('INSERT'),('UPDATE'),('DELETE'),('TRUNCATE'),('REFERENCES'),('TRIGGER')) p(privilege)
WHERE has_table_privilege(role_name, table_oid, privilege);

WITH expected(name) AS (VALUES
  ('production_observer_job_metrics'),
  ('production_observer_queue_metrics'),
  ('production_observer_usage_metrics')
), actual(name) AS (
  SELECT table_name FROM information_schema.role_table_grants
  WHERE grantee='old_mike_prod_observer' AND privilege_type='SELECT'
)
SELECT 'observer_view_missing', expected.name FROM expected LEFT JOIN actual USING(name) WHERE actual.name IS NULL
UNION ALL
SELECT 'observer_relation_extra', actual.name FROM actual LEFT JOIN expected USING(name) WHERE expected.name IS NULL;

SELECT 'public_relation_acl', c.relname, a.privilege_type
FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace
CROSS JOIN LATERAL aclexplode(COALESCE(c.relacl, acldefault('r',c.relowner))) a
WHERE n.nspname='public' AND c.relname LIKE 'production_%' AND a.grantee=0;

SELECT 'public_function_execute', routine_name
FROM information_schema.role_routine_grants
WHERE routine_schema='old_mike_production_private' AND grantee='PUBLIC';

SELECT 'baseline_owner_parent_privilege_missing_or_excess', table_name, privilege
FROM (VALUES ('projects'),('workspace_members')) parent(table_name)
CROSS JOIN (VALUES ('SELECT'),('REFERENCES')) expected(privilege)
WHERE NOT has_table_privilege('old_mike_prod_owner', 'public.' || parent.table_name, expected.privilege)
UNION ALL
SELECT 'baseline_owner_parent_dml_forbidden', table_name, privilege
FROM (VALUES ('projects'),('workspace_members')) parent(table_name)
CROSS JOIN (VALUES ('INSERT'),('UPDATE'),('DELETE'),('TRUNCATE'),('TRIGGER')) forbidden(privilege)
WHERE has_table_privilege('old_mike_prod_owner', 'public.' || parent.table_name, forbidden.privilege);

SELECT 'unsafe_default_acl', defaclrole::regrole, defaclnamespace::regnamespace, defaclobjtype
FROM pg_default_acl
WHERE defaclrole='old_mike_prod_owner'::regrole
  AND EXISTS (SELECT 1 FROM aclexplode(defaclacl) a
    WHERE a.grantee=0 OR a.grantee IN ('old_mike_prod_web'::regrole,
      'old_mike_prod_worker'::regrole, 'old_mike_prod_relay'::regrole,
      'old_mike_prod_observer'::regrole));

-- Required relational authorities and exact typed invariants.
SELECT 'operation_job_composite_fk_missing'
WHERE NOT EXISTS (
  SELECT 1 FROM pg_constraint con JOIN pg_class c ON c.oid=con.conrelid
  JOIN pg_class parent ON parent.oid=con.confrelid
  WHERE c.relname='production_ai_jobs' AND parent.relname='production_operation_intents'
    AND con.contype='f' AND array_length(con.conkey,1)=9
)
UNION ALL SELECT 'operation_event_composite_fk_missing'
WHERE NOT EXISTS (
  SELECT 1 FROM pg_constraint con JOIN pg_class c ON c.oid=con.conrelid
  JOIN pg_class parent ON parent.oid=con.confrelid
  WHERE c.relname='production_project_events' AND parent.relname='production_operation_intents'
    AND con.contype='f' AND array_length(con.conkey,1)=9
)
UNION ALL SELECT 'source_bundle_job_fk_missing'
WHERE NOT EXISTS (
  SELECT 1 FROM pg_constraint con JOIN pg_class c ON c.oid=con.conrelid
  JOIN pg_class parent ON parent.oid=con.confrelid
  WHERE c.relname='production_ai_jobs' AND parent.relname='production_source_bundles'
    AND con.contype='f' AND array_length(con.conkey,1)=5
)
UNION ALL SELECT 'attempt_receipt_exact_fk_missing'
WHERE NOT EXISTS (
  SELECT 1 FROM pg_constraint con JOIN pg_class c ON c.oid=con.conrelid
  JOIN pg_class parent ON parent.oid=con.confrelid
  WHERE c.relname='production_ai_provider_receipts' AND parent.relname='production_ai_provider_attempts'
    AND con.contype='f' AND array_length(con.conkey,1)=8
)
UNION ALL SELECT 'attempt_reconciliation_exact_fk_missing'
WHERE NOT EXISTS (
  SELECT 1 FROM pg_constraint con JOIN pg_class c ON c.oid=con.conrelid
  JOIN pg_class parent ON parent.oid=con.confrelid
  WHERE c.relname='production_ai_reconciliation_observations' AND parent.relname='production_ai_provider_attempts'
    AND con.contype='f' AND array_length(con.conkey,1)=8
)
UNION ALL SELECT 'attempt_usage_exact_fk_missing'
WHERE NOT EXISTS (
  SELECT 1 FROM pg_constraint con JOIN pg_class c ON c.oid=con.conrelid
  JOIN pg_class parent ON parent.oid=con.confrelid
  WHERE c.relname='production_ai_usage_ledger' AND parent.relname='production_ai_provider_attempts'
    AND con.contype='f' AND array_length(con.conkey,1)=8
)
UNION ALL SELECT 'formal_outbox_exact_fk_missing'
WHERE NOT EXISTS (
  SELECT 1 FROM pg_constraint con JOIN pg_class c ON c.oid=con.conrelid
  JOIN pg_class parent ON parent.oid=con.confrelid
  WHERE c.relname='production_ai_outbox' AND parent.relname='production_formal_effect_authorities'
    AND con.contype='f' AND array_length(con.conkey,1)=5
)
UNION ALL SELECT 'registry_job_full_tuple_fk_count_invalid'
WHERE (SELECT count(*) FROM pg_constraint con JOIN pg_class c ON c.oid=con.conrelid
  JOIN pg_class parent ON parent.oid=con.confrelid
  WHERE c.relname='production_ai_jobs' AND parent.relname='production_ai_authority_registry'
    AND con.contype='f' AND array_length(con.conkey,1)=5) <> 7;

-- Reconciliation evidence is method-discriminated and recoverable. Each observation
-- binds exactly one typed authority, and a durable webhook inbox row binds back to the
-- exact observation applied in the same terminalizing transaction.
SELECT 'reconciliation_lookup_fk_missing'
WHERE NOT EXISTS (
  SELECT 1 FROM pg_constraint con JOIN pg_class c ON c.oid=con.conrelid
  JOIN pg_class parent ON parent.oid=con.confrelid
  WHERE c.relname='production_ai_reconciliation_observations'
    AND parent.relname='production_ai_provider_lookup_receipts'
    AND con.contype='f' AND array_length(con.conkey,1)=7
)
UNION ALL SELECT 'reconciliation_human_fk_missing'
WHERE NOT EXISTS (
  SELECT 1 FROM pg_constraint con JOIN pg_class c ON c.oid=con.conrelid
  JOIN pg_class parent ON parent.oid=con.confrelid
  WHERE c.relname='production_ai_reconciliation_observations'
    AND parent.relname='production_ai_reconciliation_human_authorities'
    AND con.contype='f' AND array_length(con.conkey,1)=6
)
UNION ALL SELECT 'reconciliation_webhook_fk_missing'
WHERE NOT EXISTS (
  SELECT 1 FROM pg_constraint con JOIN pg_class c ON c.oid=con.conrelid
  JOIN pg_class parent ON parent.oid=con.confrelid
  WHERE c.relname='production_ai_reconciliation_observations'
    AND parent.relname='production_ai_webhook_inbox'
    AND con.contype='f' AND array_length(con.conkey,1)=5
)
UNION ALL SELECT 'webhook_applied_observation_fk_missing'
WHERE NOT EXISTS (
  SELECT 1 FROM pg_constraint con JOIN pg_class c ON c.oid=con.conrelid
  JOIN pg_class parent ON parent.oid=con.confrelid
  WHERE c.relname='production_ai_webhook_inbox'
    AND parent.relname='production_ai_reconciliation_observations'
    AND con.contype='f' AND array_length(con.conkey,1)=7
)
UNION ALL SELECT 'webhook_body_object_authority_column_missing'
WHERE (SELECT count(*) FROM information_schema.columns
  WHERE table_schema='public' AND table_name='production_ai_webhook_inbox'
    AND column_name IN ('raw_body_storage_class','raw_body_object_id',
      'raw_body_object_key_hash','raw_body_object_version_id',
      'raw_body_storage_receipt_hash')) <> 5
UNION ALL SELECT 'human_reconciliation_authorization_column_missing'
WHERE (SELECT count(*) FROM information_schema.columns
  WHERE table_schema='public' AND table_name='production_ai_reconciliation_human_authorities'
    AND column_name IN ('membership_authority_hash','authorization_scope_hash',
      'authorization_policy_hash','decision_hash','decided_by_user_id','decided_at')) <> 6;

-- Registry lifecycle is exact: immutable content includes EVAL review_class, the
-- approval event is sequence 1, retirement is the sole sequence-2 successor, and both
-- directions of the deferred approval binding plus the predecessor chain are present.
SELECT 'eval_review_class_column_missing'
WHERE NOT EXISTS (SELECT 1 FROM information_schema.columns
  WHERE table_schema='public' AND table_name='production_ai_authority_registry'
    AND column_name='review_class')
UNION ALL SELECT 'registry_content_to_approval_event_fk_missing'
WHERE NOT EXISTS (
  SELECT 1 FROM pg_constraint con JOIN pg_class c ON c.oid=con.conrelid
  JOIN pg_class parent ON parent.oid=con.confrelid
  WHERE c.relname='production_ai_authority_registry'
    AND parent.relname='production_ai_registry_status_events'
    AND con.contype='f' AND array_length(con.conkey,1)=4
)
UNION ALL SELECT 'registry_event_to_content_fk_missing'
WHERE NOT EXISTS (
  SELECT 1 FROM pg_constraint con JOIN pg_class c ON c.oid=con.conrelid
  JOIN pg_class parent ON parent.oid=con.confrelid
  WHERE c.relname='production_ai_registry_status_events'
    AND parent.relname='production_ai_authority_registry'
    AND con.contype='f' AND array_length(con.conkey,1)=4
)
UNION ALL SELECT 'registry_predecessor_fk_missing'
WHERE NOT EXISTS (
  SELECT 1 FROM pg_constraint con JOIN pg_class c ON c.oid=con.conrelid
  WHERE c.relname='production_ai_registry_status_events' AND con.confrelid=con.conrelid
    AND con.contype='f' AND array_length(con.conkey,1)=4
);

-- Guard definitions must retain null-safe immutable tuples and terminal state names.
SELECT 'guard_definition_incomplete', p.proname
FROM pg_proc p JOIN pg_namespace n ON n.oid=p.pronamespace
WHERE n.nspname='old_mike_production_private'
  AND p.proname IN ('guard_ai_job_transition','guard_operation_intent_transition',
    'guard_provider_attempt_transition','guard_human_gate_transition','guard_formal_effect_transition')
  AND (pg_get_functiondef(p.oid) NOT LIKE '%IS DISTINCT FROM%'
    OR pg_get_functiondef(p.oid) NOT LIKE '%RAISE EXCEPTION%');

SELECT 'job_guard_registry_or_terminal_binding_incomplete'
WHERE NOT EXISTS (
  SELECT 1 FROM pg_proc p JOIN pg_namespace n ON n.oid=p.pronamespace
  WHERE n.nspname='old_mike_production_private' AND p.proname='guard_ai_job_transition'
    AND pg_get_functiondef(p.oid) LIKE '%prompt_approval_event_hash%'
    AND pg_get_functiondef(p.oid) LIKE '%FAILED_PROVEN_NOT_SUBMITTED%'
    AND pg_get_functiondef(p.oid) LIKE '%production_ai_job_terminal_attempt_or_receipt_invalid%'
);

SELECT 'registry_chain_guard_incomplete'
WHERE NOT EXISTS (
  SELECT 1 FROM pg_proc p JOIN pg_namespace n ON n.oid=p.pronamespace
  WHERE n.nspname='old_mike_production_private' AND p.proname='guard_registry_status_event_insert'
    AND pg_get_functiondef(p.oid) LIKE '%sequence = 1%'
    AND pg_get_functiondef(p.oid) LIKE '%sequence = 2%'
    AND pg_get_functiondef(p.oid) LIKE '%RETIRED%'
);

-- Package-level self-consistency gate (run without executing SQL): parse this proposal's
-- CREATE TABLE/VIEW/FUNCTION/TRIGGER names, compare them byte-for-byte with the four
-- expected sets above, require each exactly once, and reject missing/extra/duplicate names.
-- The M1A result must bind that zero-difference observation. This complements catalog
-- checks and prevents the verifier manifest itself from silently drifting.

-- The executable M1 verifier must additionally prove: exact 0001..0008 ledger/digests;
-- all frozen capability signatures/bodies/owners/proconfig/ACLs; canonical hash parity;
-- lock/CAS order; operation replay/conflict; source bundles; registry approve/retire;
-- outbox/inbox lease crashes and exact encrypted webhook-body reopen; provider receipt kinds;
-- webhook/lookup/human discrimination and active-member decision authorization;
-- Human Gate/formal-effect concurrent terminal CAS; N-1 compatibility; backfill/restore;
-- and raw-DML, role-membership, search_path, cross-tenant and coordinated-hash attacks.

ROLLBACK;
