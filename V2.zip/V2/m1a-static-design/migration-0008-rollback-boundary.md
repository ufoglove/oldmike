# Migration 0008 rollback and compatibility boundary

Status: proposal only; migration was not executed.

## Additive rule

0008 follows fixed migrations 0001–0007. It may add tables, indexes, constraints, triggers, routines, roles/grants, and nullable/compatible references. It may not rename, drop, reinterpret, or overwrite existing tables/functions/data. Application startup and request paths never run migrations.

The M1A SQL is an architectural proposal, not an executable migration: it intentionally withholds application capability grants until the exact `SECURITY DEFINER` bodies are implemented, threat-reviewed, and verified. The eventual production migration must be copied into the normal migration directory, pinned in the migration manifest, reviewed, and proven on empty, N-1, restored, and representative synthetic databases before any staging/production authorization. A static parser and catalog readback must agree on the exact real 0001–0007 baseline and every final 0008 table/view/function/trigger/owner/ACL; aliases, missing objects, or extras block execution.

## N-1 compatibility

- The old image ignores all `production_*` objects and continues using its existing schema contract during expand/canary/rollback.
- New code must tolerate no production rows before cutover and must not require destructive changes to 0001–0007.
- During the rollback window, new writes use additive authorities whose existence does not break the old image. If the old image cannot safely coexist with a new truth-advancing write, cutover remains single-writer and rollback becomes read-only until reconciliation.
- Schema contract and task definition are versioned independently. A previous OCI digest is rollback-eligible only when its allowed migration range includes the observed head.

## Backfill authority

Backfill is a bounded, resumable command with tenant/project key ranges, source query/version, target authority version, batch size, checkpoint, row/object counts, aggregate hashes, start/end times, and sanitized outcome. It does not invoke providers, create evidence/citations, confirm Human Gates, or authorize formal effects. Each batch is idempotent and reconciled before the next. Any missing/extra/mismatched row or object blocks cutover.

## No destructive down

There is no automatic `0008.down.sql`. Application rollback keeps 0008 in place. Dropping `production_*` objects is a later contract migration requiring proof that:

- no supported application or worker reads/writes them;
- all outbox/inbox/jobs/unknown effects are terminally reconciled;
- retention/export/legal-hold requirements are satisfied;
- an approved backup and isolated restore drill pass;
- row counts and authority hashes are preserved in the approved archive;
- a separate Owner migration/data-destruction approval exists.

Without all proofs, the contract migration fails before any drop.

## Restore boundary

Restore is not down migration. It uses an approved PostgreSQL restore point plus exact S3 object versions and then reconciles migration head, projects, snapshots/events, operation intents, outbox/inbox, jobs/attempts/receipts, unknown effects, budget/usage, evidence/citations, Human Gates, and formal effects. Provider submission fences survive restore; an uncertain effect is never made retryable merely because the restore point predates its acknowledgement.

## Required later evidence

1. Empty up + verify.
2. 0001–0007 N-1 app before and after 0008.
3. Safe migrator/`NOLOGIN` owner plus restricted web/worker/relay/observer role attributes, membership closure, object/routine ownership, default ACL, sanitized-view positive and negative matrix.
4. Concurrent canonical operation/job/typed-outbox/receipt/event/snapshot and no-resend fault matrix, including immutable source bundle, registry approval/retirement, exact attempt provenance, and committed-result replay.
5. Webhook encrypted-body reopen and lease recovery, lookup/webhook/human method-discriminated evidence, and Human Gate/formal-effect terminal CAS matrix.
6. Bounded backfill and exact reconciliation.
7. Backup restore and object-version reconciliation.
8. Exact migration manifest/checksum and production readback.
9. Previous OCI digest compatibility and application rollback rehearsal.
