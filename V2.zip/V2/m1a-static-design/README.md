# V2 Production AI Convergence — M1A Static Design

Status: `PASS_STATIC_DESIGN_ONLY` when the package and its root authorities validate. This package is not executable production authority, Professor UAT evidence, migration approval, or release approval.

## Decision in one paragraph

Preserve the C19 professional experience and the Beta2 tenant, evidence, Human Gate, idempotency, completion-unknown, and no-resend semantics. Move production execution behind a modular Next.js web/BFF, a PostgreSQL command-and-truth layer, an append-only outbox, a durable AI worker, and a separate outbox relay. Build one immutable OCI image and promote only its digest through conventional CI/CD. Provider network I/O belongs only in the worker. PostgreSQL remains business truth; SQS carries identifiers and hashes, never research text; versioned S3 objects hold large source bytes. The current A3 action-specific acceptance launcher is retained as historical local evidence but is retired from future release authority.

## Package map

1. `architecture-decision.md` — decision, invariants, M1/M2 split, and consequences.
2. `module-map.json` — observed current modules and exact proposed ownership paths.
3. `migration-0008.proposal.sql` — additive, unexecuted database proposal.
4. `migration-0008.verify.sql` — exact verification queries for a later disposable/staging run.
5. `migration-0008-rollback-boundary.md` — expand/contract, N-1, and data-recovery boundary.
6. `ai-execution-and-governance.json` — AI job state machine, provider contract, evidence, privacy, budget, and evaluation authority.
7. `aws-ap-east-2-preflight.schema.json` — account/region capability evidence schema; every live fact starts `UNKNOWN`.
8. `aws-iac-interfaces.json` — parameterized, non-secret AWS/OpenTofu module interfaces.
9. `security-data-flow-threat-model.md` — data classification, trust boundaries, and controls.
10. `ci-cd-and-acceptance.md` — conventional build/test/promote evidence and independent Professor UAT boundary.
11. `cutover-rollback-slo.md` — migration/canary/rollback skeleton and unproven SLO targets.
12. `acceptance-matrix.json` — M1/M2 requirements, authoritative evidence, and stop rules.
13. `owner-decisions-cost-residency.json` — paid-service, retention, residency, and account decisions requiring approval.

The package also freezes the reviewed relational closure: exact real 0001–0007 baseline objects, exact 0008 object-set synchronization, canonical operation/result authority, ordered source bundles, immutable seven-kind AI registries, typed outbox ownership, exact provider-attempt/receipt provenance, recoverable encrypted webhook inbox processing, method-discriminated reconciliation, and monotonic Human Gate/formal-effect terminals. These are implementation requirements, not claims that SQL or infrastructure has run.

The root `V2_PRODUCTION_AI_M1A_STATIC_ARCHITECTURE.json` is the machine-readable authority over the frozen package. The root `V2_PRODUCTION_AI_M1A_STATIC_READINESS_RESULT.json` is written last and binds the architecture authority without self-reference.

## Holds

- M0 remains fail-closed because the current Zeabur control-plane and production database metadata snapshot is missing.
- `FULL_OR_EXECUTABLE_M1=HOLD` pending a separate Brain/Owner decision and the M0_C1 interactive-access authority.
- AWS account capability, production database head, rollback control-plane recoverability, provider access, RPO/RTO, and Professor acceptance are all unproven.
- No cloud connection, database connection, provider call, product test, migration, deployment, or UAT is performed by M1A.
