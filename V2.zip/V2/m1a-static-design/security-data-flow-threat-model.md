# Security, data-flow, and threat model

Status: static proposal. No live account, provider, database, or research data was accessed.

## Trust boundaries

1. Browser to regional ALB/web BFF: untrusted network input. Better Auth session, CSRF/same-origin policy, exact project ID, active membership, request size, content type, contract version, idempotency key, request ID, base revision, and canonical request hash are validated before any command.
2. Web BFF to PostgreSQL: mutually authenticated private traffic. The web role has no raw truth-table DML; bounded `SECURITY DEFINER` routines validate tenant/project/actor authority and atomically append the canonical operation intent, a `QUEUED` job, and one typed pending outbox row.
3. Outbox relay to SQS FIFO: messages contain only workspace/project/job/formal-effect/object identifiers, versions, hashes, attempt count, and trace ID. The relay leases and publishes but never transitions job business state. Research text, object bytes, prompts, provider bodies, credentials, and user profile data are forbidden.
4. Worker to PostgreSQL/S3: a worker role leases one exact job, reads only its tenant/project-bound object versions, and commits provider attempt/receipt/result through controlled routines.
5. Worker to provider: egress is disabled by default and restricted to capability-approved hostnames and ports. The provider receives only the policy-approved minimum source projection. The provider is not trusted to create host IDs, evidence, citations, Human Gate state, or formal effects.
6. Provider webhook to webhook ingress: untrusted public input. Require bounded raw bytes, TLS, timestamp window, signature/version/key ID, exact provider, event ID, receipt/request binding, and durable deduplication. Before inbox commit, the bounded body is written to a versioned encrypted object and read back; the inbox freezes its byte length/hash, opaque object ID, object-key hash, object version, and storage-receipt hash. The inbox insert commits before response; a database-time lease/recovery worker reopens that exact object and turns the exact `VALID` inbox tuple into an observation plus `APPLIED` transition atomically, so a crash does not rely on sender retry.
7. CI to AWS: short-lived OIDC identity bound to repository and protected environment. Plan, staging promotion, and production promotion have distinct roles. No static access key is allowed.
8. Operators/Professor to product: Professor UAT judges professional usefulness; it does not grant cloud, migration, data-transfer, budget, or release authority. Operators use audited, least-privilege, time-bounded roles.

## Data classes and locations

| Class | Examples | Authoritative store | Queue/log policy |
|---|---|---|---|
| Public | static assets, public release identity | OCI/S3 public-static | hashes and release metadata allowed |
| Account | user ID, workspace membership | PostgreSQL | identifiers only; no email in ordinary application events |
| Research restricted | raw material, manuscript fragments, provider prompts/results | versioned SSE-KMS S3 plus relational object authority | never in queue or ordinary logs |
| Research authority | snapshot, evidence/citation bindings, Human Gate, formal-effect decision | PostgreSQL append-only/CAS truth | IDs, hashes, state allowed |
| Secrets | DB/provider credentials, signing keys | Secrets Manager/KMS | never logged, serialized, hashed into public evidence, or stored in source |
| Operational | traces, durations, counts, sanitized codes | telemetry/log archive | no research text or provider body |

## Source-object flow

1. Web validates declared byte length, media type, tenant/project, and upload authorization.
2. Upload uses a short-lived, object-key-constrained mechanism. Object key is host-derived; clients cannot choose cross-tenant prefixes.
3. Finalize computes or verifies byte length, SHA-256, S3 version ID, KMS key authority, and retention class before recording `production_source_objects`.
4. A job binds an immutable source-bundle `(workspace, project, bundle ID, version, hash)`. Ordered members use contiguous unique ordinals and exact object ID, object-store version, byte length, and content hash; the capability independently recomputes count, bytes, and the canonical bundle hash. Any mismatch or later object/version/hash change creates a new job lineage. Derivatives are distinct objects that bind their original and transformation authority and never replace original bytes.
5. Worker reads exact versions, rechecks bytes and hashes, applies minimum-necessary projection, and never persists source text to ordinary logs.
6. Export/delete/legal-hold workflows operate on both object versions and relational authorities. Deletion is prohibited while an effective legal hold or formal audit retention applies.

## Primary threats and controls

### Tenant or project confusion

- Threat: insecure direct object reference, confused deputy, cross-project object key, or queue message substitution.
- Controls: composite `(workspace_id, project_id)` keys/FKs everywhere; active membership inside each command routine; object prefix and metadata binding; queue payload hash; worker reauthorization against the job's frozen tenant/project; generic 404 at public boundary.

### Duplicate or ambiguous AI effects

- Threat: HTTP retry, queue redelivery, worker crash, provider timeout, regional failover, or operator retry submits twice.
- Controls: one canonical operation tuple shared by intent/job/event; unique effect lineage, request ID, and idempotency key; immutable attempt row before I/O; full attempt-tuple FKs from receipts/lookups/reconciliation/usage; contiguous receipt chain and typed proof shapes; submission count `0|1`; `COMPLETION_UNKNOWN` as a permanent no-resend fence; exact lookup, durable signed-webhook, or separately authorized active-member reconciliation only. Human resolution freezes membership, project scope, policy, actor, decision hash, and decision time. No cross-provider failover follows possible submission.

### Provider output injection or false evidence

- Threat: provider text injects schema, citation, evidence, Human Gate, or formal-write authority.
- Controls: strict exact output schema; shared domain parser; host-generated IDs/hashes; exact source/evidence/citation spans; provider output class `UNTRUSTED_ADVISORY`; independent Human Gate; formal-effect authority separate and default-deny.

### Prompt injection and unsafe source retrieval

- Threat: source material asks the model or worker to access network, secrets, other tenants, or tools.
- Controls: provider adapter has no database/project mutation capability; worker egress allowlist; no generic URL fetch from model output; SSRF-safe URL parser and DNS/IP revalidation for separately approved fetchers; source text is data, not instructions to host tools.

### SSRF and egress bypass

- Threat: user/provider-controlled URL reaches metadata, private networks, or unapproved services.
- Controls: deny private/link-local/loopback/metadata ranges, resolve and pin approved names, TLS and host allowlist, no redirect to new authority, VPC endpoint policies, NAT/egress logs, and no web-task provider egress.

### Webhook replay or forgery

- Threat: duplicate, stale, altered, or cross-job webhook commits truth.
- Controls: verify signature before JSON projection; bounded timestamp skew; exact key version; unique provider event ID and payload hash; exact receipt/request/provider binding; retain only an encrypted versioned body-object authority plus sanitized metadata; database-time lease/replay reopens the exact object; lookup/webhook/human relations have mutually exclusive exact FKs; observation, terminal commit, and inbox `APPLIED` are atomic; duplicate is zero-effect; missing or mismatched authority is blocked.

### Browser and edge attacks

- Threat: XSS, CSRF, clickjacking, cache leakage, request smuggling, or oversized payload.
- Controls: strict CSP with nonces/hashes, no unsafe dynamic script, frame-ancestors deny, same-origin mutation policy, secure cookies, no-store authenticated responses, normalized proxy headers, ALB/WAF size/rate limits, application byte cap, and output encoding.

### Database privilege escalation

- Threat: compromised web/worker role writes arbitrary history, changes hashes, disables RLS, or invokes unsafe definer routine.
- Controls: an exact `old_mike_prod_migrator` creates objects only after `SET LOCAL ROLE old_mike_prod_owner`; the owner is `NOLOGIN`, and no application role is a member. Owner/web/worker/relay/observer role flags, the sole migrator-to-owner membership, schema ownership, function owner/proconfig, ACLs, and default privileges are catalog-verified. Raw truth DML is revoked. The observer receives only three security-barrier metadata/metrics views—never baseline auth/research tables, raw source text, or provider bodies—and future tables are default-deny. Exact routine EXECUTE grants, fixed `search_path`, fully qualified objects, no dynamic SQL, composite authorization, bounded locks/timeouts, append-only chains, terminal CAS, PUBLIC denial, and restore tests remain mandatory.

### Rewritable approval or formal-effect authority

- Threat: a privileged path changes a Human Gate decision, formal-effect payload, approver, hash, timestamp, or terminal state after authorization.
- Controls: Human Gate identity/request hash is immutable and only `PENDING -> CONFIRMED|REJECTED` is legal. Formal effects bind an exact confirmed gate and only `AUTHORIZED -> EXECUTED|REVOKED_BEFORE_EXECUTION` is legal. Terminal rows are immutable; transitions are row-locked compare-and-set operations with exact decision/terminal hashes and actors. A typed formal-effect outbox can reference only the exact `AUTHORIZED` formal-effect tuple, never an unrelated AI job.

#### RLS and `SECURITY DEFINER` review decision

The static 0008 proposal does not claim RLS safety merely by enabling a policy. Its primary write boundary is capability-only: web/worker/relay roles receive no raw table DML and invoke exact fixed-owner routines. Before executable 0008, a dedicated threat review must choose and prove one of these explicit models:

- Capability-only for truth tables: raw SELECT/DML revoked from application roles; every read/write uses a tenant/project-checking routine. RLS is not cited as a control.
- Capability plus defense-in-depth RLS: a non-user-settable authenticated database context is established by a trusted routine; policies bind both workspace and project; table owner/BYPASSRLS behavior is tested; pooled-session context is reset and cross-request leakage is fault-tested.

Client-settable custom GUCs alone are not tenant authority. A mixture of direct table reads, caller-controlled GUCs, owner bypass, or unreviewed `SECURITY DEFINER` functions blocks migration. The review must enumerate each routine's owner, grantee, arguments, tables, lock order, timeout, role assertion, search path, dynamic-SQL absence, row-security behavior, positive cases, and cross-tenant/coordinated-tamper negatives.

### Log and telemetry leakage

- Threat: prompts, provider bodies, credentials, email, or research text enter logs/traces.
- Controls: allowlisted structured fields, redaction at SDK and collector, body capture disabled, sanitized error taxonomy, trace baggage restrictions, canary leak scans, retention and access controls, sampling policy version.

### Supply chain or release substitution

- Threat: dependency, CI, image, manifest, or deployment is changed after tests.
- Controls: protected Git branch, reviewed lockfile, pinned actions, dependency/license/vulnerability policy, reproducible build inputs, OCI digest, SBOM, provenance, signature/attestation, exact-digest staging and production promotion, deployment readback, admission check, rollback digest retention.

## Security headers and public surface

- HSTS after domain/certificate validation; CSP; `X-Content-Type-Options: nosniff`; restrictive `Permissions-Policy`; `Referrer-Policy`; `frame-ancestors 'none'` unless a separately reviewed embedding need exists.
- Authenticated API and HTML use `Cache-Control: no-store`; static immutable assets may be long cached by content hash.
- Public health reveals liveness and release identity only. Readiness is access-controlled or returns a coarse status; it never exposes topology, migration details, provider identity, or secret names.

## Retention, export, deletion, and legal hold

- Retention classes for source objects, prompts, provider requests/results, operational logs, audit events, and backups require Owner/privacy approval before implementation.
- Tenant export must be complete, authenticated, scoped, asynchronous, checksum-bound, and audited.
- Delete is a state machine across PostgreSQL, object versions, provider-retention obligations, backups, and audit/legal hold. It is never a direct cascade from a web request.
- Legal hold overrides routine deletion and Object Lifecycle expiration. Hold authority is explicit, time/version bound, and audited.
- Backup expiry and provider-side deletion are separately observed; neither is inferred from host deletion.

## Static-review residuals

AWS service availability, IAM account structure, keys, region opt-in, production DB role/extension/migration head, provider retention terms, data processing agreements, egress endpoints, and incident contacts remain `UNKNOWN`. Any implementation or release gate that needs them fails closed.
