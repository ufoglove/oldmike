# Migration, cutover, rollback, and operational SLO skeleton

Status: static proposal. No migration, backup, restore, traffic change, or drill was executed. Every numeric objective below is a target for Owner review and remains `UNPROVEN` until measured or drilled.

## Hard prerequisites

- M0_C1 identifies the actual current Zeabur deployment, immutable artifact, traffic, configuration schema, production migration head, database role/HA/backup/PITR metadata, and recoverable rollback path.
- Owner approves AWS account, `ap-east-2`, data residency, retention/legal hold, paid services, provider data processing, budgets, backup, RPO/RTO targets, migration, deployment, cutover, and rollback.
- Capability preflight is complete with no required `UNKNOWN`/`ABSENT` item, and every account-scoped observation byte-binds the same sanitized caller/account authority hash and observation time.
- The exact safe migrator/`NOLOGIN` owner/web/worker/relay/observer role attributes, sole allowed membership, object/function ownership, ACL/default-ACL closure, and sanitized observer views are approved and preprovisioned.
- Exact source commit, OCI digest, SBOM, provenance, signature, migration 0008 digest, config schema, and rollback digest are frozen.

## Phased migration

### Phase 0 — inventory and restore proof

Read-only reconcile current topology and migration head. Verify backup/PITR metadata. Under separate mutation approval, create a non-production restore/clone and prove application-readable integrity without reading unrelated tenant/research content. If restore cannot be proven, stop.

### Phase 1 — expand

Apply additive 0008 under the exact safe migrator role and advisory lock, assuming only the `NOLOGIN` production owner for object creation. Create new tables, indexes, policies, triggers, routines, and grants without altering or dropping 0001–0007 objects. Verify the physical 0001–0007 digest/object baseline, exact 0008 proposal/verifier object-set equality, owners/proconfig, role membership, PUBLIC/default ACLs, sanitized observer views, composite authorities, connection/lock limits, and replication/backup impact. Old application remains compatible.

### Phase 2 — shadow and backfill

Deploy M1 in read/shadow mode with live provider disabled. Backfill only derived authorities required by the reviewed plan, in tenant/project-bounded batches with checkpoints, hashes, counts, and rate limits. Reconcile every source and destination row/object authority, ordered source bundle, operation tuple, and registry version/hash. Never fabricate provider attempts/receipts, approval events, reconciliation evidence, citations, Human Gate decisions, or formal effects. Mismatch stops.

### Phase 3 — dual-read comparison, single-write authority

Keep one authoritative writer. Compare old and new projections using IDs/hashes/sanitized states, not research text in logs. Do not dual-submit provider work. Any divergence in tenant/project, material bytes, revisions, idempotency, unknown state, evidence, or Human Gate blocks cutover.

The public API remains `/api/v2-beta2/projects/[projectId]` throughout M1 cutover and rollback. The route delegates internally by deployment version; old and new clients retain byte-exact request/response/error/status/idempotency semantics. Telemetry may distinguish internal implementation versions without exposing research data. There is no silent rename, compatibility facade, or client-only atomic assumption in M1/M2.

### Phase 4 — canary

Route an Owner-approved synthetic/internal cohort to the exact M1 digest. Live provider remains disabled until separately approved M2. Observe health, auth, database, connection budget, outbox/queue, idempotency, error rate, latency, and data consistency. Start with the minimum traffic supported by ECS-native canary/blue-green and expand only after each soak window passes.

### Phase 5 — production cutover

Freeze incompatible administrative changes, confirm backup/PITR and rollback digest, apply final non-destructive reconciliation, then advance traffic in bounded steps. Record every traffic allocation and task-definition/image digest. Stop on any authority mismatch, data divergence, P0/P1, error-budget breach, unknown provider effect, or inability to roll back application traffic.

### Phase 6 — soak and contract

Maintain N-1 compatibility through the declared soak. Do not drop old columns/tables/functions or expire rollback artifacts during soak. A later, separately approved contract migration may remove obsolete structures only after zero-reader/zero-writer proof, export/retention review, backup/restore drill, and rollback-window expiry. There is no automatic destructive down migration.

## Application rollback versus data recovery

Application rollback redeploys the previously proven OCI digest and shifts traffic back while keeping additive schema 0008. It is permitted only if N-1 compatibility and configuration compatibility are still proven. It must not rewind snapshots/events, resend unknown AI work, or delete new rows.
The rollback digest must still serve the same `/api/v2-beta2` path and understand every response/state that can exist during the rollback window; otherwise traffic rollback is blocked or the service enters an explicitly authorized read-only mode.

Data recovery restores or replays database/object-store authority after corruption or loss. It is not an application rollback. It requires incident command, a chosen restore point, write fencing, object/version reconciliation, outbox/inbox replay analysis, provider attempt/receipt preservation, tenant notification policy, and separate approval. Recovery must not convert uncertain provider effects into retryable work.

## Rollback triggers

- authentication/tenant isolation failure;
- evidence/citation/Human Gate or formal-effect authority corruption;
- duplicate provider submission or violation of completion-unknown no-resend;
- snapshot/event predecessor or idempotency mismatch;
- material byte/version/hash divergence;
- operation-intent/job/event/snapshot/response tuple divergence, registry lifecycle drift, or source-bundle member/order mismatch;
- webhook body-object recovery failure, cross-method reconciliation evidence, or mutable Human Gate/formal terminal authority;
- sustained error/latency saturation beyond approved canary threshold;
- database, queue, object-store, KMS, secret, or telemetry authority unavailable beyond approved window;
- inability to identify active or rollback OCI digest/config/migration head;
- any P0 or unresolved P1.

## Target SLOs — all UNPROVEN

| Indicator | Proposed target | Window | Current proof |
|---|---:|---:|---|
| Authenticated web availability | 99.9% | calendar month | UNPROVEN |
| Durable command acceptance availability | 99.9% | calendar month | UNPROVEN |
| Read-project p95 | <= 750 ms | rolling 30 days | UNPROVEN |
| Command-intent commit p95, excluding provider | <= 1000 ms | rolling 30 days | UNPROVEN |
| Outbox publish age p99 | <= 60 s | rolling 24 h | UNPROVEN |
| Queue-to-worker lease p99 | <= 120 s | rolling 24 h | UNPROVEN |
| Completion-unknown reconciliation age p95 | <= 15 min when lookup exists | rolling 7 days | UNPROVEN |
| Duplicate provider submissions | 0 | lifetime | design invariant, not production-proven |
| Cross-tenant truth mutations | 0 | lifetime | design invariant, not production-proven |
| Unapproved formal research writes | 0 | lifetime | design invariant, not production-proven |
| Evidence/citation false promotion | 0 | lifetime | design invariant, not production-proven |
| Backup success | >= 99.9% scheduled jobs | rolling 30 days | UNPROVEN |

Proposed error-budget policy: freeze non-remediation changes after 50% monthly budget burn; incident review after 75%; halt traffic expansion and consider rollback at 100% or any invariant breach. Owner/SRE approval is required.

## RPO/RTO — targets requiring drill

- PostgreSQL proposed RPO: <= 5 minutes via Multi-AZ plus PITR. `UNPROVEN`.
- Versioned source-object proposed RPO: <= 15 minutes for metadata/control-plane loss; object durability follows approved S3/replication policy. `UNPROVEN`.
- Application proposed RTO: <= 30 minutes for digest rollback. `UNPROVEN`.
- Regional disaster proposed RTO/RPO: unresolved; Google Cloud Run `asia-east1` is an OCI-portable design exit/DR target, not provisioned authority. Cross-region/cross-cloud data movement requires residency approval.

No SLO, RPO, or RTO may be labeled met until production telemetry or an authorized drill binds the exact environment, artifact, migration head, data class, timestamps, and outcome.
