# Conventional CI/CD and acceptance authority

Status: static proposal; no pipeline, build, deployment, preflight, or UAT was executed.

## Source and change authority

- Git commit plus reviewed pull request is source authority. Protected branches require review, passing checks, signed/verified identity under Owner policy, and no direct production mutation.
- Dependency lockfile, migration manifest, generated API schemas, IaC lock/providers, and policy files are reviewed inputs.
- The A3 action-specific custom acceptance launcher and its hash/terminal DAG remain historical local evidence only. They cannot grant M1/M2 acceptance, Professor approval, release authority, or deployment authority.

## Build-once pipeline

1. Checkout exact commit in an ephemeral Linux runner with pinned toolchain and package-manager versions.
2. Reject secrets, credentials, provider bodies, private research fixtures, unreviewed generated files, and repository drift.
3. Run formatting/lint, TypeScript, unit, property, parser/contract, evidence/citation, tenant/auth, idempotency/no-resend, budget, migration static, and policy tests.
4. Start disposable PostgreSQL and fake queue/object/provider services. Before applying 0008, hash the exact 0001–0007 migration manifest and prove the real baseline object set. Parse the final 0008 proposal and verifier manifests and require byte-exact equality of table, view, function, trigger, owner, and ACL sets with no missing, extra, duplicate, or alias object. Apply 0001–0008 to an empty DB; verify; exercise repository/worker/outbox/reconciliation/fault cases; run N-1 application compatibility and backfill/reconciliation checks.
   The migration job uses a preprovisioned safe migrator role that may assume only the `NOLOGIN` production owner. Catalog gates prove owner/proconfig/search path, role attributes/membership closure, PUBLIC/default-deny ACLs, no raw service-role truth DML, observer access only to sanitized metadata/metrics views, and exact 0001–0007 ACL delta limited to owner `SELECT,REFERENCES` on `projects` and `workspace_members`; Better Auth and every other tenant/research privilege remain unchanged.
   Database tests prove the canonical operation tuple across intent/job/event/snapshot/response, immutable ordered source bundles, all seven registry id/version/hash/approval-event bindings including EVAL `reviewClass`, one approval then optional terminal retirement, exact attempt/receipt/usage provenance, typed outbox aggregates, Human Gate/formal-effect monotonic CAS, and coordinated-tamper rejection.
   N-1 compatibility includes the literal `/api/v2-beta2/projects/[projectId]` path, byte-exact command bodies, response/error schemas and status codes, tenant/project authorization, current idempotency replay/conflict behavior, and zero additional provider effects.
5. Build the Next.js standalone application and worker entry points into one OCI image. No environment-specific build values or secrets are embedded.
6. Generate CycloneDX or SPDX SBOM, dependency/license report, vulnerability result, SLSA-compatible provenance, and image signature/attestation. Record commit, lockfile hashes, builder identity, build parameters, OCI config digest, image digest, and test evidence hashes.
7. Push immutable digest to ECR. Mutable tags are informational and cannot be deployment authority.

## Staging promotion

1. Read-only preflight proves account, `ap-east-2`, capacity, engine/class, OIDC, backup, endpoints, and connection budget.
2. IaC plan is created from reviewed commit and sanitized parameters. Plan cannot contain secret values or research data.
3. An authorized migration job applies reviewed additive 0008 under advisory lock, records exact migration digest, and runs catalog/privilege/data verification. Application tasks never migrate at startup.
4. Deploy the exact signed OCI digest to staging. Verify task-definition and image-digest readback.
5. Run product-owned Playwright and API acceptance against stable semantic controls: auth, tenant/project fence, exact material bytes/order/hash, three directions, one recommendation, 13-field S0, Field Assist, confirmed durable save/reload, Human Gate, idempotent replay, completion-unknown no-resend, reconciliation, accessibility, and zero formal writes.
   Both the existing Beta2 client transport and the M1 internal command implementation must pass through the unchanged `/api/v2-beta2` route; no client-only atomic path cutover is accepted.
6. Run worker fault injection: crash before I/O, after possible submission, after acknowledgement, after response before commit; publish-before-outbox-ack; queue redelivery; stale lease; malformed provider output; invalid webhook; webhook crash after inbox commit; encrypted webhook-body object mismatch/unavailable; DB failover; source bundle member/version/hash mismatch; budget exhaustion. Prove relay publication owns no job transition, worker claim requires exact published outbox authority, and redelivery never creates a second provider effect.
7. Run reconciliation and terminal-authority tests. Lookup binds one exact immutable lookup receipt; signed webhook binds a `VALID` provider-event/key/body/object tuple and atomically commits observation plus inbox `APPLIED`; authorized human resolution binds active tenant/project membership, scope/policy, actor, decision hash, and time. Missing/cross-method evidence stays `UNKNOWN/BLOCKED`. Human Gate and formal-effect concurrent, reversal, hash, actor, and timestamp mutations fail atomically.
8. Soak against fake provider and approved non-sensitive synthetic fixtures. Observe SLO indicators, connection saturation, outbox age, queue age/DLQ, unknown backlog, and reconciliation latency.

## Independent manual Professor UAT

- A separate Owner/Brain authorization identifies one frozen OCI digest, staging environment fingerprint, migration head, configuration schema, and product-owned playbook.
- Professor reviews professional usefulness, clarity, completeness, evidence boundaries, Human Gate meaning, and usability. Professor does not author hashes, run migration, inspect credentials, approve provider data processing, or grant release by implication.
- Technical acceptance and Professor judgment are distinct required records. Neither substitutes for the other.

## Production promotion

Promotion is allowed only when all of the following bind the same artifact and environment contract:

- source commit and reviewed PR;
- immutable OCI digest, SBOM, provenance, signature and attestation;
- exact migration head and verified N-1 compatibility;
- staging deployment readback and technical acceptance;
- independent Professor UAT pass;
- M0_C1 production/rollback truth resolved;
- Owner approvals for account, residency, retention, backup, paid provider, budget, data processing, cutover, rollback, and release;
- canary plan and observed rollback artifact availability.

Production promotion updates only task definitions/traffic for the exact digest. It does not rebuild. ECS-native blue-green or canary shifts bounded traffic while health, error, latency, queue, database, evidence, and no-resend indicators are watched. Stop or roll back on any P0/P1, authority mismatch, unknown cleanup, or error-budget breach.

## Required evidence classes

| Evidence | Producer | Consumer | Stop rule |
|---|---|---|---|
| Unit/property/contract reports | Linux CI | merge gate | any failed or missing test blocks |
| Migration up/verify/N-1/backfill | disposable/staging PostgreSQL job | migration gate | catalog, privilege, invariant, or compatibility mismatch blocks |
| Migration proposal/verifier exact-set receipt | Linux static parser plus catalog readback | migration gate | baseline alias, digest drift, missing/extra/duplicate object, owner or ACL mismatch blocks |
| Registry/source/operation/provenance property matrix | disposable PostgreSQL integration | worker and truth gate | tuple, lifecycle, source bundle, receipt, reconciliation or terminal CAS mismatch blocks |
| OCI digest/SBOM/provenance/signature | trusted builder/signing service | staging and production deploy | unsigned, stale, or mismatched digest blocks |
| IaC plan/apply/readback | OpenTofu + AWS APIs | environment gate | unknown capability, drift, or unreviewed mutation blocks |
| Product-owned browser/API acceptance | standard Playwright/contract runner | technical acceptance | serious/critical accessibility, durable truth, no-resend, or evidence failure blocks |
| Professor UAT record | independent human review | release board | absent, scoped to another digest, or no-go blocks |
| Canary/soak telemetry | production telemetry | traffic controller/operator | threshold or authority mismatch stops promotion |
| Rollback/restore drill | operator under separate authorization | continuity gate | unproven artifact or missed RPO/RTO keeps release hold |

## Pipeline security

- OIDC short-lived roles; no stored cloud keys.
- Pinned third-party actions and allowed runner images.
- Separate plan, staging deploy, production promote, migration, and signing roles.
- IaC preflight and every account-scoped capability receipt bind one sanitized caller/account authority hash and observation time; account drift or `UNKNOWN` blocks plan and apply.
- Protected environments require approval; concurrency key prevents overlapping production promotion.
- Artifacts are retained immutably for the approved period; logs are sanitized and contain no research text, provider body, or credential value.
- CI may use synthetic/local fixtures only unless a separate real-data authority exists.
