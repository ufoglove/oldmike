# ADR M1A-001: Production web/BFF, durable worker, and digest promotion

Status: accepted for static design; implementation and release are held.

## Context

The physically observed public system remains V1 `V1_5_30_C2R4_BR3`. V2 Beta2 is a local-only product whose durable domain model already defines authenticated tenant/project authority, project snapshots/events, project-global operation intent, provider submission fencing, `COMPLETION_UNKNOWN`, lookup-only reconciliation, and no automatic resend. C19 remains the professional UX/evidence baseline. M0 could not obtain the current Zeabur control-plane or production database metadata authority and therefore remains blocked.

The production target must preserve those semantics while replacing process-local and action-specific execution assumptions with conventional, observable infrastructure.

## Decision

1. Keep Next.js as the web application and BFF. Web processes authenticate, authorize, validate commands, read projections, and atomically commit database intent plus outbox rows. They never call an AI provider.
2. Treat PostgreSQL as the authority for tenant/project truth, canonical operation intent, source bundles, typed immutable AI registries, job state, exact provider attempts/receipts/reconciliation evidence, budgets, evaluation status, evidence/citation authority, Human Gate decisions, and formal-effect authorization. All production objects and definer routines have one `NOLOGIN` owner; application/observer roles have no owner membership or raw truth DML.
3. Run an independently scalable durable worker. It leases eligible jobs, commits immutable request/prompt/schema/model/config/source/evaluation hashes, then performs provider I/O outside database transactions. A provider acknowledgement followed by timeout, disconnect, process loss, or ambiguous response becomes `COMPLETION_UNKNOWN`; it cannot return to a submitting state.
4. The web command transaction creates a pending operation intent, `QUEUED` job, and typed pending outbox row atomically. A relay only leases/publishes/acknowledges identifiers, versions, and hashes to SQS FIFO; it never owns a job-state transition. A worker can claim the job only after the exact outbox row is published. SQS is delivery infrastructure, not business truth; PostgreSQL uniqueness and compare-and-set rules enforce idempotency through publish/ack crash and redelivery windows.
5. Store raw or large research materials in versioned S3 with SSE-KMS. PostgreSQL stores immutable ORIGINAL or DERIVATIVE object authority and a versioned ordered source bundle whose contiguous members bind object ID, object-store version, byte length, and content hash; the job has an exact composite bundle FK. Queue messages and ordinary logs contain no research text or provider bodies.
6. Put provider-neutral contracts behind an AI Gateway. M1 implements the gateway, fake adapter, policy, strict parsing, budgets, and telemetry. M2 may implement OpenAI Responses and OpenClaw adapters only after capability, privacy, retention, and paid-service approvals.
7. Build one OCI artifact in Linux CI. Attach SBOM, provenance, vulnerability results, signature, and attestation; deploy the exact digest to staging; run product-owned acceptance and independent manual Professor UAT; promote the same digest. Do not rebuild for production.
8. Target AWS Asia Pacific (Taipei) `ap-east-2`, subject to an account-level capability preflight. Use ECS/Fargate plus ALB, a traditional RDS PostgreSQL Multi-AZ DB instance, SQS FIFO/DLQ, S3, ECR, Secrets Manager/KMS, CloudWatch/X-Ray or OpenTelemetry-compatible telemetry, WAF, and standard AWS Backup/Vault Lock where the account probe proves availability. Do not require RDS Proxy or CloudTrail Lake.
9. Keep authenticated research APIs on the regional ALB when Taiwan residency is required. CloudFront may serve public static assets only unless a later owner-approved data-flow review allows more.
10. Retire the A3 action-specific custom acceptance harness from future release authority. Historical evidence stays immutable. Future authority comes from Git-backed source, conventional CI receipts, exact OCI digest, product-owned tests, environment preflight, and independent Professor UAT.
11. Preserve `/api/v2-beta2/projects/[projectId]` as the M1/M2 public application path. Route internals may delegate to the new command/query layer, but request bytes, response/error envelopes, HTTP status, tenant/project authorization, idempotency, and effect cardinality remain N-1 compatible. A future public path/version change requires a separate negotiated compatibility and deprecation decision.

## Invariants carried forward

- C19 professional language, three-direction flow, 13-field S0, Field Assist, evidence boundary, and Human Gate semantics are preserved.
- Every command binds authenticated user, workspace, project, base revision/content hash, operation, request ID, idempotency key, and canonical request hash.
- Intent, job and event share one host-derived operation identity. Exact replay returns the original immutable result after later revisions; changed key/request tuples fail before all effects.
- Same key and same request replays the immutable committed result with zero provider or truth delta; any mismatch conflicts before mutation.
- Provider submission count is monotonic `0 -> 1` and never exceeds one per exact stage/effect lineage.
- `COMPLETION_UNKNOWN` permanently forbids blind resend and cross-provider failover. Reconciliation requires an exact attempt-bound lookup receipt, a recoverable `VALID` signed-webhook inbox tuple whose bounded body is retained as an immutable versioned encrypted object, or a separately authorized active-member decision binding membership/scope/policy/hash/time; missing evidence remains blocked.
- Prompt, schema, model, evaluation (including `reviewClass`), provider configuration, privacy, and retention are immutable typed `(kind,id,version,hash,approval-event)` authorities. Approval is sequence 1; retirement is the sole optional terminal sequence 2. Jobs bind all seven full tuples.
- Provider output is advisory until host-side strict parsing, domain validation, evidence/citation binding, and Human Gate authority pass.
- Formal research writes remain zero unless a separate, explicit Human Gate decision and formal-effect authority permit a bounded effect.

## M1 boundary

M1 implements runtime configuration, bounded database pools, web command/query services, migration 0008, outbox/inbox, worker/relay/reconciliation processes, queue and object-store ports, fake-provider integration, readiness/telemetry, IaC modules, CI/CD, staging, and fault-tested local/disposable integration. It does not enable a live AI provider or execute a production migration.

## M2 boundary

M2 may implement and qualify live OpenAI Responses and OpenClaw adapters, signed provider webhooks, provider-specific lookup, model/prompt/schema registrations, budget policy, retention, evaluation thresholds, and production egress. M2 requires account/provider/data-residency/privacy/paid-service approval and cannot weaken M1 no-resend or host-owned truth.

## Proposed M1 implementation sequence

1. Resolve M0_C1 and freeze observed production/control-plane/database/rollback truth.
2. Approve account, residency, retention, backup, connection-budget, cost, and migration decisions; run the read-only `ap-east-2` capability preflight.
3. Establish conventional Git/CI authority, central runtime configuration, process roles, bounded pool factory, strict domain contracts, and synthetic fixtures.
4. Preprovision and verify exact migrator/NOLOGIN owner/web/worker/relay/observer role attributes and ACLs; finalize migration 0008 capability routines, threat review, digest, up/verify/N-1/backfill/restore tests; do not execute production migration.
5. Implement web command/query, operation intent, project truth, outbox/inbox, object-store and queue ports with fake adapters.
6. Implement outbox relay, durable worker, reconciliation worker, strict AI Gateway, budgets, usage, evidence/citation and Human Gate integration.
7. Implement OpenTofu modules, telemetry/readiness, Linux CI build-once evidence, and exact-digest staging.
8. Run contract/property/fault/integration/product-owned acceptance, migration/backfill/restore, accessibility, security and soak gates using synthetic data.
9. Obtain a separate Owner decision for production migration/cutover and a separate independent Professor UAT authorization for the frozen digest.

No later step may be used to infer approval for an earlier held step.

## Consequences

- Web latency and provider latency are decoupled; the UI observes durable queued/running/reconciliation states.
- Queue redelivery is expected and harmless because database authority is definitive.
- Connection budgets must be calculated per ECS task and role because no RDS Proxy dependency is assumed.
- Application rollback and data recovery are distinct. A previous image may be redeployed only while schema compatibility is proven; data restore requires a separately authorized recovery procedure.
- RPO/RTO, AWS availability, capacity, pricing, rollback retrievability, and production migration head remain unproven until observed and drilled.
