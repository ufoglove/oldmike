-- Old Mike V2 production AI foundation, migration 0008 STATIC PROPOSAL.
-- NOT EXECUTED. This file is outside research-portal and is not in migration-manifest.json.
-- It is additive to migrations 0001..0007 and preserves all existing objects.
-- Final executable 0008 requires M0_C1, Owner migration approval, disposable/staging
-- validation, exact checksums, separately provisioned roles, and reviewed
-- SECURITY DEFINER capability bodies. All created objects are owned by the exact
-- NOLOGIN owner; the migration session role never retains object ownership.

BEGIN;

DO $m1a$
BEGIN
  IF to_regclass('public.projects') IS NULL
     OR to_regclass('public.workspace_members') IS NULL
     OR to_regclass('public."user"') IS NULL THEN
    RAISE EXCEPTION 'production_ai_required_baseline_0001_0007_missing';
  END IF;
  IF EXISTS (
    SELECT 1 FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE n.nspname = 'public' AND c.relname LIKE 'production_%'
  ) THEN
    RAISE EXCEPTION 'production_ai_0008_requires_clean_additive_namespace';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'old_mike_prod_migrator')
     OR NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'old_mike_prod_owner')
     OR NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'old_mike_prod_web')
     OR NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'old_mike_prod_worker')
     OR NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'old_mike_prod_relay')
     OR NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'old_mike_prod_observer') THEN
    RAISE EXCEPTION 'production_ai_preprovisioned_roles_missing';
  END IF;
  IF EXISTS (
    SELECT 1
    FROM (VALUES
      ('old_mike_prod_migrator', true),
      ('old_mike_prod_owner', false),
      ('old_mike_prod_web', true),
      ('old_mike_prod_worker', true),
      ('old_mike_prod_relay', true),
      ('old_mike_prod_observer', true)
    ) expected(rolname, can_login)
    JOIN pg_roles role ON role.rolname = expected.rolname
    WHERE role.rolsuper OR role.rolinherit OR role.rolcreaterole OR role.rolcreatedb
       OR role.rolreplication OR role.rolbypassrls
       OR role.rolcanlogin IS DISTINCT FROM expected.can_login
  ) THEN
    RAISE EXCEPTION 'production_ai_preprovisioned_role_attributes_unsafe';
  END IF;
  IF EXISTS (
    SELECT 1
    FROM pg_auth_members membership
    JOIN pg_roles granted_role ON granted_role.oid = membership.roleid
    JOIN pg_roles member_role ON member_role.oid = membership.member
    WHERE (granted_role.rolname LIKE 'old_mike_prod_%' OR member_role.rolname LIKE 'old_mike_prod_%')
      AND NOT (granted_role.rolname = 'old_mike_prod_owner'
        AND member_role.rolname = 'old_mike_prod_migrator'
        AND NOT membership.admin_option)
  ) THEN
    RAISE EXCEPTION 'production_ai_preprovisioned_role_membership_unsafe';
  END IF;
  IF current_user <> 'old_mike_prod_migrator'
     OR NOT pg_has_role(current_user, 'old_mike_prod_owner', 'MEMBER') THEN
    RAISE EXCEPTION 'production_ai_exact_migrator_or_owner_set_authority_missing';
  END IF;
END;
$m1a$;

-- The fixed owner needs only read/reference authority on the two baseline tenant
-- parents used by exact FKs and capability authorization. The migration role must
-- already hold the grant option; inability to make this exact bounded ACL delta fails.
GRANT SELECT, REFERENCES ON TABLE projects, workspace_members TO old_mike_prod_owner;

-- All proposal objects are created as the fixed NOLOGIN owner. The migrator may
-- SET this role only for the bounded migration transaction; application roles
-- have no membership in either role and cannot become an owner.
SET LOCAL ROLE old_mike_prod_owner;
SET LOCAL search_path = pg_catalog, public, old_mike_production_private;

CREATE SCHEMA old_mike_production_private AUTHORIZATION old_mike_prod_owner;
REVOKE ALL ON SCHEMA old_mike_production_private FROM PUBLIC;

CREATE TABLE production_project_snapshots (
  workspace_id text NOT NULL,
  project_id text NOT NULL,
  revision bigint NOT NULL CHECK (revision > 0),
  schema_version text NOT NULL,
  content_hash text NOT NULL CHECK (content_hash ~ '^[0-9a-f]{64}$'),
  snapshot_payload jsonb NOT NULL CHECK (jsonb_typeof(snapshot_payload) = 'object'),
  source_job_id text,
  created_by_user_id text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT clock_timestamp(),
  PRIMARY KEY (workspace_id, project_id, revision),
  UNIQUE (workspace_id, project_id, revision, content_hash),
  UNIQUE (workspace_id, project_id, content_hash),
  FOREIGN KEY (workspace_id, project_id)
    REFERENCES projects (workspace_id, project_id) ON DELETE RESTRICT,
  FOREIGN KEY (workspace_id, created_by_user_id)
    REFERENCES workspace_members (workspace_id, user_id) ON DELETE RESTRICT
);

CREATE TABLE production_project_events (
  workspace_id text NOT NULL,
  project_id text NOT NULL,
  sequence bigint NOT NULL CHECK (sequence > 0),
  event_id text NOT NULL,
  event_type text NOT NULL,
  operation text NOT NULL,
  operation_identity_hash text NOT NULL CHECK (operation_identity_hash ~ '^[0-9a-f]{64}$'),
  request_id text NOT NULL,
  request_hash text NOT NULL CHECK (request_hash ~ '^[0-9a-f]{64}$'),
  idempotency_key text NOT NULL,
  job_id text,
  from_revision bigint NOT NULL CHECK (from_revision >= 0),
  base_content_hash text NOT NULL CHECK (base_content_hash ~ '^[0-9a-f]{64}$'),
  to_revision bigint NOT NULL CHECK (to_revision >= from_revision),
  snapshot_revision bigint,
  snapshot_content_hash text CHECK (snapshot_content_hash IS NULL OR snapshot_content_hash ~ '^[0-9a-f]{64}$'),
  predecessor_event_hash text CHECK (predecessor_event_hash IS NULL OR predecessor_event_hash ~ '^[0-9a-f]{64}$'),
  event_hash text NOT NULL CHECK (event_hash ~ '^[0-9a-f]{64}$'),
  created_by_user_id text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT clock_timestamp(),
  PRIMARY KEY (workspace_id, project_id, sequence),
  UNIQUE (workspace_id, project_id, event_id),
  UNIQUE (workspace_id, project_id, event_hash),
  UNIQUE (workspace_id, project_id, event_hash, operation_identity_hash),
  FOREIGN KEY (workspace_id, project_id)
    REFERENCES projects (workspace_id, project_id) ON DELETE RESTRICT,
  FOREIGN KEY (workspace_id, created_by_user_id)
    REFERENCES workspace_members (workspace_id, user_id) ON DELETE RESTRICT,
  FOREIGN KEY (workspace_id, project_id, snapshot_revision, snapshot_content_hash)
    REFERENCES production_project_snapshots (workspace_id, project_id, revision, content_hash) ON DELETE RESTRICT,
  CHECK ((to_revision = from_revision AND snapshot_revision IS NULL AND snapshot_content_hash IS NULL)
      OR (to_revision = from_revision + 1 AND snapshot_revision = to_revision AND snapshot_content_hash IS NOT NULL))
);

CREATE UNIQUE INDEX production_project_events_snapshot_one
  ON production_project_events (workspace_id, project_id, snapshot_revision)
  WHERE snapshot_revision IS NOT NULL;

CREATE TABLE production_operation_intents (
  workspace_id text NOT NULL,
  project_id text NOT NULL,
  operation text NOT NULL,
  operation_identity_hash text NOT NULL CHECK (operation_identity_hash ~ '^[0-9a-f]{64}$'),
  idempotency_key text NOT NULL CHECK (length(idempotency_key) BETWEEN 16 AND 180),
  request_id text NOT NULL CHECK (length(request_id) BETWEEN 16 AND 180),
  request_hash text NOT NULL CHECK (request_hash ~ '^[0-9a-f]{64}$'),
  base_revision bigint NOT NULL CHECK (base_revision >= 0),
  base_content_hash text NOT NULL CHECK (base_content_hash ~ '^[0-9a-f]{64}$'),
  status text NOT NULL CHECK (status IN ('PENDING','COMMITTED','CONFLICTED')),
  committed_revision bigint,
  committed_content_hash text CHECK (committed_content_hash IS NULL OR committed_content_hash ~ '^[0-9a-f]{64}$'),
  committed_event_hash text CHECK (committed_event_hash IS NULL OR committed_event_hash ~ '^[0-9a-f]{64}$'),
  committed_response_authority jsonb,
  committed_response_hash text CHECK (committed_response_hash IS NULL OR committed_response_hash ~ '^[0-9a-f]{64}$'),
  created_by_user_id text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT clock_timestamp(),
  committed_at timestamptz,
  PRIMARY KEY (workspace_id, project_id, operation, request_id),
  UNIQUE (workspace_id, project_id, operation_identity_hash),
  UNIQUE (workspace_id, project_id, operation, request_id, idempotency_key, request_hash,
    base_revision, base_content_hash, operation_identity_hash),
  UNIQUE (workspace_id, project_id, idempotency_key),
  UNIQUE (workspace_id, project_id, request_id),
  FOREIGN KEY (workspace_id, project_id)
    REFERENCES projects (workspace_id, project_id) ON DELETE RESTRICT,
  FOREIGN KEY (workspace_id, created_by_user_id)
    REFERENCES workspace_members (workspace_id, user_id) ON DELETE RESTRICT,
  FOREIGN KEY (workspace_id, project_id, committed_event_hash, operation_identity_hash)
    REFERENCES production_project_events (workspace_id, project_id, event_hash, operation_identity_hash) ON DELETE RESTRICT,
  CHECK (
    (status = 'PENDING' AND committed_revision IS NULL AND committed_content_hash IS NULL
      AND committed_event_hash IS NULL AND committed_response_authority IS NULL
      AND committed_response_hash IS NULL AND committed_at IS NULL)
    OR
    (status = 'COMMITTED' AND committed_revision IS NOT NULL AND committed_content_hash IS NOT NULL
      AND committed_event_hash IS NOT NULL AND jsonb_typeof(committed_response_authority) = 'object'
      AND committed_response_hash IS NOT NULL AND committed_at IS NOT NULL)
    OR
    (status = 'CONFLICTED' AND committed_revision IS NULL AND committed_content_hash IS NULL
      AND committed_event_hash IS NULL AND committed_response_authority IS NULL
      AND committed_response_hash IS NULL AND committed_at IS NOT NULL)
  )
);

-- operation_identity_hash is independently derived by the command capability from
-- UTF8 length-delimited workspace/project/operation/request/idempotency/request-hash/
-- base-revision/base-content-hash fields. The caller never supplies this authority.
-- committed_response_hash is independently derived from the exact canonical JSONB
-- response authority; caller-provided current hashes are rejected. Exact replay reads
-- the immutable committed fields, while any key/request reuse with a different tuple
-- conflicts before job, outbox, event, snapshot, provider, or formal-effect mutation.

CREATE TABLE production_source_objects (
  workspace_id text NOT NULL,
  project_id text NOT NULL,
  source_object_id text NOT NULL,
  object_class text NOT NULL CHECK (object_class IN ('ORIGINAL','DERIVATIVE')),
  derivative_of_source_object_id text,
  transformation_authority_hash text CHECK (transformation_authority_hash IS NULL OR transformation_authority_hash ~ '^[0-9a-f]{64}$'),
  object_store_bucket_authority text NOT NULL,
  object_store_key_authority text NOT NULL,
  object_store_version_id text NOT NULL,
  media_type text NOT NULL,
  byte_length bigint NOT NULL CHECK (byte_length > 0),
  content_sha256 text NOT NULL CHECK (content_sha256 ~ '^[0-9a-f]{64}$'),
  kms_key_authority text NOT NULL,
  retention_class text NOT NULL,
  legal_hold_state text NOT NULL CHECK (legal_hold_state IN ('NONE','HOLD')),
  created_by_user_id text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT clock_timestamp(),
  PRIMARY KEY (workspace_id, project_id, source_object_id),
  UNIQUE (workspace_id, project_id, source_object_id, object_store_version_id, byte_length, content_sha256),
  UNIQUE (workspace_id, project_id, object_store_bucket_authority, object_store_key_authority, object_store_version_id),
  FOREIGN KEY (workspace_id, project_id)
    REFERENCES projects (workspace_id, project_id) ON DELETE RESTRICT,
  FOREIGN KEY (workspace_id, created_by_user_id)
    REFERENCES workspace_members (workspace_id, user_id) ON DELETE RESTRICT,
  FOREIGN KEY (workspace_id, project_id, derivative_of_source_object_id)
    REFERENCES production_source_objects (workspace_id, project_id, source_object_id) ON DELETE RESTRICT,
  CHECK ((object_class = 'ORIGINAL' AND derivative_of_source_object_id IS NULL AND transformation_authority_hash IS NULL)
      OR (object_class = 'DERIVATIVE' AND derivative_of_source_object_id IS NOT NULL AND transformation_authority_hash IS NOT NULL))
);

CREATE TABLE production_source_bundles (
  workspace_id text NOT NULL,
  project_id text NOT NULL,
  source_bundle_id text NOT NULL,
  version bigint NOT NULL CHECK (version > 0),
  bundle_hash text NOT NULL CHECK (bundle_hash ~ '^[0-9a-f]{64}$'),
  member_count integer NOT NULL CHECK (member_count > 0),
  total_member_bytes bigint NOT NULL CHECK (total_member_bytes > 0),
  created_by_user_id text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT clock_timestamp(),
  PRIMARY KEY (workspace_id, project_id, source_bundle_id, version),
  UNIQUE (workspace_id, project_id, bundle_hash),
  UNIQUE (workspace_id, project_id, source_bundle_id, version, bundle_hash),
  FOREIGN KEY (workspace_id, project_id)
    REFERENCES projects (workspace_id, project_id) ON DELETE RESTRICT,
  FOREIGN KEY (workspace_id, created_by_user_id)
    REFERENCES workspace_members (workspace_id, user_id) ON DELETE RESTRICT
);

CREATE TABLE production_source_bundle_members (
  workspace_id text NOT NULL,
  project_id text NOT NULL,
  source_bundle_id text NOT NULL,
  source_bundle_version bigint NOT NULL CHECK (source_bundle_version > 0),
  ordinal integer NOT NULL CHECK (ordinal >= 0),
  source_object_id text NOT NULL,
  object_store_version_id text NOT NULL,
  byte_length bigint NOT NULL CHECK (byte_length > 0),
  content_sha256 text NOT NULL CHECK (content_sha256 ~ '^[0-9a-f]{64}$'),
  PRIMARY KEY (workspace_id, project_id, source_bundle_id, source_bundle_version, ordinal),
  UNIQUE (workspace_id, project_id, source_bundle_id, source_bundle_version, source_object_id),
  FOREIGN KEY (workspace_id, project_id)
    REFERENCES projects (workspace_id, project_id) ON DELETE RESTRICT,
  FOREIGN KEY (workspace_id, project_id, source_bundle_id, source_bundle_version)
    REFERENCES production_source_bundles (workspace_id, project_id, source_bundle_id, version) ON DELETE RESTRICT,
  FOREIGN KEY (workspace_id, project_id, source_object_id, object_store_version_id, byte_length, content_sha256)
    REFERENCES production_source_objects (workspace_id, project_id, source_object_id, object_store_version_id, byte_length, content_sha256) ON DELETE RESTRICT
);

-- Canonical bundle hash preimage, ordered by ordinal ascending with no gaps:
-- UTF8(decimal(ordinal))+NUL+UTF8(source_object_id)+NUL+UTF8(object_store_version_id)
-- +NUL+decimal(byte_length)+NUL+lowercase(content_sha256)+LF for every member.
-- bundle_hash = SHA256(concatenated entry bytes). The committing capability must
-- independently recompute member_count, total_member_bytes and bundle_hash while
-- holding the project lock. ORIGINAL object bytes remain immutable; DERIVATIVE objects
-- are distinct authorities and bind their original plus transformation hash.

CREATE TABLE production_ai_authority_registry (
  registry_kind text NOT NULL CHECK (registry_kind IN ('MODEL','PROMPT','SCHEMA','EVAL','PROVIDER_CONFIG','PRIVACY','RETENTION')),
  authority_id text NOT NULL,
  version text NOT NULL,
  authority_payload jsonb NOT NULL CHECK (jsonb_typeof(authority_payload) = 'object'),
  authority_hash text NOT NULL CHECK (authority_hash ~ '^[0-9a-f]{64}$'),
  approval_event_hash text NOT NULL CHECK (approval_event_hash ~ '^[0-9a-f]{64}$'),
  review_class text,
  approved_by_principal_hash text NOT NULL CHECK (approved_by_principal_hash ~ '^[0-9a-f]{64}$'),
  approved_at timestamptz NOT NULL,
  created_at timestamptz NOT NULL DEFAULT clock_timestamp(),
  PRIMARY KEY (registry_kind, authority_id, version),
  UNIQUE (registry_kind, authority_id, version, authority_hash),
  UNIQUE (registry_kind, authority_id, version, authority_hash, approval_event_hash),
  UNIQUE (registry_kind, authority_hash),
  CHECK ((registry_kind = 'EVAL' AND review_class IS NOT NULL)
      OR (registry_kind <> 'EVAL' AND review_class IS NULL))
);

CREATE TABLE production_ai_registry_status_events (
  registry_kind text NOT NULL CHECK (registry_kind IN ('MODEL','PROMPT','SCHEMA','EVAL','PROVIDER_CONFIG','PRIVACY','RETENTION')),
  authority_id text NOT NULL,
  version text NOT NULL,
  authority_hash text NOT NULL CHECK (authority_hash ~ '^[0-9a-f]{64}$'),
  sequence bigint NOT NULL CHECK (sequence > 0),
  status text NOT NULL CHECK (status IN ('APPROVED','RETIRED')),
  authorized_principal_hash text NOT NULL CHECK (authorized_principal_hash ~ '^[0-9a-f]{64}$'),
  predecessor_event_hash text CHECK (predecessor_event_hash IS NULL OR predecessor_event_hash ~ '^[0-9a-f]{64}$'),
  event_hash text NOT NULL CHECK (event_hash ~ '^[0-9a-f]{64}$'),
  created_at timestamptz NOT NULL DEFAULT clock_timestamp(),
  PRIMARY KEY (registry_kind, authority_id, version, sequence),
  UNIQUE (event_hash),
  UNIQUE (registry_kind, authority_id, version, event_hash),
  UNIQUE (registry_kind, authority_id, version, status),
  FOREIGN KEY (registry_kind, authority_id, version, authority_hash)
    REFERENCES production_ai_authority_registry (registry_kind, authority_id, version, authority_hash) ON DELETE RESTRICT,
  FOREIGN KEY (registry_kind, authority_id, version, predecessor_event_hash)
    REFERENCES production_ai_registry_status_events (registry_kind, authority_id, version, event_hash) ON DELETE RESTRICT,
  CHECK ((sequence = 1 AND status = 'APPROVED' AND predecessor_event_hash IS NULL)
      OR (sequence = 2 AND status = 'RETIRED' AND predecessor_event_hash IS NOT NULL))
);

ALTER TABLE production_ai_authority_registry
  ADD CONSTRAINT production_ai_authority_registry_approval_event_fk
  FOREIGN KEY (registry_kind, authority_id, version, approval_event_hash)
  REFERENCES production_ai_registry_status_events (registry_kind, authority_id, version, event_hash)
  DEFERRABLE INITIALLY DEFERRED;

-- Registry content rows are immutable. A new content/hash requires a new version.
-- Sequence 1 is the sole APPROVED event and sequence 2 is the sole terminal RETIRED
-- event with exact predecessor. Historical jobs retain exact approval-event identity;
-- command capabilities require the latest event to be APPROVED before intent/provider I/O.

CREATE TABLE production_ai_jobs (
  workspace_id text NOT NULL,
  project_id text NOT NULL,
  job_id text NOT NULL,
  created_by_user_id text NOT NULL,
  contract_version text NOT NULL,
  stage_id text NOT NULL,
  effect_lineage_hash text NOT NULL CHECK (effect_lineage_hash ~ '^[0-9a-f]{64}$'),
  operation text NOT NULL,
  operation_identity_hash text NOT NULL CHECK (operation_identity_hash ~ '^[0-9a-f]{64}$'),
  request_id text NOT NULL,
  idempotency_key text NOT NULL,
  request_hash text NOT NULL CHECK (request_hash ~ '^[0-9a-f]{64}$'),
  base_revision bigint NOT NULL CHECK (base_revision >= 0),
  base_content_hash text NOT NULL CHECK (base_content_hash ~ '^[0-9a-f]{64}$'),
  source_bundle_id text NOT NULL,
  source_bundle_version bigint NOT NULL CHECK (source_bundle_version > 0),
  source_bundle_hash text NOT NULL CHECK (source_bundle_hash ~ '^[0-9a-f]{64}$'),
  prompt_registry_kind text GENERATED ALWAYS AS ('PROMPT'::text) STORED,
  prompt_id text NOT NULL,
  prompt_version text NOT NULL,
  prompt_hash text NOT NULL CHECK (prompt_hash ~ '^[0-9a-f]{64}$'),
  prompt_approval_event_hash text NOT NULL CHECK (prompt_approval_event_hash ~ '^[0-9a-f]{64}$'),
  output_schema_registry_kind text GENERATED ALWAYS AS ('SCHEMA'::text) STORED,
  output_schema_id text NOT NULL,
  output_schema_version text NOT NULL,
  output_schema_hash text NOT NULL CHECK (output_schema_hash ~ '^[0-9a-f]{64}$'),
  output_schema_approval_event_hash text NOT NULL CHECK (output_schema_approval_event_hash ~ '^[0-9a-f]{64}$'),
  model_registry_kind text GENERATED ALWAYS AS ('MODEL'::text) STORED,
  model_policy_id text NOT NULL,
  model_policy_version text NOT NULL,
  model_policy_hash text NOT NULL CHECK (model_policy_hash ~ '^[0-9a-f]{64}$'),
  model_policy_approval_event_hash text NOT NULL CHECK (model_policy_approval_event_hash ~ '^[0-9a-f]{64}$'),
  eval_registry_kind text GENERATED ALWAYS AS ('EVAL'::text) STORED,
  eval_id text NOT NULL,
  eval_version text NOT NULL,
  eval_hash text NOT NULL CHECK (eval_hash ~ '^[0-9a-f]{64}$'),
  eval_approval_event_hash text NOT NULL CHECK (eval_approval_event_hash ~ '^[0-9a-f]{64}$'),
  provider_config_registry_kind text GENERATED ALWAYS AS ('PROVIDER_CONFIG'::text) STORED,
  provider_config_id text NOT NULL,
  provider_config_version text NOT NULL,
  provider_config_hash text NOT NULL CHECK (provider_config_hash ~ '^[0-9a-f]{64}$'),
  provider_config_approval_event_hash text NOT NULL CHECK (provider_config_approval_event_hash ~ '^[0-9a-f]{64}$'),
  privacy_registry_kind text GENERATED ALWAYS AS ('PRIVACY'::text) STORED,
  privacy_policy_id text NOT NULL,
  privacy_policy_version text NOT NULL,
  privacy_policy_hash text NOT NULL CHECK (privacy_policy_hash ~ '^[0-9a-f]{64}$'),
  privacy_policy_approval_event_hash text NOT NULL CHECK (privacy_policy_approval_event_hash ~ '^[0-9a-f]{64}$'),
  retention_registry_kind text GENERATED ALWAYS AS ('RETENTION'::text) STORED,
  retention_policy_id text NOT NULL,
  retention_policy_version text NOT NULL,
  retention_policy_hash text NOT NULL CHECK (retention_policy_hash ~ '^[0-9a-f]{64}$'),
  retention_policy_approval_event_hash text NOT NULL CHECK (retention_policy_approval_event_hash ~ '^[0-9a-f]{64}$'),
  state text NOT NULL CHECK (state IN (
    'QUEUED','LEASED','SUBMITTING','ACCEPTED','COMPLETION_UNKNOWN',
    'SUCCEEDED','TERMINAL_REJECTED','FAILED_PRE_SUBMISSION','FAILED_PROVEN_NOT_SUBMITTED','CANCELLED_PRE_SUBMISSION'
  )),
  state_version bigint NOT NULL DEFAULT 1 CHECK (state_version > 0),
  provider_submission_count smallint NOT NULL DEFAULT 0 CHECK (provider_submission_count BETWEEN 0 AND 1),
  lease_owner text,
  lease_expires_at timestamptz,
  submitted_at timestamptz,
  accepted_at timestamptz,
  terminal_at timestamptz,
  acceptance_receipt_sequence integer,
  acceptance_receipt_hash text CHECK (acceptance_receipt_hash IS NULL OR acceptance_receipt_hash ~ '^[0-9a-f]{64}$'),
  terminal_receipt_sequence integer,
  terminal_receipt_hash text CHECK (terminal_receipt_hash IS NULL OR terminal_receipt_hash ~ '^[0-9a-f]{64}$'),
  sanitized_reason_code text CHECK (sanitized_reason_code IS NULL OR sanitized_reason_code ~ '^[A-Z0-9_]{3,80}$'),
  created_at timestamptz NOT NULL DEFAULT clock_timestamp(),
  updated_at timestamptz NOT NULL DEFAULT clock_timestamp(),
  PRIMARY KEY (workspace_id, project_id, job_id),
  UNIQUE (workspace_id, project_id, job_id, operation_identity_hash),
  UNIQUE (workspace_id, project_id, job_id, effect_lineage_hash),
  UNIQUE (workspace_id, project_id, effect_lineage_hash),
  UNIQUE (workspace_id, project_id, idempotency_key),
  UNIQUE (workspace_id, project_id, request_id),
  FOREIGN KEY (workspace_id, project_id)
    REFERENCES projects (workspace_id, project_id) ON DELETE RESTRICT,
  FOREIGN KEY (workspace_id, created_by_user_id)
    REFERENCES workspace_members (workspace_id, user_id) ON DELETE RESTRICT,
  FOREIGN KEY (workspace_id, project_id, operation, request_id, idempotency_key, request_hash,
    base_revision, base_content_hash, operation_identity_hash)
    REFERENCES production_operation_intents (workspace_id, project_id, operation, request_id,
      idempotency_key, request_hash, base_revision, base_content_hash, operation_identity_hash) ON DELETE RESTRICT,
  FOREIGN KEY (workspace_id, project_id, source_bundle_id, source_bundle_version, source_bundle_hash)
    REFERENCES production_source_bundles (workspace_id, project_id, source_bundle_id, version, bundle_hash) ON DELETE RESTRICT,
  FOREIGN KEY (prompt_registry_kind, prompt_id, prompt_version, prompt_hash, prompt_approval_event_hash)
    REFERENCES production_ai_authority_registry (registry_kind, authority_id, version, authority_hash, approval_event_hash) ON DELETE RESTRICT,
  FOREIGN KEY (output_schema_registry_kind, output_schema_id, output_schema_version, output_schema_hash, output_schema_approval_event_hash)
    REFERENCES production_ai_authority_registry (registry_kind, authority_id, version, authority_hash, approval_event_hash) ON DELETE RESTRICT,
  FOREIGN KEY (model_registry_kind, model_policy_id, model_policy_version, model_policy_hash, model_policy_approval_event_hash)
    REFERENCES production_ai_authority_registry (registry_kind, authority_id, version, authority_hash, approval_event_hash) ON DELETE RESTRICT,
  FOREIGN KEY (eval_registry_kind, eval_id, eval_version, eval_hash, eval_approval_event_hash)
    REFERENCES production_ai_authority_registry (registry_kind, authority_id, version, authority_hash, approval_event_hash) ON DELETE RESTRICT,
  FOREIGN KEY (provider_config_registry_kind, provider_config_id, provider_config_version, provider_config_hash, provider_config_approval_event_hash)
    REFERENCES production_ai_authority_registry (registry_kind, authority_id, version, authority_hash, approval_event_hash) ON DELETE RESTRICT,
  FOREIGN KEY (privacy_registry_kind, privacy_policy_id, privacy_policy_version, privacy_policy_hash, privacy_policy_approval_event_hash)
    REFERENCES production_ai_authority_registry (registry_kind, authority_id, version, authority_hash, approval_event_hash) ON DELETE RESTRICT,
  FOREIGN KEY (retention_registry_kind, retention_policy_id, retention_policy_version, retention_policy_hash, retention_policy_approval_event_hash)
    REFERENCES production_ai_authority_registry (registry_kind, authority_id, version, authority_hash, approval_event_hash) ON DELETE RESTRICT,
  CHECK (
    (state IN ('QUEUED','LEASED') AND provider_submission_count = 0 AND submitted_at IS NULL
      AND accepted_at IS NULL AND terminal_at IS NULL AND acceptance_receipt_sequence IS NULL
      AND acceptance_receipt_hash IS NULL AND terminal_receipt_sequence IS NULL AND terminal_receipt_hash IS NULL)
    OR (state = 'SUBMITTING' AND provider_submission_count = 0 AND submitted_at IS NOT NULL
      AND accepted_at IS NULL AND terminal_at IS NULL AND acceptance_receipt_sequence IS NULL
      AND acceptance_receipt_hash IS NULL AND terminal_receipt_sequence IS NULL AND terminal_receipt_hash IS NULL)
    OR (state = 'ACCEPTED' AND provider_submission_count = 1 AND submitted_at IS NOT NULL
      AND accepted_at IS NOT NULL AND terminal_at IS NULL AND acceptance_receipt_sequence IS NOT NULL
      AND acceptance_receipt_hash IS NOT NULL AND terminal_receipt_sequence IS NULL AND terminal_receipt_hash IS NULL)
    OR (state = 'COMPLETION_UNKNOWN' AND provider_submission_count = 1 AND submitted_at IS NOT NULL
      AND terminal_at IS NULL AND terminal_receipt_sequence IS NULL AND terminal_receipt_hash IS NULL
      AND ((accepted_at IS NULL AND acceptance_receipt_sequence IS NULL AND acceptance_receipt_hash IS NULL)
        OR (accepted_at IS NOT NULL AND acceptance_receipt_sequence IS NOT NULL AND acceptance_receipt_hash IS NOT NULL)))
    OR (state = 'SUCCEEDED' AND provider_submission_count = 1 AND submitted_at IS NOT NULL
      AND accepted_at IS NOT NULL AND terminal_at IS NOT NULL AND acceptance_receipt_sequence IS NOT NULL
      AND acceptance_receipt_hash IS NOT NULL AND terminal_receipt_sequence IS NOT NULL AND terminal_receipt_hash IS NOT NULL)
    OR (state = 'TERMINAL_REJECTED' AND provider_submission_count = 1 AND submitted_at IS NOT NULL
      AND terminal_at IS NOT NULL AND terminal_receipt_sequence IS NOT NULL AND terminal_receipt_hash IS NOT NULL
      AND ((accepted_at IS NULL AND acceptance_receipt_sequence IS NULL AND acceptance_receipt_hash IS NULL)
        OR (accepted_at IS NOT NULL AND acceptance_receipt_sequence IS NOT NULL AND acceptance_receipt_hash IS NOT NULL)))
    OR (state IN ('FAILED_PRE_SUBMISSION','CANCELLED_PRE_SUBMISSION') AND provider_submission_count = 0
      AND submitted_at IS NULL AND accepted_at IS NULL AND terminal_at IS NOT NULL
      AND acceptance_receipt_sequence IS NULL AND acceptance_receipt_hash IS NULL
      AND terminal_receipt_sequence IS NULL AND terminal_receipt_hash IS NULL)
    OR (state = 'FAILED_PROVEN_NOT_SUBMITTED' AND provider_submission_count = 0 AND submitted_at IS NOT NULL
      AND accepted_at IS NULL AND terminal_at IS NOT NULL AND acceptance_receipt_sequence IS NULL
      AND acceptance_receipt_hash IS NULL AND terminal_receipt_sequence IS NOT NULL AND terminal_receipt_hash IS NOT NULL)
  )
);

CREATE INDEX production_ai_jobs_work_idx
  ON production_ai_jobs (state, updated_at, workspace_id, project_id)
  WHERE state IN ('QUEUED','LEASED','SUBMITTING','ACCEPTED','COMPLETION_UNKNOWN');

ALTER TABLE production_project_snapshots
  ADD CONSTRAINT production_project_snapshots_source_job_fk
  FOREIGN KEY (workspace_id, project_id, source_job_id)
  REFERENCES production_ai_jobs (workspace_id, project_id, job_id) ON DELETE RESTRICT;

ALTER TABLE production_project_events
  ADD CONSTRAINT production_project_events_job_fk
  FOREIGN KEY (workspace_id, project_id, job_id, operation_identity_hash)
  REFERENCES production_ai_jobs (workspace_id, project_id, job_id, operation_identity_hash) ON DELETE RESTRICT;

ALTER TABLE production_project_events
  ADD CONSTRAINT production_project_events_operation_intent_fk
  FOREIGN KEY (workspace_id, project_id, operation, request_id, idempotency_key, request_hash,
    from_revision, base_content_hash, operation_identity_hash)
  REFERENCES production_operation_intents (workspace_id, project_id, operation, request_id,
    idempotency_key, request_hash, base_revision, base_content_hash, operation_identity_hash) ON DELETE RESTRICT;

CREATE TABLE production_ai_outbox (
  workspace_id text NOT NULL,
  project_id text NOT NULL,
  outbox_id text NOT NULL,
  job_id text,
  formal_effect_id text,
  kind text NOT NULL CHECK (kind IN ('AI_JOB_READY','RECONCILIATION_DUE','FORMAL_EFFECT_READY')),
  formal_effect_status text GENERATED ALWAYS AS (
    CASE WHEN kind = 'FORMAL_EFFECT_READY' THEN 'AUTHORIZED'::text ELSE NULL::text END
  ) STORED,
  aggregate_version bigint NOT NULL CHECK (aggregate_version > 0),
  aggregate_authority_hash text NOT NULL CHECK (aggregate_authority_hash ~ '^[0-9a-f]{64}$'),
  payload_hash text NOT NULL CHECK (payload_hash ~ '^[0-9a-f]{64}$'),
  message_payload jsonb NOT NULL CHECK (jsonb_typeof(message_payload) = 'object'),
  state text NOT NULL CHECK (state IN ('PENDING','LEASED','PUBLISHED')),
  lease_owner text,
  lease_expires_at timestamptz,
  published_message_id text,
  created_at timestamptz NOT NULL DEFAULT clock_timestamp(),
  published_at timestamptz,
  PRIMARY KEY (workspace_id, project_id, outbox_id),
  FOREIGN KEY (workspace_id, project_id)
    REFERENCES projects (workspace_id, project_id) ON DELETE RESTRICT,
  FOREIGN KEY (workspace_id, project_id, job_id, aggregate_authority_hash)
    REFERENCES production_ai_jobs (workspace_id, project_id, job_id, effect_lineage_hash) ON DELETE RESTRICT,
  CHECK (((kind IN ('AI_JOB_READY','RECONCILIATION_DUE')) AND job_id IS NOT NULL AND formal_effect_id IS NULL)
      OR (kind = 'FORMAL_EFFECT_READY' AND job_id IS NULL AND formal_effect_id IS NOT NULL)),
  CHECK ((state = 'PUBLISHED' AND published_message_id IS NOT NULL AND published_at IS NOT NULL)
      OR (state <> 'PUBLISHED' AND published_message_id IS NULL AND published_at IS NULL)),
  CHECK ((message_payload - ARRAY[
    'schemaId','workspaceId','projectId','kind','jobId','formalEffectId','aggregateVersion','aggregateAuthorityHash'
  ]::text[]) = '{}'::jsonb),
  CHECK ((kind IN ('AI_JOB_READY','RECONCILIATION_DUE')
      AND message_payload ?& ARRAY['schemaId','workspaceId','projectId','kind','jobId','aggregateVersion','aggregateAuthorityHash']
      AND NOT (message_payload ? 'formalEffectId'))
    OR (kind = 'FORMAL_EFFECT_READY'
      AND message_payload ?& ARRAY['schemaId','workspaceId','projectId','kind','formalEffectId','aggregateVersion','aggregateAuthorityHash']
      AND NOT (message_payload ? 'jobId')))
);

CREATE UNIQUE INDEX production_ai_outbox_job_aggregate_once
  ON production_ai_outbox (workspace_id, project_id, job_id, kind, aggregate_version)
  WHERE job_id IS NOT NULL;
CREATE UNIQUE INDEX production_ai_outbox_formal_effect_once
  ON production_ai_outbox (workspace_id, project_id, formal_effect_id, kind, aggregate_version)
  WHERE formal_effect_id IS NOT NULL;

CREATE INDEX production_ai_outbox_pending_idx
  ON production_ai_outbox (state, created_at)
  WHERE state IN ('PENDING','LEASED');

CREATE TABLE production_ai_inbox (
  workspace_id text NOT NULL,
  project_id text NOT NULL,
  consumer text NOT NULL,
  message_id text NOT NULL,
  payload_hash text NOT NULL CHECK (payload_hash ~ '^[0-9a-f]{64}$'),
  status text NOT NULL CHECK (status IN ('RECEIVED','APPLIED','REJECTED')),
  received_at timestamptz NOT NULL DEFAULT clock_timestamp(),
  applied_at timestamptz,
  PRIMARY KEY (workspace_id, project_id, consumer, message_id),
  FOREIGN KEY (workspace_id, project_id)
    REFERENCES projects (workspace_id, project_id) ON DELETE RESTRICT,
  CHECK ((status = 'RECEIVED' AND applied_at IS NULL) OR (status <> 'RECEIVED' AND applied_at IS NOT NULL))
);

CREATE TABLE production_ai_provider_attempts (
  workspace_id text NOT NULL,
  project_id text NOT NULL,
  job_id text NOT NULL,
  attempt_no smallint NOT NULL CHECK (attempt_no = 1),
  provider_class text NOT NULL,
  provider_request_id text NOT NULL,
  request_hash text NOT NULL CHECK (request_hash ~ '^[0-9a-f]{64}$'),
  request_authority_hash text NOT NULL CHECK (request_authority_hash ~ '^[0-9a-f]{64}$'),
  state text NOT NULL CHECK (state IN ('PREPARED','IO_STARTED','ACKNOWLEDGED','COMPLETION_UNKNOWN','TERMINAL')),
  terminal_outcome text CHECK (terminal_outcome IS NULL OR terminal_outcome IN ('SUCCEEDED','TERMINAL_REJECTED','PROVEN_NOT_SUBMITTED')),
  terminal_authority_hash text CHECK (terminal_authority_hash IS NULL OR terminal_authority_hash ~ '^[0-9a-f]{64}$'),
  io_started_at timestamptz,
  acknowledged_at timestamptz,
  terminal_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT clock_timestamp(),
  PRIMARY KEY (workspace_id, project_id, job_id, attempt_no),
  UNIQUE (provider_class, provider_request_id),
  UNIQUE (workspace_id, project_id, job_id, attempt_no, provider_class, provider_request_id,
    request_hash, request_authority_hash),
  FOREIGN KEY (workspace_id, project_id)
    REFERENCES projects (workspace_id, project_id) ON DELETE RESTRICT,
  FOREIGN KEY (workspace_id, project_id, job_id)
    REFERENCES production_ai_jobs (workspace_id, project_id, job_id) ON DELETE RESTRICT,
  CHECK ((state = 'PREPARED' AND io_started_at IS NULL AND acknowledged_at IS NULL
        AND terminal_at IS NULL AND terminal_outcome IS NULL AND terminal_authority_hash IS NULL)
      OR (state = 'IO_STARTED' AND io_started_at IS NOT NULL AND acknowledged_at IS NULL
        AND terminal_at IS NULL AND terminal_outcome IS NULL AND terminal_authority_hash IS NULL)
      OR (state = 'ACKNOWLEDGED' AND io_started_at IS NOT NULL AND acknowledged_at IS NOT NULL
        AND terminal_at IS NULL AND terminal_outcome IS NULL AND terminal_authority_hash IS NULL)
      OR (state = 'COMPLETION_UNKNOWN' AND io_started_at IS NOT NULL
        AND terminal_at IS NULL AND terminal_outcome IS NULL AND terminal_authority_hash IS NULL)
      OR (state = 'TERMINAL' AND io_started_at IS NOT NULL AND terminal_at IS NOT NULL
        AND terminal_outcome IS NOT NULL AND terminal_authority_hash IS NOT NULL))
);

CREATE TABLE production_ai_provider_receipts (
  workspace_id text NOT NULL,
  project_id text NOT NULL,
  job_id text NOT NULL,
  attempt_no smallint NOT NULL CHECK (attempt_no = 1),
  receipt_sequence integer NOT NULL CHECK (receipt_sequence > 0),
  receipt_kind text NOT NULL CHECK (receipt_kind IN ('SUBMISSION_ACCEPTED','COMPLETION_OBSERVED','TERMINAL_REJECTED','PROVEN_NOT_SUBMITTED')),
  provider_class text NOT NULL,
  provider_request_id text NOT NULL,
  provider_receipt_id text,
  request_hash text NOT NULL CHECK (request_hash ~ '^[0-9a-f]{64}$'),
  request_authority_hash text NOT NULL CHECK (request_authority_hash ~ '^[0-9a-f]{64}$'),
  acceptance_proof_hash text CHECK (acceptance_proof_hash IS NULL OR acceptance_proof_hash ~ '^[0-9a-f]{64}$'),
  result_hash text CHECK (result_hash IS NULL OR result_hash ~ '^[0-9a-f]{64}$'),
  rejection_authority_hash text CHECK (rejection_authority_hash IS NULL OR rejection_authority_hash ~ '^[0-9a-f]{64}$'),
  non_submission_proof_hash text CHECK (non_submission_proof_hash IS NULL OR non_submission_proof_hash ~ '^[0-9a-f]{64}$'),
  sanitized_reason_code text CHECK (sanitized_reason_code IS NULL OR sanitized_reason_code ~ '^[A-Z0-9_]{3,80}$'),
  predecessor_receipt_hash text CHECK (predecessor_receipt_hash IS NULL OR predecessor_receipt_hash ~ '^[0-9a-f]{64}$'),
  receipt_hash text NOT NULL CHECK (receipt_hash ~ '^[0-9a-f]{64}$'),
  observed_at timestamptz NOT NULL,
  created_at timestamptz NOT NULL DEFAULT clock_timestamp(),
  PRIMARY KEY (workspace_id, project_id, job_id, receipt_sequence),
  UNIQUE (workspace_id, project_id, job_id, receipt_hash),
  UNIQUE (workspace_id, project_id, job_id, receipt_sequence, receipt_hash),
  FOREIGN KEY (workspace_id, project_id)
    REFERENCES projects (workspace_id, project_id) ON DELETE RESTRICT,
  FOREIGN KEY (workspace_id, project_id, job_id)
    REFERENCES production_ai_jobs (workspace_id, project_id, job_id) ON DELETE RESTRICT,
  FOREIGN KEY (workspace_id, project_id, job_id, attempt_no, provider_class, provider_request_id,
    request_hash, request_authority_hash)
    REFERENCES production_ai_provider_attempts (workspace_id, project_id, job_id, attempt_no,
      provider_class, provider_request_id, request_hash, request_authority_hash) ON DELETE RESTRICT,
  FOREIGN KEY (workspace_id, project_id, job_id, predecessor_receipt_hash)
    REFERENCES production_ai_provider_receipts (workspace_id, project_id, job_id, receipt_hash) ON DELETE RESTRICT,
  CHECK ((receipt_sequence = 1 AND predecessor_receipt_hash IS NULL)
      OR (receipt_sequence > 1 AND predecessor_receipt_hash IS NOT NULL)),
  CHECK ((receipt_kind = 'SUBMISSION_ACCEPTED' AND acceptance_proof_hash IS NOT NULL
        AND result_hash IS NULL AND rejection_authority_hash IS NULL
        AND non_submission_proof_hash IS NULL AND sanitized_reason_code IS NULL)
    OR (receipt_kind = 'COMPLETION_OBSERVED' AND acceptance_proof_hash IS NULL
        AND result_hash IS NOT NULL AND rejection_authority_hash IS NULL
        AND non_submission_proof_hash IS NULL AND sanitized_reason_code IS NULL)
    OR (receipt_kind = 'TERMINAL_REJECTED' AND acceptance_proof_hash IS NULL
        AND result_hash IS NULL AND rejection_authority_hash IS NOT NULL
        AND non_submission_proof_hash IS NULL AND sanitized_reason_code IS NOT NULL)
    OR (receipt_kind = 'PROVEN_NOT_SUBMITTED' AND acceptance_proof_hash IS NULL
        AND result_hash IS NULL AND rejection_authority_hash IS NULL
        AND non_submission_proof_hash IS NOT NULL AND sanitized_reason_code IS NOT NULL))
);

ALTER TABLE production_ai_jobs
  ADD CONSTRAINT production_ai_jobs_acceptance_receipt_fk
  FOREIGN KEY (workspace_id, project_id, job_id, acceptance_receipt_sequence, acceptance_receipt_hash)
  REFERENCES production_ai_provider_receipts (workspace_id, project_id, job_id, receipt_sequence, receipt_hash)
  DEFERRABLE INITIALLY DEFERRED;

ALTER TABLE production_ai_jobs
  ADD CONSTRAINT production_ai_jobs_terminal_receipt_fk
  FOREIGN KEY (workspace_id, project_id, job_id, terminal_receipt_sequence, terminal_receipt_hash)
  REFERENCES production_ai_provider_receipts (workspace_id, project_id, job_id, receipt_sequence, receipt_hash)
  DEFERRABLE INITIALLY DEFERRED;

CREATE UNIQUE INDEX production_ai_provider_receipts_accept_once
  ON production_ai_provider_receipts (workspace_id, project_id, job_id)
  WHERE receipt_kind = 'SUBMISSION_ACCEPTED';

CREATE TABLE production_ai_provider_lookup_receipts (
  workspace_id text NOT NULL,
  project_id text NOT NULL,
  job_id text NOT NULL,
  attempt_no smallint NOT NULL CHECK (attempt_no = 1),
  lookup_receipt_id text NOT NULL,
  provider_class text NOT NULL,
  provider_request_id text NOT NULL,
  request_hash text NOT NULL CHECK (request_hash ~ '^[0-9a-f]{64}$'),
  request_authority_hash text NOT NULL CHECK (request_authority_hash ~ '^[0-9a-f]{64}$'),
  status text NOT NULL CHECK (status IN ('NOT_FOUND','PENDING','COMPLETE','TERMINAL_REJECTED','UNKNOWN')),
  payload_hash text NOT NULL CHECK (payload_hash ~ '^[0-9a-f]{64}$'),
  result_hash text CHECK (result_hash IS NULL OR result_hash ~ '^[0-9a-f]{64}$'),
  rejection_authority_hash text CHECK (rejection_authority_hash IS NULL OR rejection_authority_hash ~ '^[0-9a-f]{64}$'),
  lookup_receipt_hash text NOT NULL CHECK (lookup_receipt_hash ~ '^[0-9a-f]{64}$'),
  observed_at timestamptz NOT NULL,
  created_at timestamptz NOT NULL DEFAULT clock_timestamp(),
  PRIMARY KEY (workspace_id, project_id, job_id, lookup_receipt_id),
  UNIQUE (workspace_id, project_id, job_id, lookup_receipt_id, lookup_receipt_hash, status, payload_hash),
  FOREIGN KEY (workspace_id, project_id)
    REFERENCES projects (workspace_id, project_id) ON DELETE RESTRICT,
  FOREIGN KEY (workspace_id, project_id, job_id, attempt_no, provider_class, provider_request_id,
    request_hash, request_authority_hash)
    REFERENCES production_ai_provider_attempts (workspace_id, project_id, job_id, attempt_no,
      provider_class, provider_request_id, request_hash, request_authority_hash) ON DELETE RESTRICT,
  CHECK ((status = 'COMPLETE' AND result_hash IS NOT NULL AND rejection_authority_hash IS NULL)
    OR (status = 'TERMINAL_REJECTED' AND result_hash IS NULL AND rejection_authority_hash IS NOT NULL)
    OR (status NOT IN ('COMPLETE','TERMINAL_REJECTED') AND result_hash IS NULL AND rejection_authority_hash IS NULL))
);

CREATE TABLE production_ai_reconciliation_human_authorities (
  workspace_id text NOT NULL,
  project_id text NOT NULL,
  job_id text NOT NULL,
  attempt_no smallint NOT NULL CHECK (attempt_no = 1),
  human_resolution_id text NOT NULL,
  provider_class text NOT NULL,
  provider_request_id text NOT NULL,
  request_hash text NOT NULL CHECK (request_hash ~ '^[0-9a-f]{64}$'),
  request_authority_hash text NOT NULL CHECK (request_authority_hash ~ '^[0-9a-f]{64}$'),
  decision text NOT NULL CHECK (decision IN ('RESOLVE_COMPLETE','RESOLVE_TERMINAL_REJECTED')),
  result_hash text CHECK (result_hash IS NULL OR result_hash ~ '^[0-9a-f]{64}$'),
  rejection_authority_hash text CHECK (rejection_authority_hash IS NULL OR rejection_authority_hash ~ '^[0-9a-f]{64}$'),
  decision_hash text NOT NULL CHECK (decision_hash ~ '^[0-9a-f]{64}$'),
  decided_by_user_id text NOT NULL,
  membership_authority_hash text NOT NULL CHECK (membership_authority_hash ~ '^[0-9a-f]{64}$'),
  authorization_scope_hash text NOT NULL CHECK (authorization_scope_hash ~ '^[0-9a-f]{64}$'),
  authorization_policy_hash text NOT NULL CHECK (authorization_policy_hash ~ '^[0-9a-f]{64}$'),
  decided_at timestamptz NOT NULL,
  created_at timestamptz NOT NULL DEFAULT clock_timestamp(),
  PRIMARY KEY (workspace_id, project_id, job_id, human_resolution_id),
  UNIQUE (workspace_id, project_id, job_id, human_resolution_id, decision_hash, decision),
  FOREIGN KEY (workspace_id, project_id)
    REFERENCES projects (workspace_id, project_id) ON DELETE RESTRICT,
  FOREIGN KEY (workspace_id, decided_by_user_id)
    REFERENCES workspace_members (workspace_id, user_id) ON DELETE RESTRICT,
  FOREIGN KEY (workspace_id, project_id, job_id, attempt_no, provider_class, provider_request_id,
    request_hash, request_authority_hash)
    REFERENCES production_ai_provider_attempts (workspace_id, project_id, job_id, attempt_no,
      provider_class, provider_request_id, request_hash, request_authority_hash) ON DELETE RESTRICT,
  CHECK ((decision = 'RESOLVE_COMPLETE' AND result_hash IS NOT NULL AND rejection_authority_hash IS NULL)
    OR (decision = 'RESOLVE_TERMINAL_REJECTED' AND result_hash IS NULL AND rejection_authority_hash IS NOT NULL))
);

CREATE TABLE production_ai_reconciliation_observations (
  workspace_id text NOT NULL,
  project_id text NOT NULL,
  job_id text NOT NULL,
  attempt_no smallint NOT NULL CHECK (attempt_no = 1),
  observation_id text NOT NULL,
  method text NOT NULL CHECK (method IN ('LOOKUP','SIGNED_WEBHOOK','AUTHORIZED_HUMAN')),
  provider_class text NOT NULL,
  provider_request_id text NOT NULL,
  provider_event_id text,
  status text NOT NULL CHECK (status IN ('NOT_FOUND','PENDING','COMPLETE','TERMINAL_REJECTED','UNKNOWN')),
  request_hash text NOT NULL CHECK (request_hash ~ '^[0-9a-f]{64}$'),
  request_authority_hash text NOT NULL CHECK (request_authority_hash ~ '^[0-9a-f]{64}$'),
  payload_hash text NOT NULL CHECK (payload_hash ~ '^[0-9a-f]{64}$'),
  result_hash text CHECK (result_hash IS NULL OR result_hash ~ '^[0-9a-f]{64}$'),
  lookup_receipt_id text,
  lookup_receipt_hash text CHECK (lookup_receipt_hash IS NULL OR lookup_receipt_hash ~ '^[0-9a-f]{64}$'),
  webhook_key_version text,
  webhook_raw_body_hash text CHECK (webhook_raw_body_hash IS NULL OR webhook_raw_body_hash ~ '^[0-9a-f]{64}$'),
  webhook_signature_status text GENERATED ALWAYS AS (
    CASE WHEN method = 'SIGNED_WEBHOOK' THEN 'VALID'::text ELSE NULL::text END
  ) STORED,
  human_resolution_id text,
  human_decision_hash text CHECK (human_decision_hash IS NULL OR human_decision_hash ~ '^[0-9a-f]{64}$'),
  human_decision text CHECK (human_decision IS NULL OR human_decision IN ('RESOLVE_COMPLETE','RESOLVE_TERMINAL_REJECTED')),
  observed_at timestamptz NOT NULL,
  created_at timestamptz NOT NULL DEFAULT clock_timestamp(),
  PRIMARY KEY (workspace_id, project_id, job_id, observation_id),
  UNIQUE (provider_class, provider_event_id),
  UNIQUE (provider_class, provider_event_id, webhook_key_version, webhook_raw_body_hash,
    webhook_signature_status, observation_id, payload_hash),
  FOREIGN KEY (workspace_id, project_id)
    REFERENCES projects (workspace_id, project_id) ON DELETE RESTRICT,
  FOREIGN KEY (workspace_id, project_id, job_id)
    REFERENCES production_ai_jobs (workspace_id, project_id, job_id) ON DELETE RESTRICT,
  FOREIGN KEY (workspace_id, project_id, job_id, attempt_no, provider_class, provider_request_id,
    request_hash, request_authority_hash)
    REFERENCES production_ai_provider_attempts (workspace_id, project_id, job_id, attempt_no,
      provider_class, provider_request_id, request_hash, request_authority_hash) ON DELETE RESTRICT,
  FOREIGN KEY (workspace_id, project_id, job_id, lookup_receipt_id, lookup_receipt_hash, status, payload_hash)
    REFERENCES production_ai_provider_lookup_receipts (
      workspace_id, project_id, job_id, lookup_receipt_id, lookup_receipt_hash, status, payload_hash
    ) ON DELETE RESTRICT,
  FOREIGN KEY (workspace_id, project_id, job_id, human_resolution_id, human_decision_hash, human_decision)
    REFERENCES production_ai_reconciliation_human_authorities (
      workspace_id, project_id, job_id, human_resolution_id, decision_hash, decision
    ) ON DELETE RESTRICT,
  CHECK ((status = 'COMPLETE' AND result_hash IS NOT NULL) OR (status <> 'COMPLETE' AND result_hash IS NULL)),
  CHECK ((method = 'LOOKUP' AND lookup_receipt_id IS NOT NULL AND lookup_receipt_hash IS NOT NULL
      AND provider_event_id IS NULL AND webhook_key_version IS NULL AND webhook_raw_body_hash IS NULL
      AND human_resolution_id IS NULL AND human_decision_hash IS NULL AND human_decision IS NULL)
    OR (method = 'SIGNED_WEBHOOK' AND provider_event_id IS NOT NULL
      AND webhook_key_version IS NOT NULL AND webhook_raw_body_hash IS NOT NULL
      AND lookup_receipt_id IS NULL AND lookup_receipt_hash IS NULL
      AND human_resolution_id IS NULL AND human_decision_hash IS NULL AND human_decision IS NULL)
    OR (method = 'AUTHORIZED_HUMAN' AND human_resolution_id IS NOT NULL
      AND human_decision_hash IS NOT NULL AND human_decision IS NOT NULL
      AND lookup_receipt_id IS NULL AND lookup_receipt_hash IS NULL
      AND provider_event_id IS NULL AND webhook_key_version IS NULL AND webhook_raw_body_hash IS NULL))
);

CREATE TABLE production_ai_webhook_inbox (
  provider_class text NOT NULL,
  provider_event_id text NOT NULL,
  key_version text NOT NULL,
  signature_status text NOT NULL CHECK (signature_status IN ('VALID','INVALID')),
  raw_body_byte_length bigint NOT NULL CHECK (raw_body_byte_length > 0),
  raw_body_hash text NOT NULL CHECK (raw_body_hash ~ '^[0-9a-f]{64}$'),
  raw_body_storage_class text NOT NULL CHECK (raw_body_storage_class = 'VERSIONED_ENCRYPTED_OBJECT'),
  raw_body_object_id text NOT NULL,
  raw_body_object_key_hash text NOT NULL CHECK (raw_body_object_key_hash ~ '^[0-9a-f]{64}$'),
  raw_body_object_version_id text NOT NULL,
  raw_body_storage_receipt_hash text NOT NULL CHECK (raw_body_storage_receipt_hash ~ '^[0-9a-f]{64}$'),
  request_timestamp timestamptz NOT NULL,
  received_at timestamptz NOT NULL DEFAULT clock_timestamp(),
  status text NOT NULL CHECK (status IN ('RECEIVED','LEASED','APPLIED','REJECTED')),
  lease_owner text,
  lease_expires_at timestamptz,
  applied_workspace_id text,
  applied_project_id text,
  applied_job_id text,
  applied_observation_id text,
  applied_observation_payload_hash text CHECK (applied_observation_payload_hash IS NULL OR applied_observation_payload_hash ~ '^[0-9a-f]{64}$'),
  applied_at timestamptz,
  PRIMARY KEY (provider_class, provider_event_id),
  UNIQUE (provider_class, provider_event_id, key_version, raw_body_hash, signature_status),
  UNIQUE (provider_class, provider_event_id, raw_body_object_id, raw_body_object_key_hash,
    raw_body_object_version_id, raw_body_storage_receipt_hash),
  FOREIGN KEY (applied_workspace_id, applied_project_id, applied_job_id)
    REFERENCES production_ai_jobs (workspace_id, project_id, job_id) ON DELETE RESTRICT,
  FOREIGN KEY (provider_class, provider_event_id, key_version, raw_body_hash, signature_status,
    applied_observation_id, applied_observation_payload_hash)
    REFERENCES production_ai_reconciliation_observations (
      provider_class, provider_event_id, webhook_key_version, webhook_raw_body_hash,
      webhook_signature_status, observation_id, payload_hash
    ) DEFERRABLE INITIALLY DEFERRED,
  CHECK ((status = 'RECEIVED' AND lease_owner IS NULL AND lease_expires_at IS NULL
        AND applied_workspace_id IS NULL AND applied_project_id IS NULL AND applied_job_id IS NULL
        AND applied_observation_id IS NULL AND applied_observation_payload_hash IS NULL AND applied_at IS NULL)
    OR (status = 'LEASED' AND signature_status = 'VALID' AND lease_owner IS NOT NULL
        AND lease_expires_at IS NOT NULL AND applied_workspace_id IS NULL AND applied_project_id IS NULL
        AND applied_job_id IS NULL AND applied_observation_id IS NULL
        AND applied_observation_payload_hash IS NULL AND applied_at IS NULL)
    OR (status = 'APPLIED' AND signature_status = 'VALID' AND lease_owner IS NULL
        AND lease_expires_at IS NULL AND applied_workspace_id IS NOT NULL
        AND applied_project_id IS NOT NULL AND applied_job_id IS NOT NULL
        AND applied_observation_id IS NOT NULL AND applied_observation_payload_hash IS NOT NULL
        AND applied_at IS NOT NULL)
    OR (status = 'REJECTED' AND applied_workspace_id IS NULL AND applied_project_id IS NULL
        AND applied_job_id IS NULL AND applied_observation_id IS NULL
        AND applied_observation_payload_hash IS NULL AND applied_at IS NOT NULL))
);

ALTER TABLE production_ai_reconciliation_observations
  ADD CONSTRAINT production_ai_reconciliation_observations_webhook_fk
  FOREIGN KEY (provider_class, provider_event_id, webhook_key_version, webhook_raw_body_hash,
    webhook_signature_status)
  REFERENCES production_ai_webhook_inbox (
    provider_class, provider_event_id, key_version, raw_body_hash, signature_status
  ) DEFERRABLE INITIALLY DEFERRED;

CREATE TABLE production_ai_budget_reservations (
  workspace_id text NOT NULL,
  project_id text NOT NULL,
  reservation_id text NOT NULL,
  job_id text NOT NULL,
  policy_version text NOT NULL,
  currency text NOT NULL CHECK (currency ~ '^[A-Z]{3}$'),
  maximum_units numeric(24,8) NOT NULL CHECK (maximum_units > 0),
  maximum_cost numeric(24,8) NOT NULL CHECK (maximum_cost >= 0),
  status text NOT NULL CHECK (status IN ('RESERVED','CONSUMED','RELEASED','EXPIRED')),
  expires_at timestamptz NOT NULL,
  created_at timestamptz NOT NULL DEFAULT clock_timestamp(),
  terminal_at timestamptz,
  PRIMARY KEY (workspace_id, project_id, reservation_id),
  UNIQUE (workspace_id, project_id, job_id),
  FOREIGN KEY (workspace_id, project_id)
    REFERENCES projects (workspace_id, project_id) ON DELETE RESTRICT,
  FOREIGN KEY (workspace_id, project_id, job_id)
    REFERENCES production_ai_jobs (workspace_id, project_id, job_id) ON DELETE RESTRICT,
  CHECK ((status = 'RESERVED' AND terminal_at IS NULL) OR (status <> 'RESERVED' AND terminal_at IS NOT NULL))
);

CREATE TABLE production_ai_usage_ledger (
  workspace_id text NOT NULL,
  project_id text NOT NULL,
  usage_id text NOT NULL,
  job_id text NOT NULL,
  attempt_no smallint NOT NULL CHECK (attempt_no = 1),
  reservation_id text NOT NULL,
  provider_class text NOT NULL,
  provider_request_id text NOT NULL,
  request_hash text NOT NULL CHECK (request_hash ~ '^[0-9a-f]{64}$'),
  request_authority_hash text NOT NULL CHECK (request_authority_hash ~ '^[0-9a-f]{64}$'),
  provider_usage_hash text NOT NULL CHECK (provider_usage_hash ~ '^[0-9a-f]{64}$'),
  normalized_input_units numeric(24,8) NOT NULL CHECK (normalized_input_units >= 0),
  normalized_output_units numeric(24,8) NOT NULL CHECK (normalized_output_units >= 0),
  currency text NOT NULL CHECK (currency ~ '^[A-Z]{3}$'),
  normalized_cost numeric(24,8) NOT NULL CHECK (normalized_cost >= 0),
  cost_schedule_version text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT clock_timestamp(),
  PRIMARY KEY (workspace_id, project_id, usage_id),
  UNIQUE (workspace_id, project_id, job_id, provider_usage_hash),
  FOREIGN KEY (workspace_id, project_id)
    REFERENCES projects (workspace_id, project_id) ON DELETE RESTRICT,
  FOREIGN KEY (workspace_id, project_id, job_id)
    REFERENCES production_ai_jobs (workspace_id, project_id, job_id) ON DELETE RESTRICT,
  FOREIGN KEY (workspace_id, project_id, job_id, attempt_no, provider_class, provider_request_id,
    request_hash, request_authority_hash)
    REFERENCES production_ai_provider_attempts (workspace_id, project_id, job_id, attempt_no,
      provider_class, provider_request_id, request_hash, request_authority_hash) ON DELETE RESTRICT,
  FOREIGN KEY (workspace_id, project_id, reservation_id)
    REFERENCES production_ai_budget_reservations (workspace_id, project_id, reservation_id) ON DELETE RESTRICT
);

CREATE TABLE production_evidence_authorities (
  workspace_id text NOT NULL,
  project_id text NOT NULL,
  evidence_id text NOT NULL,
  snapshot_revision bigint NOT NULL,
  source_object_id text NOT NULL,
  source_start_byte bigint NOT NULL CHECK (source_start_byte >= 0),
  source_end_byte bigint NOT NULL CHECK (source_end_byte > source_start_byte),
  source_span_hash text NOT NULL CHECK (source_span_hash ~ '^[0-9a-f]{64}$'),
  evidence_state text NOT NULL CHECK (evidence_state IN ('OBSERVED','PLANNED','MISSING','UNRESOLVED','CONFLICT')),
  authority_hash text NOT NULL CHECK (authority_hash ~ '^[0-9a-f]{64}$'),
  created_at timestamptz NOT NULL DEFAULT clock_timestamp(),
  PRIMARY KEY (workspace_id, project_id, evidence_id),
  UNIQUE (workspace_id, project_id, authority_hash),
  FOREIGN KEY (workspace_id, project_id)
    REFERENCES projects (workspace_id, project_id) ON DELETE RESTRICT,
  FOREIGN KEY (workspace_id, project_id, snapshot_revision)
    REFERENCES production_project_snapshots (workspace_id, project_id, revision) ON DELETE RESTRICT,
  FOREIGN KEY (workspace_id, project_id, source_object_id)
    REFERENCES production_source_objects (workspace_id, project_id, source_object_id) ON DELETE RESTRICT
);

CREATE TABLE production_citation_authorities (
  workspace_id text NOT NULL,
  project_id text NOT NULL,
  citation_id text NOT NULL,
  snapshot_revision bigint NOT NULL,
  source_object_id text NOT NULL,
  locator text NOT NULL,
  identity_payload jsonb NOT NULL CHECK (jsonb_typeof(identity_payload) = 'object'),
  identity_hash text NOT NULL CHECK (identity_hash ~ '^[0-9a-f]{64}$'),
  citation_span_hash text NOT NULL CHECK (citation_span_hash ~ '^[0-9a-f]{64}$'),
  created_at timestamptz NOT NULL DEFAULT clock_timestamp(),
  PRIMARY KEY (workspace_id, project_id, citation_id),
  UNIQUE (workspace_id, project_id, identity_hash, citation_span_hash),
  FOREIGN KEY (workspace_id, project_id)
    REFERENCES projects (workspace_id, project_id) ON DELETE RESTRICT,
  FOREIGN KEY (workspace_id, project_id, snapshot_revision)
    REFERENCES production_project_snapshots (workspace_id, project_id, revision) ON DELETE RESTRICT,
  FOREIGN KEY (workspace_id, project_id, source_object_id)
    REFERENCES production_source_objects (workspace_id, project_id, source_object_id) ON DELETE RESTRICT
);

CREATE TABLE production_human_gate_authorities (
  workspace_id text NOT NULL,
  project_id text NOT NULL,
  human_gate_id text NOT NULL,
  snapshot_revision bigint NOT NULL,
  gate_scope text NOT NULL,
  decision text NOT NULL CHECK (decision IN ('PENDING','CONFIRMED','REJECTED')),
  gate_request_hash text NOT NULL CHECK (gate_request_hash ~ '^[0-9a-f]{64}$'),
  decision_hash text CHECK (decision_hash IS NULL OR decision_hash ~ '^[0-9a-f]{64}$'),
  decided_by_user_id text,
  decided_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT clock_timestamp(),
  PRIMARY KEY (workspace_id, project_id, human_gate_id),
  UNIQUE (workspace_id, project_id, gate_scope, snapshot_revision),
  UNIQUE (workspace_id, project_id, human_gate_id, decision, decision_hash),
  FOREIGN KEY (workspace_id, project_id)
    REFERENCES projects (workspace_id, project_id) ON DELETE RESTRICT,
  FOREIGN KEY (workspace_id, project_id, snapshot_revision)
    REFERENCES production_project_snapshots (workspace_id, project_id, revision) ON DELETE RESTRICT,
  FOREIGN KEY (workspace_id, decided_by_user_id)
    REFERENCES workspace_members (workspace_id, user_id) ON DELETE RESTRICT,
  CHECK ((decision = 'PENDING' AND decision_hash IS NULL AND decided_by_user_id IS NULL AND decided_at IS NULL)
      OR (decision <> 'PENDING' AND decision_hash IS NOT NULL
        AND decided_by_user_id IS NOT NULL AND decided_at IS NOT NULL))
);

CREATE TABLE production_formal_effect_authorities (
  workspace_id text NOT NULL,
  project_id text NOT NULL,
  formal_effect_id text NOT NULL,
  snapshot_revision bigint NOT NULL,
  human_gate_id text NOT NULL,
  human_gate_decision text GENERATED ALWAYS AS ('CONFIRMED'::text) STORED,
  human_gate_decision_hash text NOT NULL CHECK (human_gate_decision_hash ~ '^[0-9a-f]{64}$'),
  operation text NOT NULL,
  effect_payload_hash text NOT NULL CHECK (effect_payload_hash ~ '^[0-9a-f]{64}$'),
  status text NOT NULL CHECK (status IN ('AUTHORIZED','EXECUTED','REVOKED_BEFORE_EXECUTION')),
  authorization_hash text NOT NULL CHECK (authorization_hash ~ '^[0-9a-f]{64}$'),
  terminal_hash text CHECK (terminal_hash IS NULL OR terminal_hash ~ '^[0-9a-f]{64}$'),
  authorized_by_user_id text NOT NULL,
  authorized_at timestamptz NOT NULL,
  terminal_actor_hash text CHECK (terminal_actor_hash IS NULL OR terminal_actor_hash ~ '^[0-9a-f]{64}$'),
  executed_at timestamptz,
  revoked_at timestamptz,
  PRIMARY KEY (workspace_id, project_id, formal_effect_id),
  UNIQUE (workspace_id, project_id, operation, effect_payload_hash),
  UNIQUE (workspace_id, project_id, formal_effect_id, status, authorization_hash),
  UNIQUE (workspace_id, project_id, formal_effect_id, status, authorization_hash, terminal_hash),
  FOREIGN KEY (workspace_id, project_id)
    REFERENCES projects (workspace_id, project_id) ON DELETE RESTRICT,
  FOREIGN KEY (workspace_id, project_id, snapshot_revision)
    REFERENCES production_project_snapshots (workspace_id, project_id, revision) ON DELETE RESTRICT,
  FOREIGN KEY (workspace_id, project_id, human_gate_id, human_gate_decision, human_gate_decision_hash)
    REFERENCES production_human_gate_authorities (
      workspace_id, project_id, human_gate_id, decision, decision_hash
    ) ON DELETE RESTRICT,
  FOREIGN KEY (workspace_id, authorized_by_user_id)
    REFERENCES workspace_members (workspace_id, user_id) ON DELETE RESTRICT,
  CHECK ((status = 'AUTHORIZED' AND terminal_hash IS NULL AND terminal_actor_hash IS NULL
      AND executed_at IS NULL AND revoked_at IS NULL)
    OR (status = 'EXECUTED' AND terminal_hash IS NOT NULL AND terminal_actor_hash IS NOT NULL
      AND executed_at IS NOT NULL AND revoked_at IS NULL)
    OR (status = 'REVOKED_BEFORE_EXECUTION' AND terminal_hash IS NOT NULL AND terminal_actor_hash IS NOT NULL
      AND executed_at IS NULL AND revoked_at IS NOT NULL))
);

ALTER TABLE production_ai_outbox
  ADD CONSTRAINT production_ai_outbox_formal_effect_fk
  FOREIGN KEY (workspace_id, project_id, formal_effect_id, formal_effect_status, aggregate_authority_hash)
  REFERENCES production_formal_effect_authorities (
    workspace_id, project_id, formal_effect_id, status, authorization_hash
  ) ON DELETE RESTRICT;

CREATE FUNCTION old_mike_production_private.reject_append_only_mutation()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public, old_mike_production_private AS $fn$
BEGIN
  RAISE EXCEPTION 'production_append_only_authority';
END;
$fn$;

REVOKE ALL ON FUNCTION old_mike_production_private.reject_append_only_mutation() FROM PUBLIC;

CREATE TRIGGER production_project_snapshots_append_only
  BEFORE UPDATE OR DELETE ON production_project_snapshots
  FOR EACH ROW EXECUTE FUNCTION old_mike_production_private.reject_append_only_mutation();
CREATE TRIGGER production_project_events_append_only
  BEFORE UPDATE OR DELETE ON production_project_events
  FOR EACH ROW EXECUTE FUNCTION old_mike_production_private.reject_append_only_mutation();
CREATE TRIGGER production_source_objects_append_only
  BEFORE UPDATE OR DELETE ON production_source_objects
  FOR EACH ROW EXECUTE FUNCTION old_mike_production_private.reject_append_only_mutation();
CREATE TRIGGER production_source_bundles_append_only
  BEFORE UPDATE OR DELETE ON production_source_bundles
  FOR EACH ROW EXECUTE FUNCTION old_mike_production_private.reject_append_only_mutation();
CREATE TRIGGER production_source_bundle_members_append_only
  BEFORE UPDATE OR DELETE ON production_source_bundle_members
  FOR EACH ROW EXECUTE FUNCTION old_mike_production_private.reject_append_only_mutation();
CREATE TRIGGER production_authority_registry_append_only
  BEFORE UPDATE OR DELETE ON production_ai_authority_registry
  FOR EACH ROW EXECUTE FUNCTION old_mike_production_private.reject_append_only_mutation();
CREATE TRIGGER production_registry_status_events_append_only
  BEFORE UPDATE OR DELETE ON production_ai_registry_status_events
  FOR EACH ROW EXECUTE FUNCTION old_mike_production_private.reject_append_only_mutation();
CREATE TRIGGER production_provider_receipts_append_only
  BEFORE UPDATE OR DELETE ON production_ai_provider_receipts
  FOR EACH ROW EXECUTE FUNCTION old_mike_production_private.reject_append_only_mutation();
CREATE TRIGGER production_provider_lookup_receipts_append_only
  BEFORE UPDATE OR DELETE ON production_ai_provider_lookup_receipts
  FOR EACH ROW EXECUTE FUNCTION old_mike_production_private.reject_append_only_mutation();
CREATE TRIGGER production_reconciliation_human_authorities_append_only
  BEFORE UPDATE OR DELETE ON production_ai_reconciliation_human_authorities
  FOR EACH ROW EXECUTE FUNCTION old_mike_production_private.reject_append_only_mutation();
CREATE TRIGGER production_reconciliation_observations_append_only
  BEFORE UPDATE OR DELETE ON production_ai_reconciliation_observations
  FOR EACH ROW EXECUTE FUNCTION old_mike_production_private.reject_append_only_mutation();
CREATE TRIGGER production_usage_ledger_append_only
  BEFORE UPDATE OR DELETE ON production_ai_usage_ledger
  FOR EACH ROW EXECUTE FUNCTION old_mike_production_private.reject_append_only_mutation();
CREATE TRIGGER production_evidence_append_only
  BEFORE UPDATE OR DELETE ON production_evidence_authorities
  FOR EACH ROW EXECUTE FUNCTION old_mike_production_private.reject_append_only_mutation();
CREATE TRIGGER production_citations_append_only
  BEFORE UPDATE OR DELETE ON production_citation_authorities
  FOR EACH ROW EXECUTE FUNCTION old_mike_production_private.reject_append_only_mutation();

CREATE FUNCTION old_mike_production_private.guard_registry_status_event_insert()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public, old_mike_production_private AS $fn$
DECLARE
  approval_hash text;
BEGIN
  SELECT registry.approval_event_hash INTO approval_hash
  FROM public.production_ai_authority_registry registry
  WHERE registry.registry_kind = NEW.registry_kind
    AND registry.authority_id = NEW.authority_id
    AND registry.version = NEW.version
    AND registry.authority_hash = NEW.authority_hash;
  IF approval_hash IS NULL THEN
    RAISE EXCEPTION 'production_registry_exact_authority_missing';
  END IF;
  IF NEW.sequence = 1 THEN
    IF NEW.status <> 'APPROVED' OR NEW.predecessor_event_hash IS NOT NULL
       OR NEW.event_hash IS DISTINCT FROM approval_hash THEN
      RAISE EXCEPTION 'production_registry_initial_approval_invalid';
    END IF;
  ELSIF NEW.sequence = 2 THEN
    IF NEW.status <> 'RETIRED' OR NEW.predecessor_event_hash IS DISTINCT FROM approval_hash
       OR NOT EXISTS (
         SELECT 1 FROM public.production_ai_registry_status_events prior
         WHERE prior.registry_kind = NEW.registry_kind AND prior.authority_id = NEW.authority_id
           AND prior.version = NEW.version AND prior.sequence = 1 AND prior.status = 'APPROVED'
           AND prior.authority_hash = NEW.authority_hash AND prior.event_hash = approval_hash
       ) THEN
      RAISE EXCEPTION 'production_registry_retirement_chain_invalid';
    END IF;
  ELSE
    RAISE EXCEPTION 'production_registry_status_sequence_invalid';
  END IF;
  RETURN NEW;
END;
$fn$;
REVOKE ALL ON FUNCTION old_mike_production_private.guard_registry_status_event_insert() FROM PUBLIC;
CREATE TRIGGER production_registry_status_event_insert_guard
  BEFORE INSERT ON production_ai_registry_status_events
  FOR EACH ROW EXECUTE FUNCTION old_mike_production_private.guard_registry_status_event_insert();

CREATE FUNCTION old_mike_production_private.guard_provider_receipt_insert()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public, old_mike_production_private AS $fn$
DECLARE
  prior_sequence integer;
  prior_hash text;
BEGIN
  SELECT receipt.receipt_sequence, receipt.receipt_hash
    INTO prior_sequence, prior_hash
  FROM public.production_ai_provider_receipts receipt
  WHERE receipt.workspace_id = NEW.workspace_id AND receipt.project_id = NEW.project_id
    AND receipt.job_id = NEW.job_id
  ORDER BY receipt.receipt_sequence DESC
  LIMIT 1;
  IF prior_sequence IS NULL THEN
    IF NEW.receipt_sequence <> 1 OR NEW.predecessor_receipt_hash IS NOT NULL THEN
      RAISE EXCEPTION 'production_provider_receipt_initial_sequence_invalid';
    END IF;
  ELSIF NEW.receipt_sequence <> prior_sequence + 1
     OR NEW.predecessor_receipt_hash IS DISTINCT FROM prior_hash THEN
    RAISE EXCEPTION 'production_provider_receipt_chain_invalid';
  END IF;
  RETURN NEW;
END;
$fn$;
REVOKE ALL ON FUNCTION old_mike_production_private.guard_provider_receipt_insert() FROM PUBLIC;
CREATE TRIGGER production_provider_receipt_insert_guard
  BEFORE INSERT ON production_ai_provider_receipts
  FOR EACH ROW EXECUTE FUNCTION old_mike_production_private.guard_provider_receipt_insert();

CREATE FUNCTION old_mike_production_private.guard_operation_intent_transition()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public, old_mike_production_private AS $fn$
BEGIN
  IF TG_OP = 'DELETE' THEN RAISE EXCEPTION 'production_operation_intent_delete_forbidden'; END IF;
  IF NEW.workspace_id IS DISTINCT FROM OLD.workspace_id
     OR NEW.project_id IS DISTINCT FROM OLD.project_id
     OR NEW.operation IS DISTINCT FROM OLD.operation
     OR NEW.operation_identity_hash IS DISTINCT FROM OLD.operation_identity_hash
     OR NEW.idempotency_key IS DISTINCT FROM OLD.idempotency_key
     OR NEW.request_id IS DISTINCT FROM OLD.request_id
     OR NEW.request_hash IS DISTINCT FROM OLD.request_hash
     OR NEW.base_revision IS DISTINCT FROM OLD.base_revision
     OR NEW.base_content_hash IS DISTINCT FROM OLD.base_content_hash
     OR NEW.created_by_user_id IS DISTINCT FROM OLD.created_by_user_id
     OR NEW.created_at IS DISTINCT FROM OLD.created_at THEN
    RAISE EXCEPTION 'production_operation_intent_identity_immutable';
  END IF;
  IF OLD.status <> 'PENDING' OR NEW.status NOT IN ('COMMITTED','CONFLICTED') THEN
    RAISE EXCEPTION 'production_operation_intent_transition_invalid';
  END IF;
  IF NEW.status = 'COMMITTED' AND NOT EXISTS (
    SELECT 1
    FROM public.production_project_events event
    LEFT JOIN public.production_project_snapshots snapshot
      ON snapshot.workspace_id = event.workspace_id AND snapshot.project_id = event.project_id
     AND snapshot.revision = event.snapshot_revision AND snapshot.content_hash = event.snapshot_content_hash
    WHERE event.workspace_id = NEW.workspace_id AND event.project_id = NEW.project_id
      AND event.event_hash = NEW.committed_event_hash
      AND event.operation_identity_hash = NEW.operation_identity_hash
      AND event.operation = NEW.operation AND event.request_id = NEW.request_id
      AND event.idempotency_key = NEW.idempotency_key AND event.request_hash = NEW.request_hash
      AND event.from_revision = NEW.base_revision AND event.base_content_hash = NEW.base_content_hash
      AND ((event.to_revision = event.from_revision + 1
          AND event.to_revision = NEW.committed_revision
          AND event.snapshot_revision = NEW.committed_revision
          AND event.snapshot_content_hash = NEW.committed_content_hash
          AND snapshot.revision IS NOT NULL)
        OR (event.to_revision = event.from_revision AND event.snapshot_revision IS NULL
          AND event.snapshot_content_hash IS NULL
          AND NEW.committed_revision = NEW.base_revision
          AND NEW.committed_content_hash = NEW.base_content_hash))
  ) THEN
    RAISE EXCEPTION 'production_operation_intent_commit_parity_invalid';
  END IF;
  RETURN NEW;
END;
$fn$;
REVOKE ALL ON FUNCTION old_mike_production_private.guard_operation_intent_transition() FROM PUBLIC;
CREATE TRIGGER production_operation_intents_transition_guard
  BEFORE UPDATE OR DELETE ON production_operation_intents
  FOR EACH ROW EXECUTE FUNCTION old_mike_production_private.guard_operation_intent_transition();

CREATE FUNCTION old_mike_production_private.guard_provider_attempt_transition()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public, old_mike_production_private AS $fn$
DECLARE
  legal boolean := false;
  required_receipt_kind text;
BEGIN
  IF TG_OP = 'DELETE' THEN RAISE EXCEPTION 'production_provider_attempt_delete_forbidden'; END IF;
  IF NEW.workspace_id IS DISTINCT FROM OLD.workspace_id OR NEW.project_id IS DISTINCT FROM OLD.project_id
     OR NEW.job_id IS DISTINCT FROM OLD.job_id OR NEW.attempt_no IS DISTINCT FROM OLD.attempt_no
     OR NEW.provider_class IS DISTINCT FROM OLD.provider_class
     OR NEW.provider_request_id IS DISTINCT FROM OLD.provider_request_id
     OR NEW.request_hash IS DISTINCT FROM OLD.request_hash
     OR NEW.request_authority_hash IS DISTINCT FROM OLD.request_authority_hash
     OR NEW.created_at IS DISTINCT FROM OLD.created_at THEN
    RAISE EXCEPTION 'production_provider_attempt_identity_immutable';
  END IF;
  legal :=
    (OLD.state = 'PREPARED' AND NEW.state = 'IO_STARTED') OR
    (OLD.state = 'IO_STARTED' AND NEW.state IN ('ACKNOWLEDGED','COMPLETION_UNKNOWN','TERMINAL')) OR
    (OLD.state = 'ACKNOWLEDGED' AND NEW.state IN ('COMPLETION_UNKNOWN','TERMINAL')) OR
    (OLD.state = 'COMPLETION_UNKNOWN' AND NEW.state IN ('COMPLETION_UNKNOWN','TERMINAL'));
  IF NOT legal THEN RAISE EXCEPTION 'production_provider_attempt_transition_invalid'; END IF;
  IF OLD.io_started_at IS NOT NULL AND NEW.io_started_at IS DISTINCT FROM OLD.io_started_at THEN
    RAISE EXCEPTION 'production_provider_attempt_io_time_immutable';
  END IF;
  IF OLD.acknowledged_at IS NOT NULL AND NEW.acknowledged_at IS DISTINCT FROM OLD.acknowledged_at THEN
    RAISE EXCEPTION 'production_provider_attempt_ack_time_immutable';
  END IF;
  IF NEW.state = 'ACKNOWLEDGED' AND NOT EXISTS (
    SELECT 1 FROM public.production_ai_provider_receipts receipt
    WHERE receipt.workspace_id = NEW.workspace_id AND receipt.project_id = NEW.project_id
      AND receipt.job_id = NEW.job_id AND receipt.attempt_no = NEW.attempt_no
      AND receipt.provider_class = NEW.provider_class
      AND receipt.provider_request_id = NEW.provider_request_id
      AND receipt.request_hash = NEW.request_hash
      AND receipt.request_authority_hash = NEW.request_authority_hash
      AND receipt.receipt_kind = 'SUBMISSION_ACCEPTED'
  ) THEN
    RAISE EXCEPTION 'production_provider_attempt_acceptance_receipt_missing';
  END IF;
  IF NEW.state = 'TERMINAL' THEN
    required_receipt_kind := CASE NEW.terminal_outcome
      WHEN 'SUCCEEDED' THEN 'COMPLETION_OBSERVED'
      WHEN 'TERMINAL_REJECTED' THEN 'TERMINAL_REJECTED'
      WHEN 'PROVEN_NOT_SUBMITTED' THEN 'PROVEN_NOT_SUBMITTED'
      ELSE NULL END;
    IF required_receipt_kind IS NULL OR NOT EXISTS (
      SELECT 1 FROM public.production_ai_provider_receipts receipt
      WHERE receipt.workspace_id = NEW.workspace_id AND receipt.project_id = NEW.project_id
        AND receipt.job_id = NEW.job_id AND receipt.attempt_no = NEW.attempt_no
        AND receipt.provider_class = NEW.provider_class
        AND receipt.provider_request_id = NEW.provider_request_id
        AND receipt.request_hash = NEW.request_hash
        AND receipt.request_authority_hash = NEW.request_authority_hash
        AND receipt.receipt_kind = required_receipt_kind
        AND receipt.receipt_hash = NEW.terminal_authority_hash
    ) THEN
      RAISE EXCEPTION 'production_provider_attempt_terminal_receipt_missing';
    END IF;
  END IF;
  RETURN NEW;
END;
$fn$;
REVOKE ALL ON FUNCTION old_mike_production_private.guard_provider_attempt_transition() FROM PUBLIC;
CREATE TRIGGER production_provider_attempts_transition_guard
  BEFORE UPDATE OR DELETE ON production_ai_provider_attempts
  FOR EACH ROW EXECUTE FUNCTION old_mike_production_private.guard_provider_attempt_transition();

CREATE FUNCTION old_mike_production_private.guard_human_gate_transition()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public, old_mike_production_private AS $fn$
BEGIN
  IF TG_OP = 'DELETE' THEN RAISE EXCEPTION 'production_human_gate_delete_forbidden'; END IF;
  IF NEW.workspace_id IS DISTINCT FROM OLD.workspace_id OR NEW.project_id IS DISTINCT FROM OLD.project_id
     OR NEW.human_gate_id IS DISTINCT FROM OLD.human_gate_id
     OR NEW.human_gate_decision_hash IS DISTINCT FROM OLD.human_gate_decision_hash
     OR NEW.snapshot_revision IS DISTINCT FROM OLD.snapshot_revision
     OR NEW.gate_scope IS DISTINCT FROM OLD.gate_scope
     OR NEW.gate_request_hash IS DISTINCT FROM OLD.gate_request_hash
     OR NEW.created_at IS DISTINCT FROM OLD.created_at THEN
    RAISE EXCEPTION 'production_human_gate_identity_immutable';
  END IF;
  IF OLD.decision <> 'PENDING' OR NEW.decision NOT IN ('CONFIRMED','REJECTED')
     OR NEW.decision_hash IS NULL OR NEW.decided_by_user_id IS NULL OR NEW.decided_at IS NULL THEN
    RAISE EXCEPTION 'production_human_gate_transition_invalid';
  END IF;
  RETURN NEW;
END;
$fn$;
REVOKE ALL ON FUNCTION old_mike_production_private.guard_human_gate_transition() FROM PUBLIC;
CREATE TRIGGER production_human_gate_transition_guard
  BEFORE UPDATE OR DELETE ON production_human_gate_authorities
  FOR EACH ROW EXECUTE FUNCTION old_mike_production_private.guard_human_gate_transition();

CREATE FUNCTION old_mike_production_private.guard_formal_effect_transition()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public, old_mike_production_private AS $fn$
BEGIN
  IF TG_OP = 'DELETE' THEN RAISE EXCEPTION 'production_formal_effect_delete_forbidden'; END IF;
  IF NEW.workspace_id IS DISTINCT FROM OLD.workspace_id OR NEW.project_id IS DISTINCT FROM OLD.project_id
     OR NEW.formal_effect_id IS DISTINCT FROM OLD.formal_effect_id
     OR NEW.snapshot_revision IS DISTINCT FROM OLD.snapshot_revision
     OR NEW.human_gate_id IS DISTINCT FROM OLD.human_gate_id
     OR NEW.operation IS DISTINCT FROM OLD.operation
     OR NEW.effect_payload_hash IS DISTINCT FROM OLD.effect_payload_hash
     OR NEW.authorization_hash IS DISTINCT FROM OLD.authorization_hash
     OR NEW.authorized_by_user_id IS DISTINCT FROM OLD.authorized_by_user_id
     OR NEW.authorized_at IS DISTINCT FROM OLD.authorized_at THEN
    RAISE EXCEPTION 'production_formal_effect_identity_immutable';
  END IF;
  IF OLD.status <> 'AUTHORIZED' OR NEW.status NOT IN ('EXECUTED','REVOKED_BEFORE_EXECUTION')
     OR NEW.terminal_hash IS NULL OR NEW.terminal_actor_hash IS NULL THEN
    RAISE EXCEPTION 'production_formal_effect_transition_invalid';
  END IF;
  RETURN NEW;
END;
$fn$;
REVOKE ALL ON FUNCTION old_mike_production_private.guard_formal_effect_transition() FROM PUBLIC;
CREATE TRIGGER production_formal_effect_transition_guard
  BEFORE UPDATE OR DELETE ON production_formal_effect_authorities
  FOR EACH ROW EXECUTE FUNCTION old_mike_production_private.guard_formal_effect_transition();

CREATE FUNCTION old_mike_production_private.guard_outbox_transition()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public, old_mike_production_private AS $fn$
DECLARE legal boolean := false;
BEGIN
  IF TG_OP = 'DELETE' THEN RAISE EXCEPTION 'production_outbox_delete_forbidden'; END IF;
  IF NEW.workspace_id IS DISTINCT FROM OLD.workspace_id OR NEW.project_id IS DISTINCT FROM OLD.project_id
     OR NEW.outbox_id IS DISTINCT FROM OLD.outbox_id OR NEW.job_id IS DISTINCT FROM OLD.job_id
     OR NEW.formal_effect_id IS DISTINCT FROM OLD.formal_effect_id OR NEW.kind IS DISTINCT FROM OLD.kind
     OR NEW.aggregate_version IS DISTINCT FROM OLD.aggregate_version
     OR NEW.aggregate_authority_hash IS DISTINCT FROM OLD.aggregate_authority_hash
     OR NEW.payload_hash IS DISTINCT FROM OLD.payload_hash
     OR NEW.message_payload IS DISTINCT FROM OLD.message_payload
     OR NEW.created_at IS DISTINCT FROM OLD.created_at THEN
    RAISE EXCEPTION 'production_outbox_identity_immutable';
  END IF;
  legal :=
    (OLD.state = 'PENDING' AND NEW.state = 'LEASED') OR
    (OLD.state = 'LEASED' AND NEW.state = 'PENDING' AND OLD.lease_expires_at < clock_timestamp()) OR
    (OLD.state = 'LEASED' AND NEW.state = 'PUBLISHED');
  IF NOT legal THEN RAISE EXCEPTION 'production_outbox_transition_invalid'; END IF;
  RETURN NEW;
END;
$fn$;
REVOKE ALL ON FUNCTION old_mike_production_private.guard_outbox_transition() FROM PUBLIC;
CREATE TRIGGER production_outbox_transition_guard
  BEFORE UPDATE OR DELETE ON production_ai_outbox
  FOR EACH ROW EXECUTE FUNCTION old_mike_production_private.guard_outbox_transition();

CREATE FUNCTION old_mike_production_private.guard_webhook_inbox_transition()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public, old_mike_production_private AS $fn$
DECLARE legal boolean := false;
BEGIN
  IF TG_OP = 'DELETE' THEN RAISE EXCEPTION 'production_webhook_inbox_delete_forbidden'; END IF;
  IF NEW.provider_class IS DISTINCT FROM OLD.provider_class
     OR NEW.provider_event_id IS DISTINCT FROM OLD.provider_event_id
     OR NEW.key_version IS DISTINCT FROM OLD.key_version
     OR NEW.signature_status IS DISTINCT FROM OLD.signature_status
     OR NEW.raw_body_byte_length IS DISTINCT FROM OLD.raw_body_byte_length
     OR NEW.raw_body_hash IS DISTINCT FROM OLD.raw_body_hash
     OR NEW.raw_body_storage_class IS DISTINCT FROM OLD.raw_body_storage_class
     OR NEW.raw_body_object_id IS DISTINCT FROM OLD.raw_body_object_id
     OR NEW.raw_body_object_key_hash IS DISTINCT FROM OLD.raw_body_object_key_hash
     OR NEW.raw_body_object_version_id IS DISTINCT FROM OLD.raw_body_object_version_id
     OR NEW.raw_body_storage_receipt_hash IS DISTINCT FROM OLD.raw_body_storage_receipt_hash
     OR NEW.request_timestamp IS DISTINCT FROM OLD.request_timestamp
     OR NEW.received_at IS DISTINCT FROM OLD.received_at THEN
    RAISE EXCEPTION 'production_webhook_inbox_identity_immutable';
  END IF;
  legal :=
    (OLD.status = 'RECEIVED' AND NEW.status IN ('LEASED','REJECTED')) OR
    (OLD.status = 'LEASED' AND NEW.status = 'RECEIVED' AND OLD.lease_expires_at < clock_timestamp()) OR
    (OLD.status = 'LEASED' AND NEW.status IN ('APPLIED','REJECTED'));
  IF NOT legal THEN RAISE EXCEPTION 'production_webhook_inbox_transition_invalid'; END IF;
  RETURN NEW;
END;
$fn$;
REVOKE ALL ON FUNCTION old_mike_production_private.guard_webhook_inbox_transition() FROM PUBLIC;
CREATE TRIGGER production_webhook_inbox_transition_guard
  BEFORE UPDATE OR DELETE ON production_ai_webhook_inbox
  FOR EACH ROW EXECUTE FUNCTION old_mike_production_private.guard_webhook_inbox_transition();

CREATE FUNCTION old_mike_production_private.guard_ai_job_transition()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER
SET search_path = pg_catalog, public, old_mike_production_private AS $fn$
DECLARE
  legal boolean := false;
BEGIN
  IF TG_OP = 'DELETE' THEN RAISE EXCEPTION 'production_ai_job_delete_forbidden'; END IF;
  IF NEW.workspace_id IS DISTINCT FROM OLD.workspace_id
     OR NEW.project_id IS DISTINCT FROM OLD.project_id OR NEW.job_id IS DISTINCT FROM OLD.job_id
     OR NEW.created_by_user_id IS DISTINCT FROM OLD.created_by_user_id
     OR NEW.contract_version IS DISTINCT FROM OLD.contract_version
     OR NEW.stage_id IS DISTINCT FROM OLD.stage_id
     OR NEW.effect_lineage_hash IS DISTINCT FROM OLD.effect_lineage_hash
     OR NEW.operation IS DISTINCT FROM OLD.operation
     OR NEW.operation_identity_hash IS DISTINCT FROM OLD.operation_identity_hash
     OR NEW.request_id IS DISTINCT FROM OLD.request_id
     OR NEW.idempotency_key IS DISTINCT FROM OLD.idempotency_key
     OR NEW.request_hash IS DISTINCT FROM OLD.request_hash
     OR NEW.base_revision IS DISTINCT FROM OLD.base_revision
     OR NEW.base_content_hash IS DISTINCT FROM OLD.base_content_hash
     OR NEW.source_bundle_id IS DISTINCT FROM OLD.source_bundle_id
     OR NEW.source_bundle_version IS DISTINCT FROM OLD.source_bundle_version
     OR NEW.source_bundle_hash IS DISTINCT FROM OLD.source_bundle_hash
     OR NEW.prompt_id IS DISTINCT FROM OLD.prompt_id OR NEW.prompt_version IS DISTINCT FROM OLD.prompt_version
     OR NEW.prompt_hash IS DISTINCT FROM OLD.prompt_hash
     OR NEW.prompt_approval_event_hash IS DISTINCT FROM OLD.prompt_approval_event_hash
     OR NEW.output_schema_id IS DISTINCT FROM OLD.output_schema_id
     OR NEW.output_schema_version IS DISTINCT FROM OLD.output_schema_version
     OR NEW.output_schema_hash IS DISTINCT FROM OLD.output_schema_hash
     OR NEW.output_schema_approval_event_hash IS DISTINCT FROM OLD.output_schema_approval_event_hash
     OR NEW.model_policy_id IS DISTINCT FROM OLD.model_policy_id
     OR NEW.model_policy_version IS DISTINCT FROM OLD.model_policy_version
     OR NEW.model_policy_hash IS DISTINCT FROM OLD.model_policy_hash
     OR NEW.model_policy_approval_event_hash IS DISTINCT FROM OLD.model_policy_approval_event_hash
     OR NEW.eval_id IS DISTINCT FROM OLD.eval_id OR NEW.eval_version IS DISTINCT FROM OLD.eval_version
     OR NEW.eval_hash IS DISTINCT FROM OLD.eval_hash
     OR NEW.eval_approval_event_hash IS DISTINCT FROM OLD.eval_approval_event_hash
     OR NEW.provider_config_id IS DISTINCT FROM OLD.provider_config_id
     OR NEW.provider_config_version IS DISTINCT FROM OLD.provider_config_version
     OR NEW.provider_config_hash IS DISTINCT FROM OLD.provider_config_hash
     OR NEW.provider_config_approval_event_hash IS DISTINCT FROM OLD.provider_config_approval_event_hash
     OR NEW.privacy_policy_id IS DISTINCT FROM OLD.privacy_policy_id
     OR NEW.privacy_policy_version IS DISTINCT FROM OLD.privacy_policy_version
     OR NEW.privacy_policy_hash IS DISTINCT FROM OLD.privacy_policy_hash
     OR NEW.privacy_policy_approval_event_hash IS DISTINCT FROM OLD.privacy_policy_approval_event_hash
     OR NEW.retention_policy_id IS DISTINCT FROM OLD.retention_policy_id
     OR NEW.retention_policy_version IS DISTINCT FROM OLD.retention_policy_version
     OR NEW.retention_policy_hash IS DISTINCT FROM OLD.retention_policy_hash
     OR NEW.retention_policy_approval_event_hash IS DISTINCT FROM OLD.retention_policy_approval_event_hash
     OR NEW.created_at IS DISTINCT FROM OLD.created_at THEN
     RAISE EXCEPTION 'production_ai_job_immutable_authority';
  END IF;
  IF NEW.state_version <> OLD.state_version + 1 OR NEW.provider_submission_count < OLD.provider_submission_count
     OR NEW.provider_submission_count > 1 THEN
    RAISE EXCEPTION 'production_ai_job_version_or_submission_invalid';
  END IF;
  legal :=
    (OLD.state = 'QUEUED' AND NEW.state IN ('LEASED','FAILED_PRE_SUBMISSION','CANCELLED_PRE_SUBMISSION')) OR
    (OLD.state = 'LEASED' AND NEW.state IN ('QUEUED','SUBMITTING','FAILED_PRE_SUBMISSION')) OR
    (OLD.state = 'SUBMITTING' AND NEW.state IN ('ACCEPTED','COMPLETION_UNKNOWN','SUCCEEDED','TERMINAL_REJECTED','FAILED_PROVEN_NOT_SUBMITTED')) OR
    (OLD.state = 'ACCEPTED' AND NEW.state IN ('COMPLETION_UNKNOWN','SUCCEEDED','TERMINAL_REJECTED')) OR
    (OLD.state = 'COMPLETION_UNKNOWN' AND NEW.state IN ('COMPLETION_UNKNOWN','SUCCEEDED','TERMINAL_REJECTED'));
  IF NOT legal THEN RAISE EXCEPTION 'production_ai_job_transition_invalid'; END IF;
  IF OLD.provider_submission_count = 1 AND NEW.state IN ('QUEUED','LEASED','SUBMITTING') THEN
    RAISE EXCEPTION 'production_ai_no_resend_fence';
  END IF;
  IF NEW.acceptance_receipt_hash IS NOT NULL AND NOT EXISTS (
    SELECT 1
    FROM public.production_ai_provider_attempts attempt
    JOIN public.production_ai_provider_receipts receipt
      ON receipt.workspace_id = attempt.workspace_id AND receipt.project_id = attempt.project_id
     AND receipt.job_id = attempt.job_id AND receipt.attempt_no = attempt.attempt_no
     AND receipt.provider_class = attempt.provider_class
     AND receipt.provider_request_id = attempt.provider_request_id
     AND receipt.request_hash = attempt.request_hash
     AND receipt.request_authority_hash = attempt.request_authority_hash
    WHERE attempt.workspace_id = NEW.workspace_id AND attempt.project_id = NEW.project_id
      AND attempt.job_id = NEW.job_id AND attempt.attempt_no = 1
      AND receipt.receipt_sequence = NEW.acceptance_receipt_sequence
      AND receipt.receipt_hash = NEW.acceptance_receipt_hash
      AND receipt.receipt_kind = 'SUBMISSION_ACCEPTED'
  ) THEN
    RAISE EXCEPTION 'production_ai_job_acceptance_receipt_invalid';
  END IF;
  IF NEW.state IN ('SUCCEEDED','TERMINAL_REJECTED','FAILED_PROVEN_NOT_SUBMITTED')
     AND NOT EXISTS (
       SELECT 1
       FROM public.production_ai_provider_attempts attempt
       JOIN public.production_ai_provider_receipts receipt
         ON receipt.workspace_id = attempt.workspace_id AND receipt.project_id = attempt.project_id
        AND receipt.job_id = attempt.job_id AND receipt.attempt_no = attempt.attempt_no
        AND receipt.provider_class = attempt.provider_class
        AND receipt.provider_request_id = attempt.provider_request_id
        AND receipt.request_hash = attempt.request_hash
        AND receipt.request_authority_hash = attempt.request_authority_hash
       WHERE attempt.workspace_id = NEW.workspace_id AND attempt.project_id = NEW.project_id
         AND attempt.job_id = NEW.job_id AND attempt.attempt_no = 1 AND attempt.state = 'TERMINAL'
         AND attempt.terminal_outcome = CASE NEW.state
           WHEN 'SUCCEEDED' THEN 'SUCCEEDED'
           WHEN 'TERMINAL_REJECTED' THEN 'TERMINAL_REJECTED'
           ELSE 'PROVEN_NOT_SUBMITTED' END
         AND receipt.receipt_sequence = NEW.terminal_receipt_sequence
         AND receipt.receipt_hash = NEW.terminal_receipt_hash
         AND receipt.receipt_kind = CASE NEW.state
           WHEN 'SUCCEEDED' THEN 'COMPLETION_OBSERVED'
           WHEN 'TERMINAL_REJECTED' THEN 'TERMINAL_REJECTED'
           ELSE 'PROVEN_NOT_SUBMITTED' END
     ) THEN
    RAISE EXCEPTION 'production_ai_job_terminal_attempt_or_receipt_invalid';
  END IF;
  NEW.updated_at := clock_timestamp();
  RETURN NEW;
END;
$fn$;

REVOKE ALL ON FUNCTION old_mike_production_private.guard_ai_job_transition() FROM PUBLIC;
CREATE TRIGGER production_ai_jobs_transition_guard
  BEFORE UPDATE OR DELETE ON production_ai_jobs
  FOR EACH ROW EXECUTE FUNCTION old_mike_production_private.guard_ai_job_transition();

-- Exact capability routines are part of the final reviewed 0008 implementation.
-- M1A freezes their contract but deliberately provides no executable bodies or grants:
--   production_register_command(text workspace, text project, text actor, text operation,
--     text request_id, text idempotency_key, jsonb exact_request) -> jsonb command_authority.
--     WEB only; lock project, recompute canonical request/operation/source-bundle/registry
--     authorities, check active membership/project and latest APPROVED registry events,
--     insert PENDING intent + QUEUED job + PENDING AI_JOB_READY outbox atomically. QUEUED
--     means durable intent exists; the relay never owns a job business-state transition.
--   production_read_project(text workspace, text project, text actor) -> jsonb exact_head.
--     WEB only; exact tenant/project membership, latest immutable snapshot/event/outcome.
--   production_save_project_truth(text workspace, text project, text actor, text operation,
--     text request_id, text idempotency_key, jsonb exact_request) -> jsonb committed_result.
--     WEB only; project lock, canonical intent tuple, CAS snapshot/event, exact response hash;
--     exact historical replay returns the original result and changed tuple conflicts at zero effect.
--   production_claim_outbox(text relay, integer lease_seconds) -> jsonb lease.
--     RELAY only; database-time PENDING/expired-LEASED claim, exact typed aggregate.
--   production_ack_outbox(text workspace, text project, text outbox_id, text relay,
--     text payload_hash, text published_message_id) -> jsonb publication.
--     RELAY only; LEASED->PUBLISHED, exact message identity, same-message replay zero mutation;
--     no job transition. Publish-before-ack crash may redeliver the same FIFO-dedup message,
--     while inbox/job/effect fences prevent a second provider effect.
--   production_claim_ai_job(text worker, integer lease_seconds) -> jsonb job_lease.
--     WORKER only; QUEUED/expired-LEASED CAS is eligible only after exact AI_JOB_READY
--     outbox PUBLISHED; one project/job lock order and no provider I/O in transaction.
--   production_begin_provider_io(text workspace, text project, text job, bigint state_version,
--     text provider_class, text provider_request_id) -> jsonb attempt.
--     WORKER only; registry/source/budget recheck, LEASED->SUBMITTING plus immutable attempt 1
--     and IO_STARTED in one commit before network I/O. Later ambiguity is never resendable.
--   production_record_provider_ack(text workspace, text project, text job, jsonb exact_ack)
--     -> jsonb attempt_state. WORKER only; strict tuple/proof parsing, next receipt, attempt and
--     job ACCEPTED transition atomically; exact replay zero mutation.
--   production_commit_provider_outcome(text workspace, text project, text job,
--     jsonb exact_outcome) -> jsonb terminal_result. WORKER only; strict result/rejection/
--     proven-not-submitted proof, receipt, attempt, usage, event and snapshot in one transaction.
--   production_mark_completion_unknown(text workspace, text project, text job,
--     bigint state_version, text sanitized_reason) -> jsonb unknown_result. WORKER only;
--     permanent no-resend fence and no truth revision.
--   production_record_lookup_receipt(text workspace, text project, text job,
--     jsonb exact_lookup) -> jsonb lookup_receipt. WORKER only; non-generating exact attempt lookup.
--   production_receive_webhook(text provider, text event_id, text key_version,
--     text signature_status, bigint raw_bytes, text raw_hash,
--     jsonb exact_versioned_encrypted_body_object, timestamptz request_time)
--     -> jsonb inbox_result. WORKER ingress only; dedup insert and durable RECEIVED authority;
--     before insert the bounded raw body is stored in a versioned encrypted object and its exact
--     key hash/version/storage receipt is read back. No project truth transition. Database polling
--     leases every valid unprocessed row and reopens the exact body object, so a crash after insert
--     cannot strand the event and sender retry is not required for recovery.
--   production_claim_webhook(text worker, integer lease_seconds) -> jsonb webhook_lease.
--     WORKER only; database-time RECEIVED/expired-LEASED recovery and exact replay.
--   production_authorize_human_reconciliation(text workspace, text project, text job,
--     text actor, jsonb exact_decision) -> jsonb decision_authority. WEB only; active member,
--     exact membership snapshot, authorization scope/policy, attempt, decision/hash/time and no
--     terminal promotion by an unbound assertion.
--   production_record_reconciliation(text workspace, text project, text job,
--     text method, jsonb exact_authority) -> jsonb reconcile_result. WORKER only; LOOKUP,
--     SIGNED_WEBHOOK or AUTHORIZED_HUMAN must bind its exact discriminated evidence; missing or
--     mismatched authority remains UNKNOWN/BLOCKED. Terminal commit is atomic and replay-safe.
--   production_decide_human_gate(text workspace, text project, text gate, text actor,
--     text decision, jsonb exact_decision) -> jsonb gate_result. WEB only; PENDING terminal CAS.
--   production_transition_formal_effect(text workspace, text project, text effect,
--     text actor_hash, text terminal_status, jsonb exact_terminal) -> jsonb effect_result.
--     authorized formal executor only; AUTHORIZED terminal CAS, never reversal or rewrite.
-- Every routine must use a fixed owner, fixed search_path, fully qualified objects,
-- no dynamic SQL, bounded statement/lock timeout, composite workspace/project authority,
-- exact role assertion, and PUBLIC EXECUTE revocation. If any body is absent, 0008 is not executable.
-- RLS is not claimed by this static proposal. Before executable 0008, the threat review
-- must freeze either capability-only access or capability-plus-defense-in-depth RLS with
-- non-caller-controlled tenant context, pooled-session reset, owner/BYPASSRLS analysis,
-- and cross-tenant tests. Enabling RLS without that authority is forbidden.

CREATE VIEW production_observer_job_metrics
WITH (security_barrier = true) AS
SELECT workspace_id, project_id, job_id, stage_id, effect_lineage_hash, state,
       state_version, provider_submission_count, created_at, updated_at,
       submitted_at, accepted_at, terminal_at, sanitized_reason_code
FROM production_ai_jobs;

CREATE VIEW production_observer_queue_metrics
WITH (security_barrier = true) AS
SELECT workspace_id, project_id, outbox_id, job_id, kind, aggregate_version,
       payload_hash, state, created_at, published_at
FROM production_ai_outbox;

CREATE VIEW production_observer_usage_metrics
WITH (security_barrier = true) AS
SELECT workspace_id, project_id, usage_id, job_id, provider_class,
       normalized_input_units, normalized_output_units, currency,
       normalized_cost, cost_schedule_version, created_at
FROM production_ai_usage_ledger;

-- Revoke only the exact new 0008 relations. Existing 0001..0007 Better Auth,
-- tenant and research ACLs are unchanged except the explicit owner SELECT/REFERENCES
-- grants on projects and workspace_members required above.
REVOKE ALL ON TABLE
  production_project_snapshots,
  production_project_events,
  production_operation_intents,
  production_source_objects,
  production_source_bundles,
  production_source_bundle_members,
  production_ai_authority_registry,
  production_ai_registry_status_events,
  production_ai_jobs,
  production_ai_outbox,
  production_ai_inbox,
  production_ai_provider_attempts,
  production_ai_provider_receipts,
  production_ai_provider_lookup_receipts,
  production_ai_reconciliation_human_authorities,
  production_ai_reconciliation_observations,
  production_ai_webhook_inbox,
  production_ai_budget_reservations,
  production_ai_usage_ledger,
  production_evidence_authorities,
  production_citation_authorities,
  production_human_gate_authorities,
  production_formal_effect_authorities,
  production_observer_job_metrics,
  production_observer_queue_metrics,
  production_observer_usage_metrics
FROM old_mike_prod_web, old_mike_prod_worker, old_mike_prod_relay, old_mike_prod_observer;
REVOKE ALL ON ALL FUNCTIONS IN SCHEMA old_mike_production_private FROM PUBLIC;
REVOKE CREATE ON SCHEMA public FROM PUBLIC, old_mike_prod_web, old_mike_prod_worker,
  old_mike_prod_relay, old_mike_prod_observer;
GRANT USAGE ON SCHEMA old_mike_production_private TO old_mike_prod_web, old_mike_prod_worker, old_mike_prod_relay;
GRANT SELECT ON production_observer_job_metrics, production_observer_queue_metrics,
  production_observer_usage_metrics TO old_mike_prod_observer;

ALTER DEFAULT PRIVILEGES FOR ROLE old_mike_prod_owner IN SCHEMA public
  REVOKE ALL ON TABLES FROM PUBLIC, old_mike_prod_web, old_mike_prod_worker,
    old_mike_prod_relay, old_mike_prod_observer;
ALTER DEFAULT PRIVILEGES FOR ROLE old_mike_prod_owner IN SCHEMA old_mike_production_private
  REVOKE EXECUTE ON FUNCTIONS FROM PUBLIC, old_mike_prod_web, old_mike_prod_worker,
    old_mike_prod_relay, old_mike_prod_observer;

COMMENT ON SCHEMA old_mike_production_private IS
  'M1A static 0008 proposal. Not executable until all exact capability routines and grants are reviewed and verification passes.';

RESET ROLE;
COMMIT;
